# WordPress MySQL database migration
#
# Generated: Friday 2. September 2016 08:39 UTC
# Hostname: localhost
# Database: `host_development`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(3, 'siteurl', 'http://$HTTP_HOST/wp', 'yes'),
(4, 'home', 'http://${HTTP_HOST}/wp', 'yes'),
(5, 'blogname', 'Host.', 'yes'),
(6, 'blogdescription', 'Where students are at home.', 'yes'),
(7, 'users_can_register', '0', 'yes'),
(8, 'admin_email', 'digital@example.dev', 'yes'),
(9, 'start_of_week', '1', 'yes'),
(10, 'use_balanceTags', '0', 'yes'),
(11, 'use_smilies', '1', 'yes'),
(12, 'require_name_email', '1', 'yes'),
(13, 'comments_notify', '1', 'yes'),
(14, 'posts_per_rss', '10', 'yes'),
(15, 'rss_use_excerpt', '1', 'yes'),
(16, 'mailserver_url', 'mail.example.com', 'yes'),
(17, 'mailserver_login', 'login@example.com', 'yes'),
(18, 'mailserver_pass', 'password', 'yes'),
(19, 'mailserver_port', '110', 'yes'),
(20, 'default_category', '1', 'yes'),
(21, 'default_comment_status', 'open', 'yes'),
(22, 'default_ping_status', 'open', 'yes'),
(23, 'default_pingback_flag', '1', 'yes'),
(24, 'posts_per_page', '20', 'yes'),
(25, 'date_format', 'F j, Y', 'yes'),
(26, 'time_format', 'g:i a', 'yes'),
(27, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(28, 'comment_moderation', '0', 'yes'),
(29, 'moderation_notify', '1', 'yes'),
(30, 'permalink_structure', '/%postname%/', 'yes'),
(31, 'rewrite_rules', 'a:130:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:36:"university/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"university/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"university/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"university/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"university/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"university/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"university/(.+?)/embed/?$";s:43:"index.php?university=$matches[1]&embed=true";s:29:"university/(.+?)/trackback/?$";s:37:"index.php?university=$matches[1]&tb=1";s:37:"university/(.+?)/page/?([0-9]{1,})/?$";s:50:"index.php?university=$matches[1]&paged=$matches[2]";s:44:"university/(.+?)/comment-page-([0-9]{1,})/?$";s:50:"index.php?university=$matches[1]&cpage=$matches[2]";s:33:"university/(.+?)(?:/([0-9]+))?/?$";s:49:"index.php?university=$matches[1]&page=$matches[2]";s:35:"locations/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"locations/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"locations/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"locations/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"locations/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"locations/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"locations/(.+?)/embed/?$";s:42:"index.php?locations=$matches[1]&embed=true";s:28:"locations/(.+?)/trackback/?$";s:36:"index.php?locations=$matches[1]&tb=1";s:36:"locations/(.+?)/page/?([0-9]{1,})/?$";s:49:"index.php?locations=$matches[1]&paged=$matches[2]";s:43:"locations/(.+?)/comment-page-([0-9]{1,})/?$";s:49:"index.php?locations=$matches[1]&cpage=$matches[2]";s:32:"locations/(.+?)(?:/([0-9]+))?/?$";s:48:"index.php?locations=$matches[1]&page=$matches[2]";s:35:"buildings/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"buildings/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"buildings/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"buildings/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"buildings/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"buildings/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"buildings/(.+?)/embed/?$";s:42:"index.php?buildings=$matches[1]&embed=true";s:28:"buildings/(.+?)/trackback/?$";s:36:"index.php?buildings=$matches[1]&tb=1";s:36:"buildings/(.+?)/page/?([0-9]{1,})/?$";s:49:"index.php?buildings=$matches[1]&paged=$matches[2]";s:43:"buildings/(.+?)/comment-page-([0-9]{1,})/?$";s:49:"index.php?buildings=$matches[1]&cpage=$matches[2]";s:32:"buildings/(.+?)(?:/([0-9]+))?/?$";s:48:"index.php?buildings=$matches[1]&page=$matches[2]";s:31:"rooms/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"rooms/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"rooms/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"rooms/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"rooms/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"rooms/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"rooms/(.+?)/embed/?$";s:38:"index.php?rooms=$matches[1]&embed=true";s:24:"rooms/(.+?)/trackback/?$";s:32:"index.php?rooms=$matches[1]&tb=1";s:32:"rooms/(.+?)/page/?([0-9]{1,})/?$";s:45:"index.php?rooms=$matches[1]&paged=$matches[2]";s:39:"rooms/(.+?)/comment-page-([0-9]{1,})/?$";s:45:"index.php?rooms=$matches[1]&cpage=$matches[2]";s:28:"rooms/(.+?)(?:/([0-9]+))?/?$";s:44:"index.php?rooms=$matches[1]&page=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:40:"index.php?&page_id=158&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(32, 'hack_file', '0', 'yes'),
(33, 'blog_charset', 'UTF-8', 'yes'),
(34, 'moderation_keys', '', 'no'),
(35, 'active_plugins', 'a:6:{i:0;s:61:"advanced-custom-fields-file-picker-master/acf-file_picker.php";i:1;s:34:"advanced-custom-fields-pro/acf.php";i:2;s:25:"gtranslate/gtranslate.php";i:3;s:27:"host-plugin/host-plugin.php";i:4;s:33:"posts-to-posts/posts-to-posts.php";i:5;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(36, 'category_base', '', 'yes'),
(37, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(38, 'comment_max_links', '2', 'yes'),
(39, 'gmt_offset', '0', 'yes'),
(40, 'default_email_category', '1', 'yes'),
(41, 'recently_edited', '', 'no'),
(42, 'template', 'host', 'yes'),
(43, 'stylesheet', 'host', 'yes'),
(44, 'comment_whitelist', '1', 'yes'),
(45, 'blacklist_keys', '', 'no'),
(46, 'comment_registration', '0', 'yes'),
(47, 'html_type', 'text/html', 'yes'),
(48, 'use_trackback', '0', 'yes'),
(49, 'default_role', 'subscriber', 'yes'),
(50, 'db_version', '37965', 'yes'),
(51, 'uploads_use_yearmonth_folders', '1', 'yes'),
(52, 'upload_path', '', 'yes'),
(53, 'blog_public', '1', 'yes'),
(54, 'default_link_category', '2', 'yes'),
(55, 'show_on_front', 'page', 'yes'),
(56, 'tag_base', '', 'yes'),
(57, 'show_avatars', '1', 'yes'),
(58, 'avatar_rating', 'G', 'yes'),
(59, 'upload_url_path', '', 'yes'),
(60, 'thumbnail_size_w', '150', 'yes'),
(61, 'thumbnail_size_h', '150', 'yes'),
(62, 'thumbnail_crop', '1', 'yes'),
(63, 'medium_size_w', '300', 'yes'),
(64, 'medium_size_h', '300', 'yes'),
(65, 'avatar_default', 'mystery', 'yes'),
(66, 'large_size_w', '1024', 'yes'),
(67, 'large_size_h', '1024', 'yes'),
(68, 'image_default_link_type', 'none', 'yes'),
(69, 'image_default_size', '', 'yes'),
(70, 'image_default_align', '', 'yes'),
(71, 'close_comments_for_old_posts', '0', 'yes'),
(72, 'close_comments_days_old', '14', 'yes'),
(73, 'thread_comments', '1', 'yes'),
(74, 'thread_comments_depth', '5', 'yes'),
(75, 'page_comments', '0', 'yes'),
(76, 'comments_per_page', '50', 'yes'),
(77, 'default_comments_page', 'newest', 'yes'),
(78, 'comment_order', 'asc', 'yes'),
(79, 'sticky_posts', 'a:0:{}', 'yes'),
(80, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_text', 'a:0:{}', 'yes'),
(82, 'widget_rss', 'a:0:{}', 'yes'),
(83, 'uninstall_plugins', 'a:1:{s:33:"posts-to-posts/posts-to-posts.php";a:2:{i:0;s:11:"P2P_Storage";i:1;s:9:"uninstall";}}', 'no'),
(84, 'timezone_string', '', 'yes'),
(85, 'page_for_posts', '162', 'yes'),
(86, 'page_on_front', '158', 'yes'),
(87, 'default_post_format', '0', 'yes'),
(88, 'link_manager_enabled', '0', 'yes'),
(89, 'finished_splitting_shared_terms', '1', 'yes'),
(90, 'site_icon', '0', 'yes'),
(91, 'medium_large_size_w', '768', 'yes'),
(92, 'medium_large_size_h', '0', 'yes'),
(93, 'initial_db_version', '36686', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(95, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(101, 'bedrock_autoloader', 'a:2:{s:7:"plugins";a:0:{}s:5:"count";i:0;}', 'no'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'cron', 'a:4:{i:1472811276;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1472816909;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1472833801;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}s:7:"version";i:2;}', 'yes'),
(164, 'auth_key', ']^7U8wU@MDKBP1#;9(E$$ S>QDs-fKMj82S| THuH0tvQ~b4YbMo];fbw{uu>(k(', 'yes'),
(165, 'auth_salt', 'Yz?kvH1Z?q$G0{~?ij3cxjhsEA?PG$n/MVm%Q!g*TWlV>$ep1mS0m=K9?oOj,l|&', 'yes'),
(166, 'logged_in_key', '>@B&EE)nb_fbSbpfb/@PF6ch_p<hSDw2$<(j8@bD6:}<#5OLXu0mJ{@QPDsJC<,-', 'yes'),
(167, 'logged_in_salt', 'rN+bK0G5Hf:<n{X4%~n5D>CNbQld|_u:n/^J>&JY<}HBql{8_fsg-t<PME!kH!8c', 'yes'),
(168, 'nonce_key', 'oOt3TGA1h$LiXUZBM#V;QUAp35Dca J,~IC^]]X4W>0*sLN(3M8D5}v:`yjBi-<i', 'yes'),
(169, 'nonce_salt', 'he#-D#,LAV52-QS@D-7@h>;C`}~:dP[-pdHsr&}kpyoi*uIGm/$3k9ryS>$vW<?(', 'yes'),
(191, 'recently_activated', 'a:0:{}', 'yes'),
(196, 'acf_version', '5.4.3', 'yes'),
(226, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1470922912;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(227, 'template_root', '/themes', 'yes'),
(228, 'stylesheet_root', '/themes', 'yes'),
(229, 'current_theme', 'Host - Student Accomodation', 'yes'),
(230, 'theme_mods_host', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:18:"primary_navigation";i:6;s:16:"footer_utilities";i:7;s:12:"footer_about";i:8;}}', 'yes'),
(231, 'theme_switched', '', 'yes'),
(258, 'wpuxss_eml_version', '2.3.1', 'yes'),
(259, 'wpuxss_eml_mimes_backup', 'a:90:{s:12:"jpg|jpeg|jpe";a:5:{s:4:"mime";s:10:"image/jpeg";s:8:"singular";s:10:"image/jpeg";s:6:"plural";s:10:"image/jpeg";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"gif";a:5:{s:4:"mime";s:9:"image/gif";s:8:"singular";s:9:"image/gif";s:6:"plural";s:9:"image/gif";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"png";a:5:{s:4:"mime";s:9:"image/png";s:8:"singular";s:9:"image/png";s:6:"plural";s:9:"image/png";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"bmp";a:5:{s:4:"mime";s:9:"image/bmp";s:8:"singular";s:9:"image/bmp";s:6:"plural";s:9:"image/bmp";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"tiff|tif";a:5:{s:4:"mime";s:10:"image/tiff";s:8:"singular";s:10:"image/tiff";s:6:"plural";s:10:"image/tiff";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ico";a:5:{s:4:"mime";s:12:"image/x-icon";s:8:"singular";s:12:"image/x-icon";s:6:"plural";s:12:"image/x-icon";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"asf|asx";a:5:{s:4:"mime";s:14:"video/x-ms-asf";s:8:"singular";s:14:"video/x-ms-asf";s:6:"plural";s:14:"video/x-ms-asf";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wmv";a:5:{s:4:"mime";s:14:"video/x-ms-wmv";s:8:"singular";s:14:"video/x-ms-wmv";s:6:"plural";s:14:"video/x-ms-wmv";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wmx";a:5:{s:4:"mime";s:14:"video/x-ms-wmx";s:8:"singular";s:14:"video/x-ms-wmx";s:6:"plural";s:14:"video/x-ms-wmx";s:6:"filter";i:0;s:6:"upload";i:1;}s:2:"wm";a:5:{s:4:"mime";s:13:"video/x-ms-wm";s:8:"singular";s:13:"video/x-ms-wm";s:6:"plural";s:13:"video/x-ms-wm";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"avi";a:5:{s:4:"mime";s:9:"video/avi";s:8:"singular";s:9:"video/avi";s:6:"plural";s:9:"video/avi";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"divx";a:5:{s:4:"mime";s:10:"video/divx";s:8:"singular";s:10:"video/divx";s:6:"plural";s:10:"video/divx";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"flv";a:5:{s:4:"mime";s:11:"video/x-flv";s:8:"singular";s:11:"video/x-flv";s:6:"plural";s:11:"video/x-flv";s:6:"filter";i:0;s:6:"upload";i:1;}s:6:"mov|qt";a:5:{s:4:"mime";s:15:"video/quicktime";s:8:"singular";s:15:"video/quicktime";s:6:"plural";s:15:"video/quicktime";s:6:"filter";i:0;s:6:"upload";i:1;}s:12:"mpeg|mpg|mpe";a:5:{s:4:"mime";s:10:"video/mpeg";s:8:"singular";s:10:"video/mpeg";s:6:"plural";s:10:"video/mpeg";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"mp4|m4v";a:5:{s:4:"mime";s:9:"video/mp4";s:8:"singular";s:9:"video/mp4";s:6:"plural";s:9:"video/mp4";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ogv";a:5:{s:4:"mime";s:9:"video/ogg";s:8:"singular";s:9:"video/ogg";s:6:"plural";s:9:"video/ogg";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"webm";a:5:{s:4:"mime";s:10:"video/webm";s:8:"singular";s:10:"video/webm";s:6:"plural";s:10:"video/webm";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mkv";a:5:{s:4:"mime";s:16:"video/x-matroska";s:8:"singular";s:16:"video/x-matroska";s:6:"plural";s:16:"video/x-matroska";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"3gp|3gpp";a:5:{s:4:"mime";s:10:"video/3gpp";s:8:"singular";s:10:"video/3gpp";s:6:"plural";s:10:"video/3gpp";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"3g2|3gp2";a:5:{s:4:"mime";s:11:"video/3gpp2";s:8:"singular";s:11:"video/3gpp2";s:6:"plural";s:11:"video/3gpp2";s:6:"filter";i:0;s:6:"upload";i:1;}s:18:"txt|asc|c|cc|h|srt";a:5:{s:4:"mime";s:10:"text/plain";s:8:"singular";s:10:"text/plain";s:6:"plural";s:10:"text/plain";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"csv";a:5:{s:4:"mime";s:8:"text/csv";s:8:"singular";s:8:"text/csv";s:6:"plural";s:8:"text/csv";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"tsv";a:5:{s:4:"mime";s:25:"text/tab-separated-values";s:8:"singular";s:25:"text/tab-separated-values";s:6:"plural";s:25:"text/tab-separated-values";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ics";a:5:{s:4:"mime";s:13:"text/calendar";s:8:"singular";s:13:"text/calendar";s:6:"plural";s:13:"text/calendar";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"rtx";a:5:{s:4:"mime";s:13:"text/richtext";s:8:"singular";s:13:"text/richtext";s:6:"plural";s:13:"text/richtext";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"css";a:5:{s:4:"mime";s:8:"text/css";s:8:"singular";s:8:"text/css";s:6:"plural";s:8:"text/css";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"htm|html";a:5:{s:4:"mime";s:9:"text/html";s:8:"singular";s:9:"text/html";s:6:"plural";s:9:"text/html";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"vtt";a:5:{s:4:"mime";s:8:"text/vtt";s:8:"singular";s:8:"text/vtt";s:6:"plural";s:8:"text/vtt";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"dfxp";a:5:{s:4:"mime";s:20:"application/ttaf+xml";s:8:"singular";s:20:"application/ttaf+xml";s:6:"plural";s:20:"application/ttaf+xml";s:6:"filter";i:0;s:6:"upload";i:1;}s:11:"mp3|m4a|m4b";a:5:{s:4:"mime";s:10:"audio/mpeg";s:8:"singular";s:10:"audio/mpeg";s:6:"plural";s:10:"audio/mpeg";s:6:"filter";i:0;s:6:"upload";i:1;}s:6:"ra|ram";a:5:{s:4:"mime";s:17:"audio/x-realaudio";s:8:"singular";s:17:"audio/x-realaudio";s:6:"plural";s:17:"audio/x-realaudio";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wav";a:5:{s:4:"mime";s:9:"audio/wav";s:8:"singular";s:9:"audio/wav";s:6:"plural";s:9:"audio/wav";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"ogg|oga";a:5:{s:4:"mime";s:9:"audio/ogg";s:8:"singular";s:9:"audio/ogg";s:6:"plural";s:9:"audio/ogg";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"mid|midi";a:5:{s:4:"mime";s:10:"audio/midi";s:8:"singular";s:10:"audio/midi";s:6:"plural";s:10:"audio/midi";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wma";a:5:{s:4:"mime";s:14:"audio/x-ms-wma";s:8:"singular";s:14:"audio/x-ms-wma";s:6:"plural";s:14:"audio/x-ms-wma";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wax";a:5:{s:4:"mime";s:14:"audio/x-ms-wax";s:8:"singular";s:14:"audio/x-ms-wax";s:6:"plural";s:14:"audio/x-ms-wax";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mka";a:5:{s:4:"mime";s:16:"audio/x-matroska";s:8:"singular";s:16:"audio/x-matroska";s:6:"plural";s:16:"audio/x-matroska";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"rtf";a:5:{s:4:"mime";s:15:"application/rtf";s:8:"singular";s:15:"application/rtf";s:6:"plural";s:15:"application/rtf";s:6:"filter";i:0;s:6:"upload";i:1;}s:2:"js";a:5:{s:4:"mime";s:22:"application/javascript";s:8:"singular";s:22:"application/javascript";s:6:"plural";s:22:"application/javascript";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"pdf";a:5:{s:4:"mime";s:15:"application/pdf";s:8:"singular";s:15:"application/pdf";s:6:"plural";s:15:"application/pdf";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"swf";a:5:{s:4:"mime";s:29:"application/x-shockwave-flash";s:8:"singular";s:29:"application/x-shockwave-flash";s:6:"plural";s:29:"application/x-shockwave-flash";s:6:"filter";i:0;s:6:"upload";i:0;}s:5:"class";a:5:{s:4:"mime";s:16:"application/java";s:8:"singular";s:16:"application/java";s:6:"plural";s:16:"application/java";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"tar";a:5:{s:4:"mime";s:17:"application/x-tar";s:8:"singular";s:17:"application/x-tar";s:6:"plural";s:17:"application/x-tar";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"zip";a:5:{s:4:"mime";s:15:"application/zip";s:8:"singular";s:15:"application/zip";s:6:"plural";s:15:"application/zip";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"gz|gzip";a:5:{s:4:"mime";s:18:"application/x-gzip";s:8:"singular";s:18:"application/x-gzip";s:6:"plural";s:18:"application/x-gzip";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"rar";a:5:{s:4:"mime";s:15:"application/rar";s:8:"singular";s:15:"application/rar";s:6:"plural";s:15:"application/rar";s:6:"filter";i:0;s:6:"upload";i:1;}s:2:"7z";a:5:{s:4:"mime";s:27:"application/x-7z-compressed";s:8:"singular";s:27:"application/x-7z-compressed";s:6:"plural";s:27:"application/x-7z-compressed";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"exe";a:5:{s:4:"mime";s:24:"application/x-msdownload";s:8:"singular";s:24:"application/x-msdownload";s:6:"plural";s:24:"application/x-msdownload";s:6:"filter";i:0;s:6:"upload";i:0;}s:3:"psd";a:5:{s:4:"mime";s:24:"application/octet-stream";s:8:"singular";s:24:"application/octet-stream";s:6:"plural";s:24:"application/octet-stream";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"xcf";a:5:{s:4:"mime";s:24:"application/octet-stream";s:8:"singular";s:24:"application/octet-stream";s:6:"plural";s:24:"application/octet-stream";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"doc";a:5:{s:4:"mime";s:18:"application/msword";s:8:"singular";s:18:"application/msword";s:6:"plural";s:18:"application/msword";s:6:"filter";i:0;s:6:"upload";i:1;}s:11:"pot|pps|ppt";a:5:{s:4:"mime";s:29:"application/vnd.ms-powerpoint";s:8:"singular";s:29:"application/vnd.ms-powerpoint";s:6:"plural";s:29:"application/vnd.ms-powerpoint";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wri";a:5:{s:4:"mime";s:24:"application/vnd.ms-write";s:8:"singular";s:24:"application/vnd.ms-write";s:6:"plural";s:24:"application/vnd.ms-write";s:6:"filter";i:0;s:6:"upload";i:1;}s:15:"xla|xls|xlt|xlw";a:5:{s:4:"mime";s:24:"application/vnd.ms-excel";s:8:"singular";s:24:"application/vnd.ms-excel";s:6:"plural";s:24:"application/vnd.ms-excel";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mdb";a:5:{s:4:"mime";s:25:"application/vnd.ms-access";s:8:"singular";s:25:"application/vnd.ms-access";s:6:"plural";s:25:"application/vnd.ms-access";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mpp";a:5:{s:4:"mime";s:26:"application/vnd.ms-project";s:8:"singular";s:26:"application/vnd.ms-project";s:6:"plural";s:26:"application/vnd.ms-project";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"docx";a:5:{s:4:"mime";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.document";s:8:"singular";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.document";s:6:"plural";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.document";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"docm";a:5:{s:4:"mime";s:48:"application/vnd.ms-word.document.macroEnabled.12";s:8:"singular";s:48:"application/vnd.ms-word.document.macroEnabled.12";s:6:"plural";s:48:"application/vnd.ms-word.document.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"dotx";a:5:{s:4:"mime";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.template";s:8:"singular";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.template";s:6:"plural";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.template";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"dotm";a:5:{s:4:"mime";s:48:"application/vnd.ms-word.template.macroEnabled.12";s:8:"singular";s:48:"application/vnd.ms-word.template.macroEnabled.12";s:6:"plural";s:48:"application/vnd.ms-word.template.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlsx";a:5:{s:4:"mime";s:65:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";s:8:"singular";s:65:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";s:6:"plural";s:65:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlsm";a:5:{s:4:"mime";s:46:"application/vnd.ms-excel.sheet.macroEnabled.12";s:8:"singular";s:46:"application/vnd.ms-excel.sheet.macroEnabled.12";s:6:"plural";s:46:"application/vnd.ms-excel.sheet.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlsb";a:5:{s:4:"mime";s:53:"application/vnd.ms-excel.sheet.binary.macroEnabled.12";s:8:"singular";s:53:"application/vnd.ms-excel.sheet.binary.macroEnabled.12";s:6:"plural";s:53:"application/vnd.ms-excel.sheet.binary.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xltx";a:5:{s:4:"mime";s:68:"application/vnd.openxmlformats-officedocument.spreadsheetml.template";s:8:"singular";s:68:"application/vnd.openxmlformats-officedocument.spreadsheetml.template";s:6:"plural";s:68:"application/vnd.openxmlformats-officedocument.spreadsheetml.template";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xltm";a:5:{s:4:"mime";s:49:"application/vnd.ms-excel.template.macroEnabled.12";s:8:"singular";s:49:"application/vnd.ms-excel.template.macroEnabled.12";s:6:"plural";s:49:"application/vnd.ms-excel.template.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlam";a:5:{s:4:"mime";s:46:"application/vnd.ms-excel.addin.macroEnabled.12";s:8:"singular";s:46:"application/vnd.ms-excel.addin.macroEnabled.12";s:6:"plural";s:46:"application/vnd.ms-excel.addin.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"pptx";a:5:{s:4:"mime";s:73:"application/vnd.openxmlformats-officedocument.presentationml.presentation";s:8:"singular";s:73:"application/vnd.openxmlformats-officedocument.presentationml.presentation";s:6:"plural";s:73:"application/vnd.openxmlformats-officedocument.presentationml.presentation";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"pptm";a:5:{s:4:"mime";s:58:"application/vnd.ms-powerpoint.presentation.macroEnabled.12";s:8:"singular";s:58:"application/vnd.ms-powerpoint.presentation.macroEnabled.12";s:6:"plural";s:58:"application/vnd.ms-powerpoint.presentation.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"ppsx";a:5:{s:4:"mime";s:70:"application/vnd.openxmlformats-officedocument.presentationml.slideshow";s:8:"singular";s:70:"application/vnd.openxmlformats-officedocument.presentationml.slideshow";s:6:"plural";s:70:"application/vnd.openxmlformats-officedocument.presentationml.slideshow";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"ppsm";a:5:{s:4:"mime";s:55:"application/vnd.ms-powerpoint.slideshow.macroEnabled.12";s:8:"singular";s:55:"application/vnd.ms-powerpoint.slideshow.macroEnabled.12";s:6:"plural";s:55:"application/vnd.ms-powerpoint.slideshow.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"potx";a:5:{s:4:"mime";s:69:"application/vnd.openxmlformats-officedocument.presentationml.template";s:8:"singular";s:69:"application/vnd.openxmlformats-officedocument.presentationml.template";s:6:"plural";s:69:"application/vnd.openxmlformats-officedocument.presentationml.template";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"potm";a:5:{s:4:"mime";s:54:"application/vnd.ms-powerpoint.template.macroEnabled.12";s:8:"singular";s:54:"application/vnd.ms-powerpoint.template.macroEnabled.12";s:6:"plural";s:54:"application/vnd.ms-powerpoint.template.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"ppam";a:5:{s:4:"mime";s:51:"application/vnd.ms-powerpoint.addin.macroEnabled.12";s:8:"singular";s:51:"application/vnd.ms-powerpoint.addin.macroEnabled.12";s:6:"plural";s:51:"application/vnd.ms-powerpoint.addin.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"sldx";a:5:{s:4:"mime";s:66:"application/vnd.openxmlformats-officedocument.presentationml.slide";s:8:"singular";s:66:"application/vnd.openxmlformats-officedocument.presentationml.slide";s:6:"plural";s:66:"application/vnd.openxmlformats-officedocument.presentationml.slide";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"sldm";a:5:{s:4:"mime";s:51:"application/vnd.ms-powerpoint.slide.macroEnabled.12";s:8:"singular";s:51:"application/vnd.ms-powerpoint.slide.macroEnabled.12";s:6:"plural";s:51:"application/vnd.ms-powerpoint.slide.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:28:"onetoc|onetoc2|onetmp|onepkg";a:5:{s:4:"mime";s:19:"application/onenote";s:8:"singular";s:19:"application/onenote";s:6:"plural";s:19:"application/onenote";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"oxps";a:5:{s:4:"mime";s:16:"application/oxps";s:8:"singular";s:16:"application/oxps";s:6:"plural";s:16:"application/oxps";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"xps";a:5:{s:4:"mime";s:30:"application/vnd.ms-xpsdocument";s:8:"singular";s:30:"application/vnd.ms-xpsdocument";s:6:"plural";s:30:"application/vnd.ms-xpsdocument";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odt";a:5:{s:4:"mime";s:39:"application/vnd.oasis.opendocument.text";s:8:"singular";s:39:"application/vnd.oasis.opendocument.text";s:6:"plural";s:39:"application/vnd.oasis.opendocument.text";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odp";a:5:{s:4:"mime";s:47:"application/vnd.oasis.opendocument.presentation";s:8:"singular";s:47:"application/vnd.oasis.opendocument.presentation";s:6:"plural";s:47:"application/vnd.oasis.opendocument.presentation";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ods";a:5:{s:4:"mime";s:46:"application/vnd.oasis.opendocument.spreadsheet";s:8:"singular";s:46:"application/vnd.oasis.opendocument.spreadsheet";s:6:"plural";s:46:"application/vnd.oasis.opendocument.spreadsheet";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odg";a:5:{s:4:"mime";s:43:"application/vnd.oasis.opendocument.graphics";s:8:"singular";s:43:"application/vnd.oasis.opendocument.graphics";s:6:"plural";s:43:"application/vnd.oasis.opendocument.graphics";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odc";a:5:{s:4:"mime";s:40:"application/vnd.oasis.opendocument.chart";s:8:"singular";s:40:"application/vnd.oasis.opendocument.chart";s:6:"plural";s:40:"application/vnd.oasis.opendocument.chart";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odb";a:5:{s:4:"mime";s:43:"application/vnd.oasis.opendocument.database";s:8:"singular";s:43:"application/vnd.oasis.opendocument.database";s:6:"plural";s:43:"application/vnd.oasis.opendocument.database";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odf";a:5:{s:4:"mime";s:42:"application/vnd.oasis.opendocument.formula";s:8:"singular";s:42:"application/vnd.oasis.opendocument.formula";s:6:"plural";s:42:"application/vnd.oasis.opendocument.formula";s:6:"filter";i:0;s:6:"upload";i:1;}s:6:"wp|wpd";a:5:{s:4:"mime";s:23:"application/wordperfect";s:8:"singular";s:23:"application/wordperfect";s:6:"plural";s:23:"application/wordperfect";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"key";a:5:{s:4:"mime";s:29:"application/vnd.apple.keynote";s:8:"singular";s:29:"application/vnd.apple.keynote";s:6:"plural";s:29:"application/vnd.apple.keynote";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"numbers";a:5:{s:4:"mime";s:29:"application/vnd.apple.numbers";s:8:"singular";s:29:"application/vnd.apple.numbers";s:6:"plural";s:29:"application/vnd.apple.numbers";s:6:"filter";i:0;s:6:"upload";i:1;}s:5:"pages";a:5:{s:4:"mime";s:27:"application/vnd.apple.pages";s:8:"singular";s:27:"application/vnd.apple.pages";s:6:"plural";s:27:"application/vnd.apple.pages";s:6:"filter";i:0;s:6:"upload";i:1;}}', 'yes'),
(260, 'wpuxss_eml_taxonomies', 'a:4:{s:14:"media_category";a:12:{s:9:"eml_media";i:1;s:12:"hierarchical";i:1;s:12:"show_in_rest";i:0;s:4:"sort";i:0;s:17:"show_admin_column";i:1;s:17:"show_in_nav_menus";i:1;s:7:"rewrite";a:2:{s:10:"with_front";i:1;s:4:"slug";s:14:"media_category";}s:8:"assigned";i:0;s:12:"admin_filter";i:1;s:21:"media_uploader_filter";i:1;s:25:"media_popup_taxonomy_edit";i:1;s:6:"labels";a:11:{s:13:"singular_name";s:14:"Media Category";s:4:"name";s:16:"Media Categories";s:9:"menu_name";s:16:"Media Categories";s:9:"all_items";s:20:"All Media Categories";s:9:"edit_item";s:19:"Edit Media Category";s:9:"view_item";s:19:"View Media Category";s:11:"update_item";s:21:"Update Media Category";s:12:"add_new_item";s:22:"Add New Media Category";s:13:"new_item_name";s:23:"New Media Category Name";s:11:"parent_item";s:21:"Parent Media Category";s:12:"search_items";s:23:"Search Media Categories";}}s:16:"university_logos";a:12:{s:9:"eml_media";i:1;s:12:"hierarchical";i:1;s:12:"show_in_rest";i:0;s:4:"sort";i:0;s:17:"show_admin_column";i:1;s:17:"show_in_nav_menus";i:0;s:7:"rewrite";a:2:{s:10:"with_front";i:1;s:4:"slug";s:16:"university_logos";}s:8:"assigned";i:1;s:12:"admin_filter";i:1;s:21:"media_uploader_filter";i:1;s:25:"media_popup_taxonomy_edit";i:1;s:6:"labels";a:11:{s:13:"singular_name";s:16:"University logos";s:4:"name";s:16:"University logos";s:9:"menu_name";s:16:"University logos";s:9:"all_items";s:20:"All University logos";s:9:"edit_item";s:21:"Edit University logos";s:9:"view_item";s:21:"View University logos";s:11:"update_item";s:23:"Update University logos";s:12:"add_new_item";s:24:"Add New University logos";s:13:"new_item_name";s:20:"New University logos";s:11:"parent_item";s:23:"Parent University logos";s:12:"search_items";s:23:"Search University logos";}}s:8:"category";a:6:{s:9:"eml_media";i:0;s:20:"taxonomy_auto_assign";i:0;s:8:"assigned";i:1;s:12:"admin_filter";i:0;s:21:"media_uploader_filter";i:0;s:25:"media_popup_taxonomy_edit";i:0;}s:8:"post_tag";a:6:{s:9:"eml_media";i:0;s:20:"taxonomy_auto_assign";i:0;s:8:"assigned";i:0;s:12:"admin_filter";i:0;s:21:"media_uploader_filter";i:0;s:25:"media_popup_taxonomy_edit";i:0;}}', 'yes'),
(261, 'wpuxss_eml_lib_options', 'a:3:{s:24:"enhance_media_shortcodes";i:0;s:13:"media_orderby";s:4:"date";s:11:"media_order";s:4:"DESC";}', 'yes'),
(262, 'wpuxss_eml_tax_options', 'a:4:{s:12:"tax_archives";i:1;s:24:"edit_all_as_hierarchical";i:1;s:13:"force_filters";i:0;s:10:"show_count";i:1;}', 'yes'),
(263, 'wpuxss_eml_mimes', 'a:90:{s:12:"jpg|jpeg|jpe";a:5:{s:4:"mime";s:10:"image/jpeg";s:8:"singular";s:10:"image/jpeg";s:6:"plural";s:10:"image/jpeg";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"gif";a:5:{s:4:"mime";s:9:"image/gif";s:8:"singular";s:9:"image/gif";s:6:"plural";s:9:"image/gif";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"png";a:5:{s:4:"mime";s:9:"image/png";s:8:"singular";s:9:"image/png";s:6:"plural";s:9:"image/png";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"bmp";a:5:{s:4:"mime";s:9:"image/bmp";s:8:"singular";s:9:"image/bmp";s:6:"plural";s:9:"image/bmp";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"tiff|tif";a:5:{s:4:"mime";s:10:"image/tiff";s:8:"singular";s:10:"image/tiff";s:6:"plural";s:10:"image/tiff";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ico";a:5:{s:4:"mime";s:12:"image/x-icon";s:8:"singular";s:12:"image/x-icon";s:6:"plural";s:12:"image/x-icon";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"asf|asx";a:5:{s:4:"mime";s:14:"video/x-ms-asf";s:8:"singular";s:14:"video/x-ms-asf";s:6:"plural";s:14:"video/x-ms-asf";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wmv";a:5:{s:4:"mime";s:14:"video/x-ms-wmv";s:8:"singular";s:14:"video/x-ms-wmv";s:6:"plural";s:14:"video/x-ms-wmv";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wmx";a:5:{s:4:"mime";s:14:"video/x-ms-wmx";s:8:"singular";s:14:"video/x-ms-wmx";s:6:"plural";s:14:"video/x-ms-wmx";s:6:"filter";i:0;s:6:"upload";i:1;}s:2:"wm";a:5:{s:4:"mime";s:13:"video/x-ms-wm";s:8:"singular";s:13:"video/x-ms-wm";s:6:"plural";s:13:"video/x-ms-wm";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"avi";a:5:{s:4:"mime";s:9:"video/avi";s:8:"singular";s:9:"video/avi";s:6:"plural";s:9:"video/avi";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"divx";a:5:{s:4:"mime";s:10:"video/divx";s:8:"singular";s:10:"video/divx";s:6:"plural";s:10:"video/divx";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"flv";a:5:{s:4:"mime";s:11:"video/x-flv";s:8:"singular";s:11:"video/x-flv";s:6:"plural";s:11:"video/x-flv";s:6:"filter";i:0;s:6:"upload";i:1;}s:6:"mov|qt";a:5:{s:4:"mime";s:15:"video/quicktime";s:8:"singular";s:15:"video/quicktime";s:6:"plural";s:15:"video/quicktime";s:6:"filter";i:0;s:6:"upload";i:1;}s:12:"mpeg|mpg|mpe";a:5:{s:4:"mime";s:10:"video/mpeg";s:8:"singular";s:10:"video/mpeg";s:6:"plural";s:10:"video/mpeg";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"mp4|m4v";a:5:{s:4:"mime";s:9:"video/mp4";s:8:"singular";s:9:"video/mp4";s:6:"plural";s:9:"video/mp4";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ogv";a:5:{s:4:"mime";s:9:"video/ogg";s:8:"singular";s:9:"video/ogg";s:6:"plural";s:9:"video/ogg";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"webm";a:5:{s:4:"mime";s:10:"video/webm";s:8:"singular";s:10:"video/webm";s:6:"plural";s:10:"video/webm";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mkv";a:5:{s:4:"mime";s:16:"video/x-matroska";s:8:"singular";s:16:"video/x-matroska";s:6:"plural";s:16:"video/x-matroska";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"3gp|3gpp";a:5:{s:4:"mime";s:10:"video/3gpp";s:8:"singular";s:10:"video/3gpp";s:6:"plural";s:10:"video/3gpp";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"3g2|3gp2";a:5:{s:4:"mime";s:11:"video/3gpp2";s:8:"singular";s:11:"video/3gpp2";s:6:"plural";s:11:"video/3gpp2";s:6:"filter";i:0;s:6:"upload";i:1;}s:18:"txt|asc|c|cc|h|srt";a:5:{s:4:"mime";s:10:"text/plain";s:8:"singular";s:10:"text/plain";s:6:"plural";s:10:"text/plain";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"csv";a:5:{s:4:"mime";s:8:"text/csv";s:8:"singular";s:8:"text/csv";s:6:"plural";s:8:"text/csv";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"tsv";a:5:{s:4:"mime";s:25:"text/tab-separated-values";s:8:"singular";s:25:"text/tab-separated-values";s:6:"plural";s:25:"text/tab-separated-values";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ics";a:5:{s:4:"mime";s:13:"text/calendar";s:8:"singular";s:13:"text/calendar";s:6:"plural";s:13:"text/calendar";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"rtx";a:5:{s:4:"mime";s:13:"text/richtext";s:8:"singular";s:13:"text/richtext";s:6:"plural";s:13:"text/richtext";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"css";a:5:{s:4:"mime";s:8:"text/css";s:8:"singular";s:8:"text/css";s:6:"plural";s:8:"text/css";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"htm|html";a:5:{s:4:"mime";s:9:"text/html";s:8:"singular";s:9:"text/html";s:6:"plural";s:9:"text/html";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"vtt";a:5:{s:4:"mime";s:8:"text/vtt";s:8:"singular";s:8:"text/vtt";s:6:"plural";s:8:"text/vtt";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"dfxp";a:5:{s:4:"mime";s:20:"application/ttaf+xml";s:8:"singular";s:20:"application/ttaf+xml";s:6:"plural";s:20:"application/ttaf+xml";s:6:"filter";i:0;s:6:"upload";i:1;}s:11:"mp3|m4a|m4b";a:5:{s:4:"mime";s:10:"audio/mpeg";s:8:"singular";s:10:"audio/mpeg";s:6:"plural";s:10:"audio/mpeg";s:6:"filter";i:0;s:6:"upload";i:1;}s:6:"ra|ram";a:5:{s:4:"mime";s:17:"audio/x-realaudio";s:8:"singular";s:17:"audio/x-realaudio";s:6:"plural";s:17:"audio/x-realaudio";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wav";a:5:{s:4:"mime";s:9:"audio/wav";s:8:"singular";s:9:"audio/wav";s:6:"plural";s:9:"audio/wav";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"ogg|oga";a:5:{s:4:"mime";s:9:"audio/ogg";s:8:"singular";s:9:"audio/ogg";s:6:"plural";s:9:"audio/ogg";s:6:"filter";i:0;s:6:"upload";i:1;}s:8:"mid|midi";a:5:{s:4:"mime";s:10:"audio/midi";s:8:"singular";s:10:"audio/midi";s:6:"plural";s:10:"audio/midi";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wma";a:5:{s:4:"mime";s:14:"audio/x-ms-wma";s:8:"singular";s:14:"audio/x-ms-wma";s:6:"plural";s:14:"audio/x-ms-wma";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wax";a:5:{s:4:"mime";s:14:"audio/x-ms-wax";s:8:"singular";s:14:"audio/x-ms-wax";s:6:"plural";s:14:"audio/x-ms-wax";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mka";a:5:{s:4:"mime";s:16:"audio/x-matroska";s:8:"singular";s:16:"audio/x-matroska";s:6:"plural";s:16:"audio/x-matroska";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"rtf";a:5:{s:4:"mime";s:15:"application/rtf";s:8:"singular";s:15:"application/rtf";s:6:"plural";s:15:"application/rtf";s:6:"filter";i:0;s:6:"upload";i:1;}s:2:"js";a:5:{s:4:"mime";s:22:"application/javascript";s:8:"singular";s:22:"application/javascript";s:6:"plural";s:22:"application/javascript";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"pdf";a:5:{s:4:"mime";s:15:"application/pdf";s:8:"singular";s:3:"PDF";s:6:"plural";s:4:"PDFs";s:6:"filter";i:1;s:6:"upload";i:1;}s:3:"swf";a:5:{s:4:"mime";s:29:"application/x-shockwave-flash";s:8:"singular";s:29:"application/x-shockwave-flash";s:6:"plural";s:29:"application/x-shockwave-flash";s:6:"filter";i:0;s:6:"upload";i:0;}s:5:"class";a:5:{s:4:"mime";s:16:"application/java";s:8:"singular";s:16:"application/java";s:6:"plural";s:16:"application/java";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"tar";a:5:{s:4:"mime";s:17:"application/x-tar";s:8:"singular";s:17:"application/x-tar";s:6:"plural";s:17:"application/x-tar";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"zip";a:5:{s:4:"mime";s:15:"application/zip";s:8:"singular";s:15:"application/zip";s:6:"plural";s:15:"application/zip";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"gz|gzip";a:5:{s:4:"mime";s:18:"application/x-gzip";s:8:"singular";s:18:"application/x-gzip";s:6:"plural";s:18:"application/x-gzip";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"rar";a:5:{s:4:"mime";s:15:"application/rar";s:8:"singular";s:15:"application/rar";s:6:"plural";s:15:"application/rar";s:6:"filter";i:0;s:6:"upload";i:1;}s:2:"7z";a:5:{s:4:"mime";s:27:"application/x-7z-compressed";s:8:"singular";s:27:"application/x-7z-compressed";s:6:"plural";s:27:"application/x-7z-compressed";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"exe";a:5:{s:4:"mime";s:24:"application/x-msdownload";s:8:"singular";s:24:"application/x-msdownload";s:6:"plural";s:24:"application/x-msdownload";s:6:"filter";i:0;s:6:"upload";i:0;}s:3:"psd";a:5:{s:4:"mime";s:24:"application/octet-stream";s:8:"singular";s:24:"application/octet-stream";s:6:"plural";s:24:"application/octet-stream";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"xcf";a:5:{s:4:"mime";s:24:"application/octet-stream";s:8:"singular";s:24:"application/octet-stream";s:6:"plural";s:24:"application/octet-stream";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"doc";a:5:{s:4:"mime";s:18:"application/msword";s:8:"singular";s:18:"application/msword";s:6:"plural";s:18:"application/msword";s:6:"filter";i:0;s:6:"upload";i:1;}s:11:"pot|pps|ppt";a:5:{s:4:"mime";s:29:"application/vnd.ms-powerpoint";s:8:"singular";s:29:"application/vnd.ms-powerpoint";s:6:"plural";s:29:"application/vnd.ms-powerpoint";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"wri";a:5:{s:4:"mime";s:24:"application/vnd.ms-write";s:8:"singular";s:24:"application/vnd.ms-write";s:6:"plural";s:24:"application/vnd.ms-write";s:6:"filter";i:0;s:6:"upload";i:1;}s:15:"xla|xls|xlt|xlw";a:5:{s:4:"mime";s:24:"application/vnd.ms-excel";s:8:"singular";s:24:"application/vnd.ms-excel";s:6:"plural";s:24:"application/vnd.ms-excel";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mdb";a:5:{s:4:"mime";s:25:"application/vnd.ms-access";s:8:"singular";s:25:"application/vnd.ms-access";s:6:"plural";s:25:"application/vnd.ms-access";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"mpp";a:5:{s:4:"mime";s:26:"application/vnd.ms-project";s:8:"singular";s:26:"application/vnd.ms-project";s:6:"plural";s:26:"application/vnd.ms-project";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"docx";a:5:{s:4:"mime";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.document";s:8:"singular";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.document";s:6:"plural";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.document";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"docm";a:5:{s:4:"mime";s:48:"application/vnd.ms-word.document.macroEnabled.12";s:8:"singular";s:48:"application/vnd.ms-word.document.macroEnabled.12";s:6:"plural";s:48:"application/vnd.ms-word.document.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"dotx";a:5:{s:4:"mime";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.template";s:8:"singular";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.template";s:6:"plural";s:71:"application/vnd.openxmlformats-officedocument.wordprocessingml.template";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"dotm";a:5:{s:4:"mime";s:48:"application/vnd.ms-word.template.macroEnabled.12";s:8:"singular";s:48:"application/vnd.ms-word.template.macroEnabled.12";s:6:"plural";s:48:"application/vnd.ms-word.template.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlsx";a:5:{s:4:"mime";s:65:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";s:8:"singular";s:65:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";s:6:"plural";s:65:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlsm";a:5:{s:4:"mime";s:46:"application/vnd.ms-excel.sheet.macroEnabled.12";s:8:"singular";s:46:"application/vnd.ms-excel.sheet.macroEnabled.12";s:6:"plural";s:46:"application/vnd.ms-excel.sheet.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlsb";a:5:{s:4:"mime";s:53:"application/vnd.ms-excel.sheet.binary.macroEnabled.12";s:8:"singular";s:53:"application/vnd.ms-excel.sheet.binary.macroEnabled.12";s:6:"plural";s:53:"application/vnd.ms-excel.sheet.binary.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xltx";a:5:{s:4:"mime";s:68:"application/vnd.openxmlformats-officedocument.spreadsheetml.template";s:8:"singular";s:68:"application/vnd.openxmlformats-officedocument.spreadsheetml.template";s:6:"plural";s:68:"application/vnd.openxmlformats-officedocument.spreadsheetml.template";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xltm";a:5:{s:4:"mime";s:49:"application/vnd.ms-excel.template.macroEnabled.12";s:8:"singular";s:49:"application/vnd.ms-excel.template.macroEnabled.12";s:6:"plural";s:49:"application/vnd.ms-excel.template.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"xlam";a:5:{s:4:"mime";s:46:"application/vnd.ms-excel.addin.macroEnabled.12";s:8:"singular";s:46:"application/vnd.ms-excel.addin.macroEnabled.12";s:6:"plural";s:46:"application/vnd.ms-excel.addin.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"pptx";a:5:{s:4:"mime";s:73:"application/vnd.openxmlformats-officedocument.presentationml.presentation";s:8:"singular";s:73:"application/vnd.openxmlformats-officedocument.presentationml.presentation";s:6:"plural";s:73:"application/vnd.openxmlformats-officedocument.presentationml.presentation";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"pptm";a:5:{s:4:"mime";s:58:"application/vnd.ms-powerpoint.presentation.macroEnabled.12";s:8:"singular";s:58:"application/vnd.ms-powerpoint.presentation.macroEnabled.12";s:6:"plural";s:58:"application/vnd.ms-powerpoint.presentation.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"ppsx";a:5:{s:4:"mime";s:70:"application/vnd.openxmlformats-officedocument.presentationml.slideshow";s:8:"singular";s:70:"application/vnd.openxmlformats-officedocument.presentationml.slideshow";s:6:"plural";s:70:"application/vnd.openxmlformats-officedocument.presentationml.slideshow";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"ppsm";a:5:{s:4:"mime";s:55:"application/vnd.ms-powerpoint.slideshow.macroEnabled.12";s:8:"singular";s:55:"application/vnd.ms-powerpoint.slideshow.macroEnabled.12";s:6:"plural";s:55:"application/vnd.ms-powerpoint.slideshow.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"potx";a:5:{s:4:"mime";s:69:"application/vnd.openxmlformats-officedocument.presentationml.template";s:8:"singular";s:69:"application/vnd.openxmlformats-officedocument.presentationml.template";s:6:"plural";s:69:"application/vnd.openxmlformats-officedocument.presentationml.template";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"potm";a:5:{s:4:"mime";s:54:"application/vnd.ms-powerpoint.template.macroEnabled.12";s:8:"singular";s:54:"application/vnd.ms-powerpoint.template.macroEnabled.12";s:6:"plural";s:54:"application/vnd.ms-powerpoint.template.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"ppam";a:5:{s:4:"mime";s:51:"application/vnd.ms-powerpoint.addin.macroEnabled.12";s:8:"singular";s:51:"application/vnd.ms-powerpoint.addin.macroEnabled.12";s:6:"plural";s:51:"application/vnd.ms-powerpoint.addin.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"sldx";a:5:{s:4:"mime";s:66:"application/vnd.openxmlformats-officedocument.presentationml.slide";s:8:"singular";s:66:"application/vnd.openxmlformats-officedocument.presentationml.slide";s:6:"plural";s:66:"application/vnd.openxmlformats-officedocument.presentationml.slide";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"sldm";a:5:{s:4:"mime";s:51:"application/vnd.ms-powerpoint.slide.macroEnabled.12";s:8:"singular";s:51:"application/vnd.ms-powerpoint.slide.macroEnabled.12";s:6:"plural";s:51:"application/vnd.ms-powerpoint.slide.macroEnabled.12";s:6:"filter";i:0;s:6:"upload";i:1;}s:28:"onetoc|onetoc2|onetmp|onepkg";a:5:{s:4:"mime";s:19:"application/onenote";s:8:"singular";s:19:"application/onenote";s:6:"plural";s:19:"application/onenote";s:6:"filter";i:0;s:6:"upload";i:1;}s:4:"oxps";a:5:{s:4:"mime";s:16:"application/oxps";s:8:"singular";s:16:"application/oxps";s:6:"plural";s:16:"application/oxps";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"xps";a:5:{s:4:"mime";s:30:"application/vnd.ms-xpsdocument";s:8:"singular";s:30:"application/vnd.ms-xpsdocument";s:6:"plural";s:30:"application/vnd.ms-xpsdocument";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odt";a:5:{s:4:"mime";s:39:"application/vnd.oasis.opendocument.text";s:8:"singular";s:39:"application/vnd.oasis.opendocument.text";s:6:"plural";s:39:"application/vnd.oasis.opendocument.text";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odp";a:5:{s:4:"mime";s:47:"application/vnd.oasis.opendocument.presentation";s:8:"singular";s:47:"application/vnd.oasis.opendocument.presentation";s:6:"plural";s:47:"application/vnd.oasis.opendocument.presentation";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"ods";a:5:{s:4:"mime";s:46:"application/vnd.oasis.opendocument.spreadsheet";s:8:"singular";s:46:"application/vnd.oasis.opendocument.spreadsheet";s:6:"plural";s:46:"application/vnd.oasis.opendocument.spreadsheet";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odg";a:5:{s:4:"mime";s:43:"application/vnd.oasis.opendocument.graphics";s:8:"singular";s:43:"application/vnd.oasis.opendocument.graphics";s:6:"plural";s:43:"application/vnd.oasis.opendocument.graphics";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odc";a:5:{s:4:"mime";s:40:"application/vnd.oasis.opendocument.chart";s:8:"singular";s:40:"application/vnd.oasis.opendocument.chart";s:6:"plural";s:40:"application/vnd.oasis.opendocument.chart";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odb";a:5:{s:4:"mime";s:43:"application/vnd.oasis.opendocument.database";s:8:"singular";s:43:"application/vnd.oasis.opendocument.database";s:6:"plural";s:43:"application/vnd.oasis.opendocument.database";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"odf";a:5:{s:4:"mime";s:42:"application/vnd.oasis.opendocument.formula";s:8:"singular";s:42:"application/vnd.oasis.opendocument.formula";s:6:"plural";s:42:"application/vnd.oasis.opendocument.formula";s:6:"filter";i:0;s:6:"upload";i:1;}s:6:"wp|wpd";a:5:{s:4:"mime";s:23:"application/wordperfect";s:8:"singular";s:23:"application/wordperfect";s:6:"plural";s:23:"application/wordperfect";s:6:"filter";i:0;s:6:"upload";i:1;}s:3:"key";a:5:{s:4:"mime";s:29:"application/vnd.apple.keynote";s:8:"singular";s:29:"application/vnd.apple.keynote";s:6:"plural";s:29:"application/vnd.apple.keynote";s:6:"filter";i:0;s:6:"upload";i:1;}s:7:"numbers";a:5:{s:4:"mime";s:29:"application/vnd.apple.numbers";s:8:"singular";s:29:"application/vnd.apple.numbers";s:6:"plural";s:29:"application/vnd.apple.numbers";s:6:"filter";i:0;s:6:"upload";i:1;}s:5:"pages";a:5:{s:4:"mime";s:27:"application/vnd.apple.pages";s:8:"singular";s:27:"application/vnd.apple.pages";s:6:"plural";s:27:"application/vnd.apple.pages";s:6:"filter";i:0;s:6:"upload";i:1;}}', 'yes'),
(283, 'widget_p2p', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(284, 'p2p_storage', '4', 'yes'),
(332, 'options_title', 'Awards for Host Students.', 'no'),
(333, '_options_title', 'field_57b19630ada62', 'no'),
(334, 'options_description', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\r\n\r\nExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'no'),
(335, '_options_description', 'field_57b19643f86e0', 'no'),
(336, 'options_award_logos', '6', 'no'),
(337, '_options_award_logos', 'field_57b19542cb44d', 'no'),
(338, 'options_award_logos_0_title', 'Quality mark - International accomodation', 'no'),
(339, '_options_award_logos_0_title', 'field_57b195d7cb44f', 'no'),
(340, 'options_award_logos_0_logo', '32', 'no'),
(341, '_options_award_logos_0_logo', 'field_57b195adcb44e', 'no'),
(342, 'options_award_logos_1_title', '2015 Best - Individual Accomodation', 'no'),
(343, '_options_award_logos_1_title', 'field_57b195d7cb44f', 'no'),
(344, 'options_award_logos_1_logo', '33', 'no'),
(345, '_options_award_logos_1_logo', 'field_57b195adcb44e', 'no'),
(346, 'options_award_logos_2_title', '2015 Best - Individual Accomodation', 'no'),
(347, '_options_award_logos_2_title', 'field_57b195d7cb44f', 'no'),
(348, 'options_award_logos_2_logo', '37', 'no'),
(349, '_options_award_logos_2_logo', 'field_57b195adcb44e', 'no'),
(350, 'options_award_logos_3_title', 'Quality mark - International accomodation', 'no'),
(351, '_options_award_logos_3_title', 'field_57b195d7cb44f', 'no'),
(352, 'options_award_logos_3_logo', '36', 'no'),
(353, '_options_award_logos_3_logo', 'field_57b195adcb44e', 'no'),
(354, 'options_award_logos_4_title', '2015 Best - Value for Money', 'no'),
(355, '_options_award_logos_4_title', 'field_57b195d7cb44f', 'no'),
(356, 'options_award_logos_4_logo', '34', 'no'),
(357, '_options_award_logos_4_logo', 'field_57b195adcb44e', 'no'),
(358, 'options_award_logos_5_title', '2015 Best - Value for Money', 'no'),
(359, '_options_award_logos_5_title', 'field_57b195d7cb44f', 'no'),
(360, 'options_award_logos_5_logo', '35', 'no'),
(361, '_options_award_logos_5_logo', 'field_57b195adcb44e', 'no'),
(364, 'WPLANG', 'en_GB', 'yes'),
(371, 'options_awards_title', 'Awards for Host Students.', 'no'),
(372, '_options_awards_title', 'field_57b19630ada62', 'no'),
(373, 'options_awards_description', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\r\n\r\nExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'no'),
(374, '_options_awards_description', 'field_57b19643f86e0', 'no'),
(408, 'db_upgraded', '', 'yes'),
(413, 'can_compress_scripts', '0', 'no'),
(418, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TmpVNE5qTjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMUxURXdMVEEySURFMU9qQTFPakkyIjtzOjM6InVybCI7czoxNToiaHR0cDovL2hvc3QuZGV2Ijt9', 'yes'),
(450, 'category_children', 'a:0:{}', 'yes'),
(451, 'options_title_1', 'Where your pennies', 'no'),
(452, '_options_title_1', 'field_57bf021ca4ff8', 'no'),
(453, 'options_title_2', 'are being spent.', 'no'),
(454, '_options_title_2', 'field_57bf0228a4ff9', 'no'),
(455, 'options_content_1', '<strong>Electricity</strong>\r\nOur rents are inclusive of electricity consumption up to the value of £300 per room. Statements are issued monthly and should your share of the charges incurred by the flat exceed this allowance you will be required to make an additional payment for additional electricity consumed.\r\n\r\n<strong>Payments</strong>\r\nCredit/Debit Card - Please complete the attached credit/debit card instruction for automatic payment of rent from your credit/debit card account. Payments which are not received in full on the due date will be subject to a daily interest charge on the outstanding amount which is calculated at 4% above the base rate of Lloyds Bank plc. Please note that we do not accept cheques', 'no'),
(456, '_options_content_1', 'field_57bf0235a4ffa', 'no'),
(457, 'options_content_2', '<strong>International Students</strong>\r\nAll non-UK students are normally required to pay the rent in full on booking. Please include this payment when making your booking. We are now able to offer a monthly payment option utilising the Housing Hand Guarantor scheme.\r\n\r\n<strong>Internet</strong>\r\nBroadband Internet is provided in every bedroom. Wi-Fi is available throughout the hall.\r\n\r\n<strong>Guarantor</strong>\r\nA guarantor is required to observe or perform the applicant’s tenancy obligations. The attached guarantor form needs to be completed by the guarantor, witnessed by an independent adult and returned to Victoria Hall Management UK Ltd along with 2 true and accurate documents confirming the guarantor’s UK residence (Passport, Utility Bill,Bank Statement or Driving Licence), and full time employment, or retired and in receipt of aprivate pension.', 'no'),
(458, '_options_content_2', 'field_57bf024ca4ffb', 'no'),
(459, 'options_content_3', '<strong>Contents Insurance</strong>\r\nContents insurance is included within the rent for each of our students. Full details of this policy can be found at www.endsleigh.co.uk/reviewcover\r\n\r\n<strong>Telephone System</strong>\r\nA direct dial telephone is provided free of charge in each flat hallway. Call credit and access PIN are provided by our third party company, Ask4.\r\n\r\n<strong>Smoking</strong>\r\nSmoking is not permitted in any areas within Victoria Hall including bedrooms, lounges and courtyard areas.', 'no'),
(460, '_options_content_3', 'field_57bf0254a4ffc', 'no'),
(465, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(506, 'GTranslate', 'a:13:{s:11:"pro_version";s:0:"";s:18:"enterprise_version";s:0:"";s:10:"new_window";s:0:"";s:9:"analytics";s:0:"";s:11:"load_jquery";s:0:"";s:12:"add_new_line";i:1;s:16:"default_language";s:2:"en";s:18:"translation_method";s:5:"onfly";s:11:"widget_look";s:8:"dropdown";s:9:"flag_size";i:16;s:11:"widget_code";s:5729:"<!-- GTranslate: https://gtranslate.io/ -->\r\n <select onchange="doGTranslate(this);"><option value="">Select Language</option><option value="en|af">Afrikaans</option><option value="en|sq">Albanian</option><option value="en|am">Amharic</option><option value="en|ar">Arabic</option><option value="en|hy">Armenian</option><option value="en|az">Azerbaijani</option><option value="en|eu">Basque</option><option value="en|be">Belarusian</option><option value="en|bn">Bengali</option><option value="en|bs">Bosnian</option><option value="en|bg">Bulgarian</option><option value="en|ca">Catalan</option><option value="en|ceb">Cebuano</option><option value="en|ny">Chichewa</option><option value="en|zh-CN">Chinese (Simplified)</option><option value="en|zh-TW">Chinese (Traditional)</option><option value="en|co">Corsican</option><option value="en|hr">Croatian</option><option value="en|cs">Czech</option><option value="en|da">Danish</option><option value="en|nl">Dutch</option><option value="en|en">English</option><option value="en|eo">Esperanto</option><option value="en|et">Estonian</option><option value="en|tl">Filipino</option><option value="en|fi">Finnish</option><option value="en|fr">French</option><option value="en|fy">Frisian</option><option value="en|gl">Galician</option><option value="en|ka">Georgian</option><option value="en|de">German</option><option value="en|el">Greek</option><option value="en|gu">Gujarati</option><option value="en|ht">Haitian Creole</option><option value="en|ha">Hausa</option><option value="en|haw">Hawaiian</option><option value="en|iw">Hebrew</option><option value="en|hi">Hindi</option><option value="en|hmn">Hmong</option><option value="en|hu">Hungarian</option><option value="en|is">Icelandic</option><option value="en|ig">Igbo</option><option value="en|id">Indonesian</option><option value="en|ga">Irish</option><option value="en|it">Italian</option><option value="en|ja">Japanese</option><option value="en|jw">Javanese</option><option value="en|kn">Kannada</option><option value="en|kk">Kazakh</option><option value="en|km">Khmer</option><option value="en|ko">Korean</option><option value="en|ku">Kurdish (Kurmanji)</option><option value="en|ky">Kyrgyz</option><option value="en|lo">Lao</option><option value="en|la">Latin</option><option value="en|lv">Latvian</option><option value="en|lt">Lithuanian</option><option value="en|lb">Luxembourgish</option><option value="en|mk">Macedonian</option><option value="en|mg">Malagasy</option><option value="en|ms">Malay</option><option value="en|ml">Malayalam</option><option value="en|mt">Maltese</option><option value="en|mi">Maori</option><option value="en|mr">Marathi</option><option value="en|mn">Mongolian</option><option value="en|my">Myanmar (Burmese)</option><option value="en|ne">Nepali</option><option value="en|no">Norwegian</option><option value="en|ps">Pashto</option><option value="en|fa">Persian</option><option value="en|pl">Polish</option><option value="en|pt">Portuguese</option><option value="en|pa">Punjabi</option><option value="en|ro">Romanian</option><option value="en|ru">Russian</option><option value="en|sm">Samoan</option><option value="en|gd">Scottish Gaelic</option><option value="en|sr">Serbian</option><option value="en|st">Sesotho</option><option value="en|sn">Shona</option><option value="en|sd">Sindhi</option><option value="en|si">Sinhala</option><option value="en|sk">Slovak</option><option value="en|sl">Slovenian</option><option value="en|so">Somali</option><option value="en|es">Spanish</option><option value="en|su">Sudanese</option><option value="en|sw">Swahili</option><option value="en|sv">Swedish</option><option value="en|tg">Tajik</option><option value="en|ta">Tamil</option><option value="en|te">Telugu</option><option value="en|th">Thai</option><option value="en|tr">Turkish</option><option value="en|uk">Ukrainian</option><option value="en|ur">Urdu</option><option value="en|uz">Uzbek</option><option value="en|vi">Vietnamese</option><option value="en|cy">Welsh</option><option value="en|xh">Xhosa</option><option value="en|yi">Yiddish</option><option value="en|yo">Yoruba</option><option value="en|zu">Zulu</option></select><style type="text/css">\r\n<!--\r\n#goog-gt-tt {display:none !important;}\r\n.goog-te-banner-frame {display:none !important;}\r\n.goog-te-menu-value:hover {text-decoration:none !important;}\r\nbody {top:0 !important;}\r\n#google_translate_element2 {display:none!important;}\r\n-->\r\n</style>\r\n\r\n<div id="google_translate_element2"></div>\r\n<script type="text/javascript">\r\nfunction googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: \'en\',autoDisplay: false}, \'google_translate_element2\');}\r\n</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>\r\n\r\n\r\n<script type="text/javascript">\r\nfunction GTranslateFireEvent(element,event){try{if(document.createEventObject){var evt=document.createEventObject();element.fireEvent(\'on\'+event,evt)}else{var evt=document.createEvent(\'HTMLEvents\');evt.initEvent(event,true,true);element.dispatchEvent(evt)}}catch(e){}}function doGTranslate(lang_pair){if(lang_pair.value)lang_pair=lang_pair.value;if(lang_pair==\'\')return;var lang=lang_pair.split(\'|\')[1];var teCombo;var sel=document.getElementsByTagName(\'select\');for(var i=0;i<sel.length;i++)if(sel[i].className==\'goog-te-combo\')teCombo=sel[i];if(document.getElementById(\'google_translate_element2\')==null||document.getElementById(\'google_translate_element2\').innerHTML.length==0||teCombo.length==0||teCombo.innerHTML.length==0){setTimeout(function(){doGTranslate(lang_pair)},500)}else{teCombo.value=lang;GTranslateFireEvent(teCombo,\'change\');GTranslateFireEvent(teCombo,\'change\')}}\r\n</script>\r\n";s:10:"incl_langs";a:104:{i:0;s:2:"af";i:1;s:2:"sq";i:2;s:2:"am";i:3;s:2:"ar";i:4;s:2:"hy";i:5;s:2:"az";i:6;s:2:"eu";i:7;s:2:"be";i:8;s:2:"bn";i:9;s:2:"bs";i:10;s:2:"bg";i:11;s:2:"ca";i:12;s:3:"ceb";i:13;s:2:"ny";i:14;s:5:"zh-CN";i:15;s:5:"zh-TW";i:16;s:2:"co";i:17;s:2:"hr";i:18;s:2:"cs";i:19;s:2:"da";i:20;s:2:"nl";i:21;s:2:"en";i:22;s:2:"eo";i:23;s:2:"et";i:24;s:2:"tl";i:25;s:2:"fi";i:26;s:2:"fr";i:27;s:2:"fy";i:28;s:2:"gl";i:29;s:2:"ka";i:30;s:2:"de";i:31;s:2:"el";i:32;s:2:"gu";i:33;s:2:"ht";i:34;s:2:"ha";i:35;s:3:"haw";i:36;s:2:"iw";i:37;s:2:"hi";i:38;s:3:"hmn";i:39;s:2:"hu";i:40;s:2:"is";i:41;s:2:"ig";i:42;s:2:"id";i:43;s:2:"ga";i:44;s:2:"it";i:45;s:2:"ja";i:46;s:2:"jw";i:47;s:2:"kn";i:48;s:2:"kk";i:49;s:2:"km";i:50;s:2:"ko";i:51;s:2:"ku";i:52;s:2:"ky";i:53;s:2:"lo";i:54;s:2:"la";i:55;s:2:"lv";i:56;s:2:"lt";i:57;s:2:"lb";i:58;s:2:"mk";i:59;s:2:"mg";i:60;s:2:"ms";i:61;s:2:"ml";i:62;s:2:"mt";i:63;s:2:"mi";i:64;s:2:"mr";i:65;s:2:"mn";i:66;s:2:"my";i:67;s:2:"ne";i:68;s:2:"no";i:69;s:2:"ps";i:70;s:2:"fa";i:71;s:2:"pl";i:72;s:2:"pt";i:73;s:2:"pa";i:74;s:2:"ro";i:75;s:2:"ru";i:76;s:2:"sm";i:77;s:2:"gd";i:78;s:2:"sr";i:79;s:2:"st";i:80;s:2:"sn";i:81;s:2:"sd";i:82;s:2:"si";i:83;s:2:"sk";i:84;s:2:"sl";i:85;s:2:"so";i:86;s:2:"es";i:87;s:2:"su";i:88;s:2:"sw";i:89;s:2:"sv";i:90;s:2:"tg";i:91;s:2:"ta";i:92;s:2:"te";i:93;s:2:"th";i:94;s:2:"tr";i:95;s:2:"uk";i:96;s:2:"ur";i:97;s:2:"uz";i:98;s:2:"vi";i:99;s:2:"cy";i:100;s:2:"xh";i:101;s:2:"yi";i:102;s:2:"yo";i:103;s:2:"zu";}s:11:"fincl_langs";a:7:{i:0;s:2:"en";i:1;s:2:"fr";i:2;s:2:"de";i:3;s:2:"it";i:4;s:2:"pt";i:5;s:2:"ru";i:6;s:2:"es";}}', 'yes'),
(507, 'gtranslate_admin_notice', 'a:2:{s:15:"two_week_review";a:2:{s:5:"start";s:8:"9/4/2016";s:3:"int";i:3;}s:12:"upgrade_tips";a:3:{s:5:"start";s:8:"9/2/2016";s:3:"int";i:1;s:9:"dismissed";i:1;}}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_p2p`
#

DROP TABLE IF EXISTS `wp_p2p`;


#
# Table structure of table `wp_p2p`
#

CREATE TABLE `wp_p2p` (
  `p2p_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p2p_from` bigint(20) unsigned NOT NULL,
  `p2p_to` bigint(20) unsigned NOT NULL,
  `p2p_type` varchar(44) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`p2p_id`),
  KEY `p2p_from` (`p2p_from`),
  KEY `p2p_to` (`p2p_to`),
  KEY `p2p_type` (`p2p_type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_p2p`
#
INSERT INTO `wp_p2p` ( `p2p_id`, `p2p_from`, `p2p_to`, `p2p_type`) VALUES
(4, 12, 9, 'uni_to_location'),
(5, 17, 9, 'building_to_location'),
(6, 17, 12, 'building_to_uni'),
(8, 20, 17, 'room_to_building'),
(9, 19, 17, 'room_to_building'),
(11, 48, 9, 'building_to_location'),
(12, 48, 12, 'building_to_uni'),
(13, 18, 48, 'room_to_building') ;

#
# End of data contents of table `wp_p2p`
# --------------------------------------------------------



#
# Delete any existing table `wp_p2pmeta`
#

DROP TABLE IF EXISTS `wp_p2pmeta`;


#
# Table structure of table `wp_p2pmeta`
#

CREATE TABLE `wp_p2pmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p2p_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `p2p_id` (`p2p_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_p2pmeta`
#

#
# End of data contents of table `wp_p2pmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=641 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(5, 6, '_edit_last', '1'),
(6, 6, '_edit_lock', '1470997058:1'),
(9, 8, '_wp_attached_file', '2016/08/ual-logo-1360.png'),
(10, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1360;s:6:"height";i:400;s:4:"file";s:25:"2016/08/ual-logo-1360.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"ual-logo-1360-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"ual-logo-1360-300x88.png";s:5:"width";i:300;s:6:"height";i:88;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:25:"ual-logo-1360-768x226.png";s:5:"width";i:768;s:6:"height";i:226;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:26:"ual-logo-1360-1024x301.png";s:5:"width";i:1024;s:6:"height";i:301;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(11, 6, '_thumbnail_id', '8'),
(12, 9, '_edit_last', '1'),
(13, 9, '_edit_lock', '1472743170:1'),
(14, 12, '_edit_last', '1'),
(15, 12, '_edit_lock', '1472208131:1'),
(16, 12, '_thumbnail_id', '8'),
(17, 18, '_edit_last', '1'),
(18, 18, '_edit_lock', '1472805297:1'),
(19, 19, '_edit_last', '1'),
(20, 19, '_edit_lock', '1472729452:1'),
(21, 20, '_edit_last', '1'),
(22, 20, '_edit_lock', '1472125922:1'),
(23, 17, '_edit_last', '1'),
(24, 17, '_edit_lock', '1472739870:1'),
(25, 21, '_edit_last', '1'),
(26, 21, '_edit_lock', '1472136208:1'),
(27, 12, 'title', 'Your closest home:'),
(28, 12, '_title', 'field_57b19337aad91'),
(29, 12, 'description', 'Victoria Hall boasts unrivaled locations with our halls located minutes from University campuses and close to town centre attractions and nightlife.\r\n\r\nFor those who prefer more independant living, someof our locations offer studio apartments with the same fantastic facilities provided in our shared flats.'),
(30, 12, '_description', 'field_57b19346aad92'),
(31, 12, 'select_building', '17'),
(32, 12, '_select_building', 'field_57b192592a494'),
(33, 25, '_edit_last', '1'),
(34, 25, '_edit_lock', '1471268005:1'),
(35, 32, '_wp_attached_file', '2016/08/Award_1.png'),
(36, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:123;s:6:"height";i:123;s:4:"file";s:19:"2016/08/Award_1.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(37, 33, '_wp_attached_file', '2016/08/Award_2.png'),
(38, 33, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:123;s:6:"height";i:123;s:4:"file";s:19:"2016/08/Award_2.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(39, 34, '_wp_attached_file', '2016/08/Award_3.png'),
(40, 34, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:123;s:6:"height";i:123;s:4:"file";s:19:"2016/08/Award_3.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(41, 35, '_wp_attached_file', '2016/08/Award_4.png'),
(42, 35, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:123;s:6:"height";i:123;s:4:"file";s:19:"2016/08/Award_4.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(43, 36, '_wp_attached_file', '2016/08/Award_5.png'),
(44, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:123;s:6:"height";i:123;s:4:"file";s:19:"2016/08/Award_5.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(45, 37, '_wp_attached_file', '2016/08/Award_6.png'),
(46, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:123;s:6:"height";i:123;s:4:"file";s:19:"2016/08/Award_6.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(47, 39, '_edit_last', '1'),
(48, 39, '_edit_lock', '1472742514:1'),
(49, 48, '_edit_last', '1'),
(50, 48, '_edit_lock', '1472739830:1'),
(51, 48, 'building_address_1', '25 Canal Reach'),
(52, 48, '_building_address_1', 'field_57b2f7287a9c9'),
(53, 48, 'building_address_2', ''),
(54, 48, '_building_address_2', 'field_57b3088f7a9ca'),
(55, 48, 'building_address_town_city', 'London'),
(56, 48, '_building_address_town_city', 'field_57b3089e7a9cb'),
(57, 48, 'building_address_post_code', 'N1C 4DD'),
(58, 48, '_building_address_post_code', 'field_57b308be7a9cc'),
(59, 48, 'building_address_phone_no', '020 3475 5980'),
(60, 48, '_building_address_phone_no', 'field_57b308ed7a9cd'),
(61, 48, 'building_address_longitude', '51.4619432'),
(62, 48, '_building_address_longitude', 'field_57b30964c687b'),
(63, 48, 'building_address_latitude', '-0.8022603'),
(64, 48, '_building_address_latitude', 'field_57b30991c687c'),
(65, 48, 'facilities_title', 'Our facilities at a glance.'),
(66, 48, '_facilities_title', 'field_57b30d00567c9'),
(67, 48, 'facilities_overview', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam porta sem malesuada magna mollis euismod.'),
(68, 48, '_facilities_overview', 'field_57b30c2ebdda7'),
(69, 48, 'facilities_list_0_icon', 'ruleset.xml'),
(70, 48, '_facilities_list_0_icon', 'field_57b30c55bdda9'),
(71, 48, 'facilities_list_0_description', '24/7 Security, caretakers & CCTV cameras'),
(72, 48, '_facilities_list_0_description', 'field_57b30ce5bddaa'),
(73, 48, 'facilities_list_1_icon', ''),
(74, 48, '_facilities_list_1_icon', 'field_57b30c55bdda9'),
(75, 48, 'facilities_list_1_description', 'Reading room for quiet study'),
(76, 48, '_facilities_list_1_description', 'field_57b30ce5bddaa'),
(77, 48, 'facilities_list_2_icon', ''),
(78, 48, '_facilities_list_2_icon', 'field_57b30c55bdda9'),
(79, 48, 'facilities_list_2_description', 'Common room with large TV and seating'),
(80, 48, '_facilities_list_2_description', 'field_57b30ce5bddaa'),
(81, 48, 'facilities_list_3_icon', ''),
(82, 48, '_facilities_list_3_icon', 'field_57b30c55bdda9'),
(83, 48, 'facilities_list_3_description', 'Gym with cardio equipment & weights'),
(84, 48, '_facilities_list_3_description', 'field_57b30ce5bddaa'),
(85, 48, 'facilities_list_4_icon', ''),
(86, 48, '_facilities_list_4_icon', 'field_57b30c55bdda9'),
(87, 48, 'facilities_list_4_description', 'Bicycle parking with plenty of spaces'),
(88, 48, '_facilities_list_4_description', 'field_57b30ce5bddaa'),
(89, 48, 'facilities_list_5_icon', ''),
(90, 48, '_facilities_list_5_icon', 'field_57b30c55bdda9'),
(91, 48, 'facilities_list_5_description', 'Laundry room with washing & ironing facilities'),
(92, 48, '_facilities_list_5_description', 'field_57b30ce5bddaa'),
(93, 48, 'facilities_list', '6'),
(94, 48, '_facilities_list', 'field_57b30c41bdda8'),
(95, 58, '_wp_attached_file', '2016/08/facilities_1.png'),
(96, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:655;s:6:"height";i:658;s:4:"file";s:24:"2016/08/facilities_1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"facilities_1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"facilities_1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(97, 59, '_wp_attached_file', '2016/08/facilities_2.png'),
(98, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:655;s:6:"height";i:658;s:4:"file";s:24:"2016/08/facilities_2.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"facilities_2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"facilities_2-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(99, 48, 'facilities_photos_0_photo', '58'),
(100, 48, '_facilities_photos_0_photo', 'field_57b574287f432'),
(101, 48, 'facilities_photos_1_photo', '59'),
(102, 48, '_facilities_photos_1_photo', 'field_57b574287f432'),
(103, 48, 'facilities_photos', '2'),
(104, 48, '_facilities_photos', 'field_57b5741b7f431'),
(105, 65, '_wp_attached_file', '2016/08/staff.jpg'),
(106, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:659;s:6:"height";i:659;s:4:"file";s:17:"2016/08/staff.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"staff-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"staff-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(107, 48, 'people_title', 'Our people. Your Hosts.'),
(108, 48, '_people_title', 'field_57b575c9c8ea2'),
(109, 48, 'people_description', 'Donec ullamcorper nulla non metus auctor fringilla. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Curabitur blandit tempus porttitor. Aenean eu leo quam.\r\n\r\nPellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Etiam porta sem malesuada magna mollis euismod. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Donec ullamcorper.'),
(110, 48, '_people_description', 'field_57b575e6c8ea3'),
(111, 48, 'people_photos_0_photo', '65'),
(112, 48, '_people_photos_0_photo', 'field_57b57603c8ea5'),
(113, 48, 'people_photos', '1'),
(114, 48, '_people_photos', 'field_57b57603c8ea4'),
(115, 48, 'location_title', 'The location. What\'s it like?'),
(116, 48, '_location_title', 'field_57b577f6299ad'),
(117, 48, 'location_description', '<strong>Address:</strong>\r\nHost King’s Cross, 25-27, Canal Reach, London, N1C 4DD\r\n\r\nSituated near the city centre within easy walking distance ofthe uni’s as well as the shopping areas and nightlife of CamdenTown. It’s close to the river and King’s Cross train station.'),
(118, 48, '_location_description', 'field_57b57813299ae'),
(119, 48, 'points_of_interest_0_title', '1. University of Arts London.'),
(120, 48, '_points_of_interest_0_title', 'field_57b58b0286ca7'),
(121, 48, 'points_of_interest_0_transport_time', '5 mins'),
(122, 48, '_points_of_interest_0_transport_time', 'field_57b58b3786ca9'),
(123, 48, 'points_of_interest_0_walking_time', '10 mins'),
(124, 48, '_points_of_interest_0_walking_time', 'field_57b58b5286caa'),
(125, 48, 'points_of_interest_1_title', '2. University of London.'),
(126, 48, '_points_of_interest_1_title', 'field_57b58b0286ca7'),
(127, 48, 'points_of_interest_1_transport_time', '10 mins'),
(128, 48, '_points_of_interest_1_transport_time', 'field_57b58b3786ca9'),
(129, 48, 'points_of_interest_1_walking_time', '15 mins'),
(130, 48, '_points_of_interest_1_walking_time', 'field_57b58b5286caa'),
(131, 48, 'points_of_interest', '2'),
(132, 48, '_points_of_interest', 'field_57b58abd86ca6'),
(133, 48, 'title_1', 'King\'s Cross student home.'),
(134, 48, '_title_1', 'field_57b59095da7aa'),
(135, 48, 'title_2', 'Stylish, friendly & secure.'),
(136, 48, '_title_2', 'field_57b590a3da7ab'),
(137, 48, 'description', 'King’s Cross is the ideal location for students. A short walk away is the British Library and Central Saint Martins, part of the University of the Arts London. City University, UCL, SOAS and University of Westminster are all close by. Whether you are an international or UK-based student, Victoria Hall King’s Cross is the perfect choice. It’s a place where you can feel at home and be safe with first class facilities to help you enjoy your student life.'),
(138, 48, '_description', 'field_57b590b1da7ac'),
(139, 48, 'links__downloads', '2'),
(140, 48, '_links__downloads', 'field_57b590d8da7ad'),
(141, 48, 'links__downloads_0_button_text', 'Like to book a viewing?'),
(142, 48, '_links__downloads_0_button_text', 'field_57b590ebda7ae'),
(143, 48, 'links__downloads_0_link', 'http://www.host-students.com/'),
(144, 48, '_links__downloads_0_link', 'field_57b59108da7af'),
(145, 48, 'links__downloads_1_button_text', 'Info & application booklet'),
(146, 48, '_links__downloads_1_button_text', 'field_57b590ebda7ae'),
(147, 48, 'links__downloads_1_link', 'http://www.host-students.com/'),
(148, 48, '_links__downloads_1_link', 'field_57b59108da7af'),
(149, 83, '_wp_attached_file', '2016/08/kings-cross.jpg'),
(150, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1326;s:6:"height";i:673;s:4:"file";s:23:"2016/08/kings-cross.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"kings-cross-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"kings-cross-300x152.jpg";s:5:"width";i:300;s:6:"height";i:152;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"kings-cross-768x390.jpg";s:5:"width";i:768;s:6:"height";i:390;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"kings-cross-1024x520.jpg";s:5:"width";i:1024;s:6:"height";i:520;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(151, 48, 'links_downloads_0_button_text', 'Like to book a viewing?'),
(152, 48, '_links_downloads_0_button_text', 'field_57b590ebda7ae'),
(153, 48, 'links_downloads_0_link', 'http://www.host-students.com/'),
(154, 48, '_links_downloads_0_link', 'field_57b59108da7af'),
(155, 48, 'links_downloads_1_button_text', 'Info & application booklet'),
(156, 48, '_links_downloads_1_button_text', 'field_57b590ebda7ae'),
(157, 48, 'links_downloads_1_link', 'http://www.host-students.com/'),
(158, 48, '_links_downloads_1_link', 'field_57b59108da7af'),
(159, 48, 'links_downloads', '2'),
(160, 48, '_links_downloads', 'field_57b590d8da7ad'),
(161, 48, 'carousel_images_0_image', '83'),
(162, 48, '_carousel_images_0_image', 'field_57b5926945124'),
(163, 48, 'carousel_images', 'a:2:{i:0;s:2:"83";i:1;s:3:"149";}'),
(164, 48, '_carousel_images', 'field_57c8133c281d9'),
(165, 85, '_edit_lock', '1472743804:1'),
(166, 85, '_edit_last', '1'),
(167, 141, '_edit_last', '1'),
(168, 141, '_edit_lock', '1472136191:1'),
(169, 149, '_wp_attached_file', '2016/08/room_placeholder.jpg'),
(170, 149, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1366;s:6:"height";i:670;s:4:"file";s:28:"2016/08/room_placeholder.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"room_placeholder-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"room_placeholder-300x147.jpg";s:5:"width";i:300;s:6:"height";i:147;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"room_placeholder-768x377.jpg";s:5:"width";i:768;s:6:"height";i:377;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"room_placeholder-1024x502.jpg";s:5:"width";i:1024;s:6:"height";i:502;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(171, 18, 'availability', 'available'),
(172, 18, '_availability', 'field_57bf04c843a01'),
(173, 18, 'availability_description', '2 rooms remaining.'),
(174, 18, '_availability_description', 'field_57bedc06c20aa'),
(175, 18, 'from_amount', '£412pw.'),
(176, 18, '_from_amount', 'field_57bedc06c2102'),
(177, 18, 'description', 'We believe that smart, large, well-designed rooms boost learning power. And that’s what Victoria Hall King\'s Cross is all about – giving you the best, so you can achieve your best.  A far cry from the dark corridors and dorms of student accommodation of old, the hallways and entrance spaces in Victoria Hall King\'s Cross have all been designed to make the most of natural light, helping all the flats and studios feel luxurious and modern.'),
(178, 18, '_description', 'field_57bedc06c2157'),
(179, 18, 'links_downloads_0_button_text', 'Info & application booklet'),
(180, 18, '_links_downloads_0_button_text', 'field_57bedc06cfa1d'),
(181, 18, 'links_downloads_0_link', 'http://www.google.com/'),
(182, 18, '_links_downloads_0_link', 'field_57bedc06cfa77'),
(183, 18, 'links_downloads_1_button_text', 'Show the room floorplan'),
(184, 18, '_links_downloads_1_button_text', 'field_57bedc06cfa1d'),
(185, 18, 'links_downloads_1_link', 'http://www.yahoo.com/'),
(186, 18, '_links_downloads_1_link', 'field_57bedc06cfa77'),
(187, 18, 'links_downloads', '2'),
(188, 18, '_links_downloads', 'field_57bedc06c21ae'),
(189, 18, 'carousel_images_0_image', '149'),
(190, 18, '_carousel_images_0_image', 'field_57bedc06d8ffc'),
(191, 18, 'carousel_images', 'a:3:{i:0;s:3:"211";i:1;s:3:"149";i:2;s:2:"83";}'),
(192, 18, '_carousel_images', 'field_57c8133c281d9'),
(193, 18, 'living_space', '5'),
(194, 18, '_living_space', 'field_57bedcedf0eea'),
(195, 18, 'the_amenities', '3'),
(196, 18, '_the_amenities', 'field_57bedd500a7a5'),
(197, 18, 'facilities_title', ''),
(198, 18, '_facilities_title', 'field_57bedc06c2847'),
(199, 18, 'facilities_overview', ''),
(200, 18, '_facilities_overview', 'field_57bedc06c2905'),
(201, 18, 'facilities_list', ''),
(202, 18, '_facilities_list', 'field_57bedc06c2a34'),
(203, 18, 'facilities_photos', ''),
(204, 18, '_facilities_photos', 'field_57bedc06c2b8d'),
(205, 18, 'number_of_weeks', '43'),
(206, 18, '_number_of_weeks', 'field_57befd73e6def') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(207, 18, 'date_range', '(17 Sept 2016 - 14 July 2017)'),
(208, 18, '_date_range', 'field_57befe01e6df0'),
(209, 18, 'price_per_week', '£175pw'),
(210, 18, '_price_per_week', 'field_57befeafe6df1'),
(211, 18, 'payment_plans', '3'),
(212, 18, '_payment_plans', 'field_57beffb6e6df2'),
(213, 18, 'cancellation_policy', ''),
(214, 18, '_cancellation_policy', 'field_57bf00b22e455'),
(215, 18, 'location_title', 'The location. What’s it like?'),
(216, 18, '_location_title', 'field_57bedc06c2ccf'),
(217, 18, 'location_description', '<strong>Address:</strong>\r\nHost King’s Cross, 25-27, Canal Reach, London, N1C 4DD\r\n\r\nSituated near the city centre within easy walking distance of the universities as well as the shopping areas and nightlife of Camden Town. It’s close to the river andKing’s Cross train station.'),
(218, 18, '_location_description', 'field_57bedc06c2d5e'),
(219, 18, 'points_of_interest', '2'),
(220, 18, '_points_of_interest', 'field_57bedc06c2e35'),
(221, 18, 'living_space_0_icon', ''),
(222, 18, '_living_space_0_icon', 'field_57bedcedf0eeb'),
(223, 18, 'living_space_0_name', 'Bed'),
(224, 18, '_living_space_0_name', 'field_57bedd26f0eed'),
(225, 18, 'living_space_0_description', '1 double bed'),
(226, 18, '_living_space_0_description', 'field_57bedcedf0eec'),
(227, 18, 'living_space_1_icon', ''),
(228, 18, '_living_space_1_icon', 'field_57bedcedf0eeb'),
(229, 18, 'living_space_1_name', 'Studying'),
(230, 18, '_living_space_1_name', 'field_57bedd26f0eed'),
(231, 18, 'living_space_1_description', 'Large desk and chair'),
(232, 18, '_living_space_1_description', 'field_57bedcedf0eec'),
(233, 18, 'living_space_2_icon', ''),
(234, 18, '_living_space_2_icon', 'field_57bedcedf0eeb'),
(235, 18, 'living_space_2_name', 'Storage'),
(236, 18, '_living_space_2_name', 'field_57bedd26f0eed'),
(237, 18, 'living_space_2_description', 'Large wardrobe'),
(238, 18, '_living_space_2_description', 'field_57bedcedf0eec'),
(239, 18, 'living_space_3_icon', ''),
(240, 18, '_living_space_3_icon', 'field_57bedcedf0eeb'),
(241, 18, 'living_space_3_name', 'Bed'),
(242, 18, '_living_space_3_name', 'field_57bedd26f0eed'),
(243, 18, 'living_space_3_description', '1 double bed'),
(244, 18, '_living_space_3_description', 'field_57bedcedf0eec'),
(245, 18, 'living_space_4_icon', ''),
(246, 18, '_living_space_4_icon', 'field_57bedcedf0eeb'),
(247, 18, 'living_space_4_name', 'Studying'),
(248, 18, '_living_space_4_name', 'field_57bedd26f0eed'),
(249, 18, 'living_space_4_description', 'Large desk and chair'),
(250, 18, '_living_space_4_description', 'field_57bedcedf0eec'),
(251, 18, 'the_amenities_0_icon', ''),
(252, 18, '_the_amenities_0_icon', 'field_57bedd500a7a6'),
(253, 18, 'the_amenities_0_name', 'Kitchen'),
(254, 18, '_the_amenities_0_name', 'field_57bedd500a7a7'),
(255, 18, 'the_amenities_0_description', 'Open plan kitchen'),
(256, 18, '_the_amenities_0_description', 'field_57bedd500a7a8'),
(257, 18, 'the_amenities_1_icon', ''),
(258, 18, '_the_amenities_1_icon', 'field_57bedd500a7a6'),
(259, 18, 'the_amenities_1_name', 'Kitchen'),
(260, 18, '_the_amenities_1_name', 'field_57bedd500a7a7'),
(261, 18, 'the_amenities_1_description', 'Fully fitted'),
(262, 18, '_the_amenities_1_description', 'field_57bedd500a7a8'),
(263, 18, 'the_amenities_2_icon', ''),
(264, 18, '_the_amenities_2_icon', 'field_57bedd500a7a6'),
(265, 18, 'the_amenities_2_name', 'Bathroom'),
(266, 18, '_the_amenities_2_name', 'field_57bedd500a7a7'),
(267, 18, 'the_amenities_2_description', 'En suite'),
(268, 18, '_the_amenities_2_description', 'field_57bedd500a7a8'),
(269, 18, 'payment_plans_0_title', '1. Full year payment.'),
(270, 18, '_payment_plans_0_title', 'field_57beffcee6df3'),
(271, 18, 'payment_plans_0_subtitle', '(Curabitur blandit tempus porttitor)'),
(272, 18, '_payment_plans_0_subtitle', 'field_57beffe2e6df4'),
(273, 18, 'payment_plans_0_content', '<h4>£5,977.00</h4>\r\nLess 3% discount\r\n<strong>Total £5,797.69</strong>\r\n\r\n£200.00 on booking\r\n£5,597.69 on 01/08/16'),
(274, 18, '_payment_plans_0_content', 'field_57beffede6df5'),
(275, 18, '_thumbnail_id', '149'),
(276, 18, 'payment_plans_1_title', '2. Installment Plan.'),
(277, 18, '_payment_plans_1_title', 'field_57beffcee6df3'),
(278, 18, 'payment_plans_1_subtitle', '(only available with UK based guarantor) per room'),
(279, 18, '_payment_plans_1_subtitle', 'field_57beffe2e6df4'),
(280, 18, 'payment_plans_1_content', '1st Payment due on booking\r\n<h4>£200.00</h4>\r\n2nd Payment due on 1 Aug 2016\r\n<h4>£2,997.00</h4>\r\n3rd Payment due on 16 Jan 2017\r\n<h4>£2,780.00</h4>'),
(281, 18, '_payment_plans_1_content', 'field_57beffede6df5'),
(282, 18, 'payment_plans_2_title', '3. Monthly Plan.'),
(283, 18, '_payment_plans_2_title', 'field_57beffcee6df3'),
(284, 18, 'payment_plans_2_subtitle', '(via Housing Hand Guarantor Scheme only)'),
(285, 18, '_payment_plans_2_subtitle', 'field_57beffe2e6df4'),
(286, 18, 'payment_plans_2_content', '1st Payment due upon booking\r\n<h4>£200.00</h4>\r\nInitial Monthly Payment:Due on 1 Aug 2016\r\n\r\n<h4>£773.00</h4>\r\nRemaining monthly payments from1 Sept 2016 for 9 consecutive months up to and including 1 July 2017\r\n<h4>£556.00</h4>'),
(287, 18, '_payment_plans_2_content', 'field_57beffede6df5'),
(288, 18, 'points_of_interest_0_title', 'University of Arts London'),
(289, 18, '_points_of_interest_0_title', 'field_57bedc071e38b'),
(290, 18, 'points_of_interest_0_transport_time', '5 mins'),
(291, 18, '_points_of_interest_0_transport_time', 'field_57bedc071e3e7'),
(292, 18, 'points_of_interest_0_walking_time', '10 mins'),
(293, 18, '_points_of_interest_0_walking_time', 'field_57bedc071e434'),
(294, 18, 'points_of_interest_1_title', 'University of London'),
(295, 18, '_points_of_interest_1_title', 'field_57bedc071e38b'),
(296, 18, 'points_of_interest_1_transport_time', '10 mins'),
(297, 18, '_points_of_interest_1_transport_time', 'field_57bedc071e3e7'),
(298, 18, 'points_of_interest_1_walking_time', '15 mins'),
(299, 18, '_points_of_interest_1_walking_time', 'field_57bedc071e434'),
(302, 9, 'carousel', 'a:2:{i:0;s:3:"149";i:1;s:2:"83";}'),
(303, 9, '_carousel', 'field_57bf14293bf45'),
(310, 48, 'rooms_title_1', 'Need a room.'),
(311, 48, '_rooms_title_1', 'field_57c015bcbd611'),
(312, 48, 'rooms_title_2', 'Let\'s find you a place.'),
(313, 48, '_rooms_title_2', 'field_57c015dcbd612'),
(314, 48, 'rooms_description', 'All our rooms have been designed to help you make the most of your time at university. They will be ultra modern, and include lots of little luxuries like high-tech kitchens and beautiful bathrooms. All pictures are indicative as all rooms slightly vary.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(315, 48, '_rooms_description', 'field_57c015f0bd613'),
(334, 158, '_edit_last', '1'),
(335, 158, '_wp_page_template', 'default'),
(336, 158, '_edit_lock', '1472209274:1'),
(337, 160, '_edit_last', '1'),
(338, 160, '_wp_page_template', 'default'),
(339, 160, '_edit_lock', '1472570200:1'),
(340, 162, '_edit_last', '1'),
(341, 162, '_wp_page_template', 'default'),
(342, 162, '_edit_lock', '1472209301:1'),
(343, 164, '_edit_last', '1'),
(344, 164, '_wp_page_template', 'default'),
(345, 164, '_edit_lock', '1472209314:1'),
(349, 167, '_edit_last', '1'),
(350, 167, '_wp_page_template', 'default'),
(351, 167, '_edit_lock', '1472209402:1'),
(352, 169, '_edit_last', '1'),
(353, 169, '_wp_page_template', 'default'),
(354, 169, '_edit_lock', '1472211364:1'),
(355, 171, '_menu_item_type', 'post_type'),
(356, 171, '_menu_item_menu_item_parent', '0'),
(357, 171, '_menu_item_object_id', '169'),
(358, 171, '_menu_item_object', 'page'),
(359, 171, '_menu_item_target', ''),
(360, 171, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(361, 171, '_menu_item_xfn', ''),
(362, 171, '_menu_item_url', ''),
(364, 172, '_menu_item_type', 'post_type'),
(365, 172, '_menu_item_menu_item_parent', '0'),
(366, 172, '_menu_item_object_id', '164'),
(367, 172, '_menu_item_object', 'page'),
(368, 172, '_menu_item_target', ''),
(369, 172, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(370, 172, '_menu_item_xfn', ''),
(371, 172, '_menu_item_url', ''),
(373, 173, '_menu_item_type', 'post_type'),
(374, 173, '_menu_item_menu_item_parent', '0'),
(375, 173, '_menu_item_object_id', '162'),
(376, 173, '_menu_item_object', 'page'),
(377, 173, '_menu_item_target', ''),
(378, 173, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(379, 173, '_menu_item_xfn', ''),
(380, 173, '_menu_item_url', ''),
(382, 174, '_menu_item_type', 'post_type'),
(383, 174, '_menu_item_menu_item_parent', '0'),
(384, 174, '_menu_item_object_id', '160'),
(385, 174, '_menu_item_object', 'page'),
(386, 174, '_menu_item_target', ''),
(387, 174, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(388, 174, '_menu_item_xfn', ''),
(389, 174, '_menu_item_url', ''),
(391, 175, '_edit_last', '1'),
(392, 175, '_edit_lock', '1472211337:1'),
(393, 175, '_wp_page_template', 'default'),
(394, 177, '_edit_last', '1'),
(395, 177, '_edit_lock', '1472211477:1'),
(396, 177, '_wp_page_template', 'default'),
(397, 179, '_edit_last', '1'),
(398, 179, '_edit_lock', '1472211551:1'),
(399, 179, '_wp_page_template', 'default'),
(400, 181, '_edit_last', '1'),
(401, 181, '_edit_lock', '1472211617:1'),
(402, 181, '_wp_page_template', 'default'),
(403, 183, '_edit_last', '1'),
(404, 183, '_edit_lock', '1472211681:1'),
(405, 183, '_wp_page_template', 'default'),
(406, 185, '_menu_item_type', 'post_type'),
(407, 185, '_menu_item_menu_item_parent', '0'),
(408, 185, '_menu_item_object_id', '183'),
(409, 185, '_menu_item_object', 'page'),
(410, 185, '_menu_item_target', ''),
(411, 185, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(412, 185, '_menu_item_xfn', ''),
(413, 185, '_menu_item_url', ''),
(415, 186, '_menu_item_type', 'post_type'),
(416, 186, '_menu_item_menu_item_parent', '0'),
(417, 186, '_menu_item_object_id', '181'),
(418, 186, '_menu_item_object', 'page'),
(419, 186, '_menu_item_target', ''),
(420, 186, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(421, 186, '_menu_item_xfn', ''),
(422, 186, '_menu_item_url', ''),
(424, 187, '_menu_item_type', 'post_type'),
(425, 187, '_menu_item_menu_item_parent', '0'),
(426, 187, '_menu_item_object_id', '179'),
(427, 187, '_menu_item_object', 'page'),
(428, 187, '_menu_item_target', ''),
(429, 187, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(430, 187, '_menu_item_xfn', ''),
(431, 187, '_menu_item_url', ''),
(433, 188, '_menu_item_type', 'post_type'),
(434, 188, '_menu_item_menu_item_parent', '0'),
(435, 188, '_menu_item_object_id', '177'),
(436, 188, '_menu_item_object', 'page'),
(437, 188, '_menu_item_target', ''),
(438, 188, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(439, 188, '_menu_item_xfn', ''),
(440, 188, '_menu_item_url', ''),
(442, 189, '_menu_item_type', 'post_type'),
(443, 189, '_menu_item_menu_item_parent', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(444, 189, '_menu_item_object_id', '175'),
(445, 189, '_menu_item_object', 'page'),
(446, 189, '_menu_item_target', ''),
(447, 189, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(448, 189, '_menu_item_xfn', ''),
(449, 189, '_menu_item_url', ''),
(451, 190, '_menu_item_type', 'post_type'),
(452, 190, '_menu_item_menu_item_parent', '0'),
(453, 190, '_menu_item_object_id', '158'),
(454, 190, '_menu_item_object', 'page'),
(455, 190, '_menu_item_target', ''),
(456, 190, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(457, 190, '_menu_item_xfn', ''),
(458, 190, '_menu_item_url', ''),
(460, 191, '_edit_last', '1'),
(461, 191, '_edit_lock', '1472544760:1'),
(462, 191, '_wp_page_template', 'default'),
(463, 194, '_edit_last', '1'),
(464, 194, '_edit_lock', '1472545017:1'),
(465, 194, '_wp_page_template', 'default'),
(466, 196, '_edit_last', '1'),
(467, 196, '_edit_lock', '1472736747:1'),
(468, 19, 'availability', 'available'),
(469, 19, '_availability', 'field_57bf04c843a01'),
(470, 19, 'availability_description', ''),
(471, 19, '_availability_description', 'field_57bedc06c20aa'),
(472, 19, 'from_amount', ''),
(473, 19, '_from_amount', 'field_57bedc06c2102'),
(474, 19, 'description', ''),
(475, 19, '_description', 'field_57bedc06c2157'),
(476, 19, 'links_downloads', ''),
(477, 19, '_links_downloads', 'field_57bedc06c21ae'),
(478, 19, 'living_space', ''),
(479, 19, '_living_space', 'field_57bedcedf0eea'),
(480, 19, 'the_amenities', ''),
(481, 19, '_the_amenities', 'field_57bedd500a7a5'),
(482, 19, 'number_of_weeks', ''),
(483, 19, '_number_of_weeks', 'field_57befd73e6def'),
(484, 19, 'date_range', ''),
(485, 19, '_date_range', 'field_57befe01e6df0'),
(486, 19, 'price_per_week', ''),
(487, 19, '_price_per_week', 'field_57befeafe6df1'),
(488, 19, 'payment_plans', ''),
(489, 19, '_payment_plans', 'field_57beffb6e6df2'),
(490, 19, 'cancellation_policy', ''),
(491, 19, '_cancellation_policy', 'field_57bf00b22e455'),
(492, 19, 'location_title', ''),
(493, 19, '_location_title', 'field_57bedc06c2ccf'),
(494, 19, 'location_description', ''),
(495, 19, '_location_description', 'field_57bedc06c2d5e'),
(496, 19, 'points_of_interest', ''),
(497, 19, '_points_of_interest', 'field_57bedc06c2e35'),
(498, 19, 'carousel_images', 'a:2:{i:0;s:3:"149";i:1;s:2:"83";}'),
(499, 19, '_carousel_images', 'field_57c8133c281d9'),
(500, 198, '_edit_last', '1'),
(501, 198, '_edit_lock', '1472743627:1'),
(505, 9, 'title_1', 'London student homes'),
(506, 9, '_title_1', 'field_57c827ec458c4'),
(507, 9, 'title_2', 'to pause and relax in.'),
(508, 9, '_title_2', 'field_57c827f7458c5'),
(509, 9, 'description', 'We believe that smart, large, well-designed rooms boost learning power. And that’s what Victoria Hall King\'s Cross is all about – giving you the best, so you can achieve your best.  A far cry from the dark corridors and dorms of student accommodation of old, the hallways and entrance spaces in Victoria Hall King\'s Cross have all been designed to make the most of natural light, helping all the flats and studios feel luxurious and modern.'),
(510, 9, '_description', 'field_57c82815458c7'),
(511, 9, 'location_title', 'London! What\'s it like?'),
(512, 9, '_location_title', 'field_57c828748b040'),
(513, 9, 'location_description', '<strong>London:</strong>\r\nLorem ipsum dolor sit amet, consectetura dipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.'),
(514, 9, '_location_description', 'field_57c8288c8b041'),
(515, 9, 'things_to_do', '10'),
(516, 9, '_things_to_do', 'field_57c828aed6f1d'),
(517, 9, 'carousel_images', 'a:1:{i:0;s:3:"211";}'),
(518, 9, '_carousel_images', 'field_57c8133c281d9'),
(519, 210, '_wp_attached_file', '2016/08/london_feature.jpg'),
(520, 210, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:390;s:6:"height";i:385;s:4:"file";s:26:"2016/08/london_feature.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"london_feature-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"london_feature-300x296.jpg";s:5:"width";i:300;s:6:"height";i:296;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(521, 211, '_wp_attached_file', '2016/08/london.jpg'),
(522, 211, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1310;s:6:"height";i:670;s:4:"file";s:18:"2016/08/london.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"london-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"london-300x153.jpg";s:5:"width";i:300;s:6:"height";i:153;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"london-768x393.jpg";s:5:"width";i:768;s:6:"height";i:393;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"london-1024x524.jpg";s:5:"width";i:1024;s:6:"height";i:524;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(523, 9, '_thumbnail_id', '210'),
(524, 9, 'things_to_do_title', 'Top 10 things to do for students in London.'),
(525, 9, '_things_to_do_title', 'field_57c82b9fef965'),
(526, 9, 'things_to_do_0_item_number', 'No 1'),
(527, 9, '_things_to_do_0_item_number', 'field_57c828c1d6f1e'),
(528, 9, 'things_to_do_0_item_name', 'A guided tour of London'),
(529, 9, '_things_to_do_0_item_name', 'field_57c828e3d6f1f'),
(530, 9, 'things_to_do_1_item_number', 'No 2'),
(531, 9, '_things_to_do_1_item_number', 'field_57c828c1d6f1e'),
(532, 9, 'things_to_do_1_item_name', 'British Museum'),
(533, 9, '_things_to_do_1_item_name', 'field_57c828e3d6f1f'),
(534, 9, 'things_to_do_2_item_number', 'No 3'),
(535, 9, '_things_to_do_2_item_number', 'field_57c828c1d6f1e'),
(536, 9, 'things_to_do_2_item_name', 'National Gallery'),
(537, 9, '_things_to_do_2_item_name', 'field_57c828e3d6f1f'),
(538, 9, 'things_to_do_3_item_number', 'No 4'),
(539, 9, '_things_to_do_3_item_number', 'field_57c828c1d6f1e'),
(540, 9, 'things_to_do_3_item_name', 'V&A - Victoria and Albert Museum'),
(541, 9, '_things_to_do_3_item_name', 'field_57c828e3d6f1f'),
(542, 9, 'things_to_do_4_item_number', 'No 5'),
(543, 9, '_things_to_do_4_item_number', 'field_57c828c1d6f1e'),
(544, 9, 'things_to_do_4_item_name', 'Tower of London'),
(545, 9, '_things_to_do_4_item_name', 'field_57c828e3d6f1f'),
(546, 9, 'things_to_do_5_item_number', 'No 6'),
(547, 9, '_things_to_do_5_item_number', 'field_57c828c1d6f1e'),
(548, 9, 'things_to_do_5_item_name', 'Big Ben') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(549, 9, '_things_to_do_5_item_name', 'field_57c828e3d6f1f'),
(550, 9, 'things_to_do_6_item_number', 'No 7'),
(551, 9, '_things_to_do_6_item_number', 'field_57c828c1d6f1e'),
(552, 9, 'things_to_do_6_item_name', 'St. James\'s Park'),
(553, 9, '_things_to_do_6_item_name', 'field_57c828e3d6f1f'),
(554, 9, 'things_to_do_7_item_number', 'No 8'),
(555, 9, '_things_to_do_7_item_number', 'field_57c828c1d6f1e'),
(556, 9, 'things_to_do_7_item_name', 'Natural History Museum'),
(557, 9, '_things_to_do_7_item_name', 'field_57c828e3d6f1f'),
(558, 9, 'things_to_do_8_item_number', 'No 9'),
(559, 9, '_things_to_do_8_item_number', 'field_57c828c1d6f1e'),
(560, 9, 'things_to_do_8_item_name', 'Hyde Park'),
(561, 9, '_things_to_do_8_item_name', 'field_57c828e3d6f1f'),
(562, 9, 'things_to_do_9_item_number', 'No 10'),
(563, 9, '_things_to_do_9_item_number', 'field_57c828c1d6f1e'),
(564, 9, 'things_to_do_9_item_name', 'The London Eye'),
(565, 9, '_things_to_do_9_item_name', 'field_57c828e3d6f1f'),
(566, 213, '_wp_attached_file', '2016/08/kings_cross_feature.jpg'),
(567, 213, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:361;s:6:"height";i:344;s:4:"file";s:31:"2016/08/kings_cross_feature.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"kings_cross_feature-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"kings_cross_feature-300x286.jpg";s:5:"width";i:300;s:6:"height";i:286;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(568, 48, '_thumbnail_id', '213'),
(569, 214, '_edit_last', '1'),
(570, 214, '_edit_lock', '1472739437:1'),
(571, 48, 'external_website', ''),
(572, 48, '_external_website', 'field_57c8342cd2812'),
(573, 17, 'external_website', 'a:1:{i:0;s:8:"external";}'),
(574, 17, '_external_website', 'field_57c8342cd2812'),
(575, 17, 'website_url', 'http://www.google.com'),
(576, 17, '_website_url', 'field_57c83463d2813'),
(577, 17, 'title_1', ''),
(578, 17, '_title_1', 'field_57b59095da7aa'),
(579, 17, 'title_2', ''),
(580, 17, '_title_2', 'field_57b590a3da7ab'),
(581, 17, 'description', ''),
(582, 17, '_description', 'field_57b590b1da7ac'),
(583, 17, 'links_downloads', ''),
(584, 17, '_links_downloads', 'field_57b590d8da7ad'),
(585, 17, 'building_address_1', ''),
(586, 17, '_building_address_1', 'field_57b2f7287a9c9'),
(587, 17, 'building_address_2', ''),
(588, 17, '_building_address_2', 'field_57b3088f7a9ca'),
(589, 17, 'building_address_town_city', ''),
(590, 17, '_building_address_town_city', 'field_57b3089e7a9cb'),
(591, 17, 'building_address_post_code', ''),
(592, 17, '_building_address_post_code', 'field_57b308be7a9cc'),
(593, 17, 'building_address_phone_no', ''),
(594, 17, '_building_address_phone_no', 'field_57b308ed7a9cd'),
(595, 17, 'building_address_longitude', ''),
(596, 17, '_building_address_longitude', 'field_57b30964c687b'),
(597, 17, 'building_address_latitude', ''),
(598, 17, '_building_address_latitude', 'field_57b30991c687c'),
(599, 17, 'rooms_title_1', ''),
(600, 17, '_rooms_title_1', 'field_57c015bcbd611'),
(601, 17, 'rooms_title_2', ''),
(602, 17, '_rooms_title_2', 'field_57c015dcbd612'),
(603, 17, 'rooms_description', ''),
(604, 17, '_rooms_description', 'field_57c015f0bd613'),
(605, 17, 'facilities_title', ''),
(606, 17, '_facilities_title', 'field_57b30d00567c9'),
(607, 17, 'facilities_overview', ''),
(608, 17, '_facilities_overview', 'field_57b30c2ebdda7'),
(609, 17, 'facilities_list', ''),
(610, 17, '_facilities_list', 'field_57b30c41bdda8'),
(611, 17, 'facilities_photos', ''),
(612, 17, '_facilities_photos', 'field_57b5741b7f431'),
(613, 17, 'location_title', ''),
(614, 17, '_location_title', 'field_57b577f6299ad'),
(615, 17, 'location_description', ''),
(616, 17, '_location_description', 'field_57b57813299ae'),
(617, 17, 'points_of_interest', ''),
(618, 17, '_points_of_interest', 'field_57b58abd86ca6'),
(619, 17, 'people_title', ''),
(620, 17, '_people_title', 'field_57b575c9c8ea2'),
(621, 17, 'people_description', ''),
(622, 17, '_people_description', 'field_57b575e6c8ea3'),
(623, 17, 'people_photos', ''),
(624, 17, '_people_photos', 'field_57b57603c8ea4'),
(625, 17, 'carousel_images', ''),
(626, 17, '_carousel_images', 'field_57c8133c281d9'),
(627, 48, 'availability', 'available'),
(628, 48, '_availability', 'field_57c83af56a8ab'),
(629, 48, 'prices_from', '£285 pw.'),
(630, 48, '_prices_from', 'field_57c83bca4bd33'),
(631, 17, 'availability', 'limited'),
(632, 17, '_availability', 'field_57c83af56a8ab'),
(633, 17, 'prices_from', '£253 pw.'),
(634, 17, '_prices_from', 'field_57c83bca4bd33'),
(635, 220, '_wp_attached_file', '2016/08/london_attraction.jpg'),
(636, 220, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:289;s:6:"height";i:463;s:4:"file";s:29:"2016/08/london_attraction.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"london_attraction-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"london_attraction-187x300.jpg";s:5:"width";i:187;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(637, 9, 'things_to_do_image', '220'),
(638, 9, '_things_to_do_image', 'field_57c846edbc365'),
(639, 18, 'location_image', '220'),
(640, 18, '_location_image', 'field_57c84b4680837') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-08-09 16:23:30', '2016-08-09 16:23:30', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2016-08-09 16:23:30', '2016-08-09 16:23:30', '', 0, 'http://${HTTP_HOST}/?p=1', 0, 'post', '', 0),
(6, 1, '2016-08-11 15:26:47', '2016-08-11 15:26:47', 'University of the Arts London is Europe’s largest university specializing purely in art and design with almost 20,000 students representing over 100 countries.\r\n\r\nThe University is only 10 years old but has quickly established itself as a centre for innovation and has expanded considerably to have 6 main campuses across the City; these colleges include Camberwell College of Arts, Central Saint Martins, Chelsea College of Arts, London College of Communication, London College of Fashion, and Wimbledon College of Arts.', 'University of the arts London.', '', 'publish', 'closed', 'closed', '', 'university-of-the-arts-london', '', '', '2016-08-11 15:32:24', '2016-08-11 15:32:24', '', 0, 'http://host.dev/?post_type=universities&#038;p=6', 0, 'universities', '', 0),
(8, 1, '2016-08-11 15:31:31', '2016-08-11 15:31:31', '', 'ual-logo-1360', '', 'inherit', 'open', 'closed', '', 'ual-logo-1360', '', '', '2016-08-11 15:31:31', '2016-08-11 15:31:31', '', 6, 'http://host.dev/app/uploads/2016/08/ual-logo-1360.png', 0, 'attachment', 'image/png', 0),
(9, 1, '2016-08-12 09:49:20', '2016-08-12 09:49:20', '', 'London', '', 'publish', 'closed', 'closed', '', 'london', '', '', '2016-09-01 15:11:57', '2016-09-01 15:11:57', '', 0, 'http://host.dev/?post_type=locations&#038;p=9', 0, 'locations', '', 0),
(12, 1, '2016-08-12 10:23:23', '2016-08-12 10:23:23', 'University of the Arts London is Europe’s largest university specializing purely in art and design with almost 20,000 students representing over 100 countries.\r\n\r\nThe University is only 10 years old but has quickly established itself as a centre for innovation and has expanded considerably to have 6 main campuses across the City; these colleges include Camberwell College of Arts, Central Saint Martins, Chelsea College of Arts, London College of Communication, London College of Fashion, and Wimbledon College of Arts.', 'University of the arts London.', '', 'publish', 'closed', 'closed', '', 'university-of-the-arts-london', '', '', '2016-08-15 09:56:35', '2016-08-15 09:56:35', '', 0, 'http://host.dev/?post_type=university&#038;p=12', 0, 'university', '', 0),
(17, 1, '2016-08-12 10:45:29', '2016-08-12 10:45:29', '', 'Dashwood Studio, Southwark', '', 'publish', 'closed', 'closed', '', 'dashwood-studio-southwark', '', '', '2016-09-01 14:26:47', '2016-09-01 14:26:47', '', 0, 'http://host.dev/?post_type=buildings&#038;p=17', 0, 'buildings', '', 0),
(18, 1, '2016-08-12 10:43:02', '2016-08-12 10:43:02', '', 'King\'s Cross, Premium Studio', '', 'publish', 'closed', 'closed', '', 'kings-cross-premium-studio', '', '', '2016-09-01 15:30:27', '2016-09-01 15:30:27', '', 0, 'http://host.dev/?post_type=rooms&#038;p=18', 0, 'rooms', '', 0),
(19, 1, '2016-08-12 10:43:18', '2016-08-12 10:43:18', '', 'King\'s Cross, Large Studio', '', 'publish', 'closed', 'closed', '', 'kings-cross-large-studio', '', '', '2016-09-01 11:33:07', '2016-09-01 11:33:07', '', 0, 'http://host.dev/?post_type=rooms&#038;p=19', 0, 'rooms', '', 0),
(20, 1, '2016-08-12 10:43:34', '2016-08-12 10:43:34', '', 'King\'s Cross, En-suite Room', '', 'publish', 'closed', 'closed', '', 'kings-cross-en-suite-room', '', '', '2016-08-25 11:52:02', '2016-08-25 11:52:02', '', 0, 'http://host.dev/?post_type=rooms&#038;p=20', 0, 'rooms', '', 0),
(21, 1, '2016-08-15 09:46:04', '2016-08-15 09:46:04', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"university";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'University - Featured accomodation', 'university-featured-accomodation', 'publish', 'closed', 'closed', '', 'group_57b18f4d73a67', '', '', '2016-08-15 09:53:11', '2016-08-15 09:53:11', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=21', 0, 'acf-field-group', '', 0),
(22, 1, '2016-08-15 09:48:39', '2016-08-15 09:48:39', 'a:11:{s:4:"type";s:11:"post_object";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:9:"buildings";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:13:"return_format";s:6:"object";s:2:"ui";i:1;}', 'Select Building', 'select_building', 'publish', 'closed', 'closed', '', 'field_57b192592a494', '', '', '2016-08-15 09:53:11', '2016-08-15 09:53:11', '', 21, 'http://host.dev/?post_type=acf-field&#038;p=22', 1, 'acf-field', '', 0),
(23, 1, '2016-08-15 09:51:51', '2016-08-15 09:51:51', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_57b19337aad91', '', '', '2016-08-15 09:51:51', '2016-08-15 09:51:51', '', 21, 'http://host.dev/?post_type=acf-field&p=23', 0, 'acf-field', '', 0),
(24, 1, '2016-08-15 09:51:51', '2016-08-15 09:51:51', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_57b19346aad92', '', '', '2016-08-15 09:53:11', '2016-08-15 09:53:11', '', 21, 'http://host.dev/?post_type=acf-field&#038;p=24', 2, 'acf-field', '', 0),
(25, 1, '2016-08-15 10:02:25', '2016-08-15 10:02:25', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:27:"acf-options-awards-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Global - Awards', 'global-awards', 'publish', 'closed', 'closed', '', 'group_57b19251e35fe', '', '', '2016-08-15 13:12:06', '2016-08-15 13:12:06', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=25', 0, 'acf-field-group', '', 0),
(26, 1, '2016-08-15 10:02:25', '2016-08-15 10:02:25', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Award logos', 'award_logos', 'publish', 'closed', 'closed', '', 'field_57b19542cb44d', '', '', '2016-08-15 13:12:06', '2016-08-15 13:12:06', '', 25, 'http://host.dev/?post_type=acf-field&#038;p=26', 2, 'acf-field', '', 0),
(27, 1, '2016-08-15 10:02:25', '2016-08-15 10:02:25', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:60;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_57b195d7cb44f', '', '', '2016-08-15 10:02:25', '2016-08-15 10:02:25', '', 26, 'http://host.dev/?post_type=acf-field&p=27', 0, 'acf-field', '', 0),
(28, 1, '2016-08-15 10:02:25', '2016-08-15 10:02:25', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:40;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Logo', 'logo', 'publish', 'closed', 'closed', '', 'field_57b195adcb44e', '', '', '2016-08-15 10:02:25', '2016-08-15 10:02:25', '', 26, 'http://host.dev/?post_type=acf-field&p=28', 1, 'acf-field', '', 0),
(29, 1, '2016-08-15 10:03:20', '2016-08-15 10:03:20', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Awards title', 'awards_title', 'publish', 'closed', 'closed', '', 'field_57b19630ada62', '', '', '2016-08-15 12:59:24', '2016-08-15 12:59:24', '', 25, 'http://host.dev/?post_type=acf-field&#038;p=29', 0, 'acf-field', '', 0),
(31, 1, '2016-08-15 10:03:55', '2016-08-15 10:03:55', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Awards Description', 'awards_description', 'publish', 'closed', 'closed', '', 'field_57b19643f86e0', '', '', '2016-08-15 12:59:38', '2016-08-15 12:59:38', '', 25, 'http://host.dev/?post_type=acf-field&#038;p=31', 1, 'acf-field', '', 0),
(32, 1, '2016-08-15 10:07:24', '2016-08-15 10:07:24', '', 'Award_1', '', 'inherit', 'open', 'closed', '', 'award_1', '', '', '2016-08-15 10:07:24', '2016-08-15 10:07:24', '', 0, 'http://host.dev/app/uploads/2016/08/Award_1.png', 0, 'attachment', 'image/png', 0),
(33, 1, '2016-08-15 10:07:24', '2016-08-15 10:07:24', '', 'Award_2', '', 'inherit', 'open', 'closed', '', 'award_2', '', '', '2016-08-15 10:07:24', '2016-08-15 10:07:24', '', 0, 'http://host.dev/app/uploads/2016/08/Award_2.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2016-08-15 10:07:25', '2016-08-15 10:07:25', '', 'Award_3', '', 'inherit', 'open', 'closed', '', 'award_3', '', '', '2016-08-15 10:07:25', '2016-08-15 10:07:25', '', 0, 'http://host.dev/app/uploads/2016/08/Award_3.png', 0, 'attachment', 'image/png', 0),
(35, 1, '2016-08-15 10:07:25', '2016-08-15 10:07:25', '', 'Award_4', '', 'inherit', 'open', 'closed', '', 'award_4', '', '', '2016-08-15 10:07:25', '2016-08-15 10:07:25', '', 0, 'http://host.dev/app/uploads/2016/08/Award_4.png', 0, 'attachment', 'image/png', 0),
(36, 1, '2016-08-15 10:07:26', '2016-08-15 10:07:26', '', 'Award_5', '', 'inherit', 'open', 'closed', '', 'award_5', '', '', '2016-08-15 10:07:26', '2016-08-15 10:07:26', '', 0, 'http://host.dev/app/uploads/2016/08/Award_5.png', 0, 'attachment', 'image/png', 0),
(37, 1, '2016-08-15 10:07:27', '2016-08-15 10:07:27', '', 'Award_6', '', 'inherit', 'open', 'closed', '', 'award_6', '', '', '2016-08-15 10:07:27', '2016-08-15 10:07:27', '', 0, 'http://host.dev/app/uploads/2016/08/Award_6.png', 0, 'attachment', 'image/png', 0),
(39, 1, '2016-08-16 12:37:52', '2016-08-16 12:37:52', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"buildings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Building Information', 'building-information', 'publish', 'closed', 'closed', '', 'group_57b2f6e941ba7', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=39', 0, 'acf-field-group', '', 0),
(40, 1, '2016-08-16 12:37:52', '2016-08-16 12:37:52', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Address', 'address', 'publish', 'closed', 'closed', '', 'field_57b309047a9ce', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=40', 7, 'acf-field', '', 0),
(41, 1, '2016-08-16 12:37:52', '2016-08-16 12:37:52', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Address 1', 'building_address_1', 'publish', 'closed', 'closed', '', 'field_57b2f7287a9c9', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=41', 8, 'acf-field', '', 0),
(42, 1, '2016-08-16 12:37:52', '2016-08-16 12:37:52', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Address 2', 'building_address_2', 'publish', 'closed', 'closed', '', 'field_57b3088f7a9ca', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=42', 9, 'acf-field', '', 0),
(43, 1, '2016-08-16 12:37:52', '2016-08-16 12:37:52', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Town/City', 'building_address_town_city', 'publish', 'closed', 'closed', '', 'field_57b3089e7a9cb', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=43', 10, 'acf-field', '', 0),
(44, 1, '2016-08-16 12:37:52', '2016-08-16 12:37:52', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Post Code', 'building_address_post_code', 'publish', 'closed', 'closed', '', 'field_57b308be7a9cc', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=44', 11, 'acf-field', '', 0),
(45, 1, '2016-08-16 12:37:52', '2016-08-16 12:37:52', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Phone No', 'building_address_phone_no', 'publish', 'closed', 'closed', '', 'field_57b308ed7a9cd', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=45', 12, 'acf-field', '', 0),
(46, 1, '2016-08-16 12:40:20', '2016-08-16 12:40:20', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Longitude', 'building_address_longitude', 'publish', 'closed', 'closed', '', 'field_57b30964c687b', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=46', 13, 'acf-field', '', 0),
(47, 1, '2016-08-16 12:40:20', '2016-08-16 12:40:20', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Latitude', 'building_address_latitude', 'publish', 'closed', 'closed', '', 'field_57b30991c687c', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=47', 14, 'acf-field', '', 0),
(48, 1, '2016-08-16 12:44:34', '2016-08-16 12:44:34', '', 'King\'s Cross', '', 'publish', 'closed', 'closed', '', 'kings-cross', '', '', '2016-09-01 14:25:51', '2016-09-01 14:25:51', '', 0, 'http://host.dev/?post_type=buildings&#038;p=48', 0, 'buildings', '', 0),
(49, 1, '2016-08-16 12:54:19', '2016-08-16 12:54:19', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Facilities', 'facilities_', 'publish', 'closed', 'closed', '', 'field_57b30befbdda6', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=49', 19, 'acf-field', '', 0),
(50, 1, '2016-08-16 12:54:19', '2016-08-16 12:54:19', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Facilities overview', 'facilities_overview', 'publish', 'closed', 'closed', '', 'field_57b30c2ebdda7', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=50', 21, 'acf-field', '', 0),
(51, 1, '2016-08-16 12:54:19', '2016-08-16 12:54:19', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Facilities list', 'facilities_list', 'publish', 'closed', 'closed', '', 'field_57b30c41bdda8', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=51', 22, 'acf-field', '', 0),
(52, 1, '2016-08-16 12:54:19', '2016-08-16 12:54:19', 'a:7:{s:4:"type";s:11:"file_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:30;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"file_location";s:0:"";s:9:"file_glob";s:0:"";}', 'Icon', 'icon', 'publish', 'closed', 'closed', '', 'field_57b30c55bdda9', '', '', '2016-08-16 15:57:47', '2016-08-16 15:57:47', '', 51, 'http://host.dev/?post_type=acf-field&#038;p=52', 0, 'acf-field', '', 0),
(53, 1, '2016-08-16 12:54:19', '2016-08-16 12:54:19', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:70;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_57b30ce5bddaa', '', '', '2016-08-16 12:54:19', '2016-08-16 12:54:19', '', 51, 'http://host.dev/?post_type=acf-field&p=53', 1, 'acf-field', '', 0),
(54, 1, '2016-08-16 12:54:43', '2016-08-16 12:54:43', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Facilities title', 'facilities_title', 'publish', 'closed', 'closed', '', 'field_57b30d00567c9', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=54', 20, 'acf-field', '', 0),
(56, 1, '2016-08-18 08:39:28', '2016-08-18 08:39:28', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Facilities photos', 'facilities_photos', 'publish', 'closed', 'closed', '', 'field_57b5741b7f431', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=56', 23, 'acf-field', '', 0),
(57, 1, '2016-08-18 08:39:28', '2016-08-18 08:39:28', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Photo', 'photo', 'publish', 'closed', 'closed', '', 'field_57b574287f432', '', '', '2016-08-18 08:39:28', '2016-08-18 08:39:28', '', 56, 'http://host.dev/?post_type=acf-field&p=57', 0, 'acf-field', '', 0),
(58, 1, '2016-08-18 08:44:02', '2016-08-18 08:44:02', '', 'facilities_1', '', 'inherit', 'open', 'closed', '', 'facilities_1', '', '', '2016-08-18 08:44:07', '2016-08-18 08:44:07', '', 48, 'http://host.dev/app/uploads/2016/08/facilities_1.png', 0, 'attachment', 'image/png', 0),
(59, 1, '2016-08-18 08:44:03', '2016-08-18 08:44:03', '', 'facilities_2', '', 'inherit', 'open', 'closed', '', 'facilities_2', '', '', '2016-08-18 08:44:03', '2016-08-18 08:44:03', '', 48, 'http://host.dev/app/uploads/2016/08/facilities_2.png', 0, 'attachment', 'image/png', 0),
(60, 1, '2016-08-18 08:47:33', '2016-08-18 08:47:33', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'People', '', 'publish', 'closed', 'closed', '', 'field_57b575bcc8ea1', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=60', 28, 'acf-field', '', 0),
(61, 1, '2016-08-18 08:47:33', '2016-08-18 08:47:33', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'People title', 'people_title', 'publish', 'closed', 'closed', '', 'field_57b575c9c8ea2', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=61', 29, 'acf-field', '', 0),
(62, 1, '2016-08-18 08:47:33', '2016-08-18 08:47:33', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'People description', 'people_description', 'publish', 'closed', 'closed', '', 'field_57b575e6c8ea3', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=62', 30, 'acf-field', '', 0),
(63, 1, '2016-08-18 08:47:33', '2016-08-18 08:47:33', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'People photos', 'people_photos', 'publish', 'closed', 'closed', '', 'field_57b57603c8ea4', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=63', 31, 'acf-field', '', 0),
(64, 1, '2016-08-18 08:47:33', '2016-08-18 08:47:33', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Photo', 'photo', 'publish', 'closed', 'closed', '', 'field_57b57603c8ea5', '', '', '2016-08-18 08:47:33', '2016-08-18 08:47:33', '', 63, 'http://host.dev/?post_type=acf-field&p=64', 0, 'acf-field', '', 0),
(65, 1, '2016-08-18 08:50:22', '2016-08-18 08:50:22', '', 'staff', '', 'inherit', 'open', 'closed', '', 'staff', '', '', '2016-08-18 08:50:24', '2016-08-18 08:50:24', '', 48, 'http://host.dev/app/uploads/2016/08/staff.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2016-08-18 08:56:35', '2016-08-18 08:56:35', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Location', '', 'publish', 'closed', 'closed', '', 'field_57b577e3299ac', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=66', 24, 'acf-field', '', 0),
(67, 1, '2016-08-18 08:56:35', '2016-08-18 08:56:35', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Location title', 'location_title', 'publish', 'closed', 'closed', '', 'field_57b577f6299ad', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=67', 25, 'acf-field', '', 0),
(68, 1, '2016-08-18 08:56:35', '2016-08-18 08:56:35', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Location description', 'location_description', 'publish', 'closed', 'closed', '', 'field_57b57813299ae', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=68', 26, 'acf-field', '', 0),
(69, 1, '2016-08-18 10:15:51', '2016-08-18 10:15:51', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Points of interest', 'points_of_interest', 'publish', 'closed', 'closed', '', 'field_57b58abd86ca6', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=69', 27, 'acf-field', '', 0),
(70, 1, '2016-08-18 10:15:51', '2016-08-18 10:15:51', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_57b58b0286ca7', '', '', '2016-08-18 10:20:13', '2016-08-18 10:20:13', '', 69, 'http://host.dev/?post_type=acf-field&#038;p=70', 0, 'acf-field', '', 0),
(72, 1, '2016-08-18 10:15:51', '2016-08-18 10:15:51', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Transport time', 'transport_time', 'publish', 'closed', 'closed', '', 'field_57b58b3786ca9', '', '', '2016-08-18 10:23:18', '2016-08-18 10:23:18', '', 69, 'http://host.dev/?post_type=acf-field&#038;p=72', 1, 'acf-field', '', 0),
(73, 1, '2016-08-18 10:15:51', '2016-08-18 10:15:51', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Walking time', 'walking_time', 'publish', 'closed', 'closed', '', 'field_57b58b5286caa', '', '', '2016-08-18 10:23:18', '2016-08-18 10:23:18', '', 69, 'http://host.dev/?post_type=acf-field&#038;p=73', 2, 'acf-field', '', 0),
(74, 1, '2016-08-18 10:41:25', '2016-08-18 10:41:25', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header', '', 'publish', 'closed', 'closed', '', 'field_57b5906cda7a9', '', '', '2016-08-18 10:41:25', '2016-08-18 10:41:25', '', 39, 'http://host.dev/?post_type=acf-field&p=74', 0, 'acf-field', '', 0),
(75, 1, '2016-08-18 10:41:25', '2016-08-18 10:41:25', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Title 1', 'title_1', 'publish', 'closed', 'closed', '', 'field_57b59095da7aa', '', '', '2016-08-18 10:41:25', '2016-08-18 10:41:25', '', 39, 'http://host.dev/?post_type=acf-field&p=75', 1, 'acf-field', '', 0),
(76, 1, '2016-08-18 10:41:25', '2016-08-18 10:41:25', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Title 2', 'title_2', 'publish', 'closed', 'closed', '', 'field_57b590a3da7ab', '', '', '2016-08-18 10:41:25', '2016-08-18 10:41:25', '', 39, 'http://host.dev/?post_type=acf-field&p=76', 2, 'acf-field', '', 0),
(77, 1, '2016-08-18 10:41:25', '2016-08-18 10:41:25', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_57b590b1da7ac', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=77', 5, 'acf-field', '', 0),
(78, 1, '2016-08-18 10:41:25', '2016-08-18 10:41:25', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Links / Downloads', 'links_downloads', 'publish', 'closed', 'closed', '', 'field_57b590d8da7ad', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=78', 6, 'acf-field', '', 0),
(79, 1, '2016-08-18 10:41:25', '2016-08-18 10:41:25', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Button text', 'button_text', 'publish', 'closed', 'closed', '', 'field_57b590ebda7ae', '', '', '2016-08-18 10:41:25', '2016-08-18 10:41:25', '', 78, 'http://host.dev/?post_type=acf-field&p=79', 0, 'acf-field', '', 0),
(80, 1, '2016-08-18 10:41:25', '2016-08-18 10:41:25', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_57b59108da7af', '', '', '2016-08-18 10:41:25', '2016-08-18 10:41:25', '', 78, 'http://host.dev/?post_type=acf-field&p=80', 1, 'acf-field', '', 0),
(83, 1, '2016-08-18 10:49:57', '2016-08-18 10:49:57', '', 'kings-cross', '', 'inherit', 'open', 'closed', '', 'kings-cross-2', '', '', '2016-09-01 15:22:23', '2016-09-01 15:22:23', '', 48, 'http://host.dev/app/uploads/2016/08/kings-cross.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"rooms";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Room Information', 'room-information', 'publish', 'closed', 'closed', '', 'group_57bedc06b5a5e', '', '', '2016-09-01 15:30:03', '2016-09-01 15:30:03', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=85', 0, 'acf-field-group', '', 0),
(86, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Overview', '', 'publish', 'closed', 'closed', '', 'field_57bedc06c204a', '', '', '2016-08-25 11:54:45', '2016-08-25 11:54:45', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=86', 0, 'acf-field', '', 0),
(87, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:4:"33.3";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Availability description', 'availability_description', 'publish', 'closed', 'closed', '', 'field_57bedc06c20aa', '', '', '2016-08-25 14:50:59', '2016-08-25 14:50:59', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=87', 2, 'acf-field', '', 0),
(88, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:4:"33.3";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'From amount', 'from_amount', 'publish', 'closed', 'closed', '', 'field_57bedc06c2102', '', '', '2016-08-25 14:50:08', '2016-08-25 14:50:08', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=88', 3, 'acf-field', '', 0),
(89, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_57bedc06c2157', '', '', '2016-08-25 14:50:08', '2016-08-25 14:50:08', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=89', 4, 'acf-field', '', 0),
(90, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Links / Downloads', 'links_downloads', 'publish', 'closed', 'closed', '', 'field_57bedc06c21ae', '', '', '2016-08-25 14:50:08', '2016-08-25 14:50:08', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=90', 5, 'acf-field', '', 0),
(91, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Button text', 'button_text', 'publish', 'closed', 'closed', '', 'field_57bedc06cfa1d', '', '', '2016-08-25 11:52:38', '2016-08-25 11:52:38', '', 90, 'http://host.dev/?post_type=acf-field&p=91', 0, 'acf-field', '', 0),
(92, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";i:50;s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_57bedc06cfa77', '', '', '2016-08-25 11:52:38', '2016-08-25 11:52:38', '', 90, 'http://host.dev/?post_type=acf-field&p=92', 1, 'acf-field', '', 0),
(95, 1, '2016-08-25 11:52:38', '2016-08-25 11:52:38', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Details', '', 'publish', 'closed', 'closed', '', 'field_57bedc06c2257', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=95', 6, 'acf-field', '', 0),
(111, 1, '2016-08-25 11:52:39', '2016-08-25 11:52:39', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Location', '', 'publish', 'closed', 'closed', '', 'field_57bedc06c2c17', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=111', 15, 'acf-field', '', 0),
(112, 1, '2016-08-25 11:52:39', '2016-08-25 11:52:39', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Location title', 'location_title', 'publish', 'closed', 'closed', '', 'field_57bedc06c2ccf', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=112', 16, 'acf-field', '', 0),
(113, 1, '2016-08-25 11:52:39', '2016-08-25 11:52:39', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Location description', 'location_description', 'publish', 'closed', 'closed', '', 'field_57bedc06c2d5e', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=113', 17, 'acf-field', '', 0),
(114, 1, '2016-08-25 11:52:39', '2016-08-25 11:52:39', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Points of interest', 'points_of_interest', 'publish', 'closed', 'closed', '', 'field_57bedc06c2e35', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=114', 18, 'acf-field', '', 0),
(115, 1, '2016-08-25 11:52:39', '2016-08-25 11:52:39', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_57bedc071e38b', '', '', '2016-08-25 11:52:39', '2016-08-25 11:52:39', '', 114, 'http://host.dev/?post_type=acf-field&p=115', 0, 'acf-field', '', 0),
(116, 1, '2016-08-25 11:52:39', '2016-08-25 11:52:39', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Transport time', 'transport_time', 'publish', 'closed', 'closed', '', 'field_57bedc071e3e7', '', '', '2016-08-25 11:52:39', '2016-08-25 11:52:39', '', 114, 'http://host.dev/?post_type=acf-field&p=116', 1, 'acf-field', '', 0),
(117, 1, '2016-08-25 11:52:39', '2016-08-25 11:52:39', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Walking time', 'walking_time', 'publish', 'closed', 'closed', '', 'field_57bedc071e434', '', '', '2016-08-25 11:52:39', '2016-08-25 11:52:39', '', 114, 'http://host.dev/?post_type=acf-field&p=117', 2, 'acf-field', '', 0),
(123, 1, '2016-08-25 11:57:56', '2016-08-25 11:57:56', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Living space', 'living_space', 'publish', 'closed', 'closed', '', 'field_57bedcedf0eea', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=123', 7, 'acf-field', '', 0),
(124, 1, '2016-08-25 11:57:56', '2016-08-25 11:57:56', 'a:7:{s:4:"type";s:11:"file_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"30";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"file_location";s:0:"";s:9:"file_glob";s:0:"";}', 'Icon', 'icon', 'publish', 'closed', 'closed', '', 'field_57bedcedf0eeb', '', '', '2016-08-25 11:57:56', '2016-08-25 11:57:56', '', 123, 'http://host.dev/?post_type=acf-field&p=124', 0, 'acf-field', '', 0),
(125, 1, '2016-08-25 11:57:56', '2016-08-25 11:57:56', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"35";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'name', 'publish', 'closed', 'closed', '', 'field_57bedd26f0eed', '', '', '2016-08-25 11:57:56', '2016-08-25 11:57:56', '', 123, 'http://host.dev/?post_type=acf-field&p=125', 1, 'acf-field', '', 0),
(126, 1, '2016-08-25 11:57:56', '2016-08-25 11:57:56', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"35";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_57bedcedf0eec', '', '', '2016-08-25 11:57:56', '2016-08-25 11:57:56', '', 123, 'http://host.dev/?post_type=acf-field&p=126', 2, 'acf-field', '', 0),
(127, 1, '2016-08-25 11:58:34', '2016-08-25 11:58:34', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'The amenities', 'the_amenities', 'publish', 'closed', 'closed', '', 'field_57bedd500a7a5', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=127', 8, 'acf-field', '', 0),
(128, 1, '2016-08-25 11:58:34', '2016-08-25 11:58:34', 'a:7:{s:4:"type";s:11:"file_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"30";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"file_location";s:0:"";s:9:"file_glob";s:0:"";}', 'Icon', 'icon', 'publish', 'closed', 'closed', '', 'field_57bedd500a7a6', '', '', '2016-08-25 11:58:34', '2016-08-25 11:58:34', '', 127, 'http://host.dev/?post_type=acf-field&p=128', 0, 'acf-field', '', 0),
(129, 1, '2016-08-25 11:58:34', '2016-08-25 11:58:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"35";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'name', 'publish', 'closed', 'closed', '', 'field_57bedd500a7a7', '', '', '2016-08-25 11:58:34', '2016-08-25 11:58:34', '', 127, 'http://host.dev/?post_type=acf-field&p=129', 1, 'acf-field', '', 0),
(130, 1, '2016-08-25 11:58:34', '2016-08-25 11:58:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"35";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_57bedd500a7a8', '', '', '2016-08-25 11:58:34', '2016-08-25 11:58:34', '', 127, 'http://host.dev/?post_type=acf-field&p=130', 2, 'acf-field', '', 0),
(131, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Price', '', 'publish', 'closed', 'closed', '', 'field_57befcd7e6dee', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=131', 9, 'acf-field', '', 0),
(132, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Simple - Number of weeks', 'number_of_weeks', 'publish', 'closed', 'closed', '', 'field_57befd73e6def', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=132', 10, 'acf-field', '', 0),
(133, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Simple - Date range', 'date_range', 'publish', 'closed', 'closed', '', 'field_57befe01e6df0', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=133', 11, 'acf-field', '', 0),
(134, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Simple - Price per week', 'price_per_week', 'publish', 'closed', 'closed', '', 'field_57befeafe6df1', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=134', 12, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(135, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Payment plans', 'payment_plans', 'publish', 'closed', 'closed', '', 'field_57beffb6e6df2', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=135', 13, 'acf-field', '', 0),
(136, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_57beffcee6df3', '', '', '2016-08-25 15:03:57', '2016-08-25 15:03:57', '', 135, 'http://host.dev/?post_type=acf-field&#038;p=136', 0, 'acf-field', '', 0),
(137, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Subtitle', 'subtitle', 'publish', 'closed', 'closed', '', 'field_57beffe2e6df4', '', '', '2016-08-25 15:03:57', '2016-08-25 15:03:57', '', 135, 'http://host.dev/?post_type=acf-field&#038;p=137', 1, 'acf-field', '', 0),
(138, 1, '2016-08-25 14:26:20', '2016-08-25 14:26:20', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:0;}', 'Content', 'content', 'publish', 'closed', 'closed', '', 'field_57beffede6df5', '', '', '2016-08-25 15:06:09', '2016-08-25 15:06:09', '', 135, 'http://host.dev/?post_type=acf-field&#038;p=138', 2, 'acf-field', '', 0),
(139, 1, '2016-08-25 14:30:47', '2016-08-25 14:30:47', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:60:"If no cancellation policy the generic version will be shown.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Cancellation policy', 'cancellation_policy', 'publish', 'closed', 'closed', '', 'field_57bf00b22e455', '', '', '2016-09-01 11:26:38', '2016-09-01 11:26:38', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=139', 14, 'acf-field', '', 0),
(140, 1, '2016-08-25 14:34:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-08-25 14:34:27', '0000-00-00 00:00:00', '', 0, 'http://host.dev/?post_type=acf-field-group&p=140', 0, 'acf-field-group', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(141, 1, '2016-08-25 14:36:12', '2016-08-25 14:36:12', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:32:"acf-options-room-prices-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Global - Room Prices', 'global-room-prices', 'publish', 'closed', 'closed', '', 'group_57bf0201a455c', '', '', '2016-08-25 14:44:15', '2016-08-25 14:44:15', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=141', 0, 'acf-field-group', '', 0),
(142, 1, '2016-08-25 14:36:12', '2016-08-25 14:36:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title 1', 'title_1', 'publish', 'closed', 'closed', '', 'field_57bf021ca4ff8', '', '', '2016-08-25 14:36:12', '2016-08-25 14:36:12', '', 141, 'http://host.dev/?post_type=acf-field&p=142', 0, 'acf-field', '', 0),
(143, 1, '2016-08-25 14:36:12', '2016-08-25 14:36:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title 2', 'title_2', 'publish', 'closed', 'closed', '', 'field_57bf0228a4ff9', '', '', '2016-08-25 14:36:12', '2016-08-25 14:36:12', '', 141, 'http://host.dev/?post_type=acf-field&p=143', 1, 'acf-field', '', 0),
(144, 1, '2016-08-25 14:36:12', '2016-08-25 14:36:12', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"33";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Content 1', 'content_1', 'publish', 'closed', 'closed', '', 'field_57bf0235a4ffa', '', '', '2016-08-25 14:36:12', '2016-08-25 14:36:12', '', 141, 'http://host.dev/?post_type=acf-field&p=144', 2, 'acf-field', '', 0),
(145, 1, '2016-08-25 14:36:12', '2016-08-25 14:36:12', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"33";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Content 2', 'content_2', 'publish', 'closed', 'closed', '', 'field_57bf024ca4ffb', '', '', '2016-08-25 14:36:12', '2016-08-25 14:36:12', '', 141, 'http://host.dev/?post_type=acf-field&p=145', 3, 'acf-field', '', 0),
(146, 1, '2016-08-25 14:36:12', '2016-08-25 14:36:12', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"33";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Content 3', 'content_3', 'publish', 'closed', 'closed', '', 'field_57bf0254a4ffc', '', '', '2016-08-25 14:36:12', '2016-08-25 14:36:12', '', 141, 'http://host.dev/?post_type=acf-field&p=146', 4, 'acf-field', '', 0),
(147, 1, '2016-08-25 14:44:15', '2016-08-25 14:44:15', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Global - Cancellation policy', 'global_cancellation_policy', 'publish', 'closed', 'closed', '', 'field_57bf0410852d7', '', '', '2016-08-25 14:44:15', '2016-08-25 14:44:15', '', 141, 'http://host.dev/?post_type=acf-field&p=147', 5, 'acf-field', '', 0),
(148, 1, '2016-08-25 14:50:08', '2016-08-25 14:50:08', 'a:13:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:4:"33.3";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:3:{s:9:"available";s:9:"Available";s:7:"limited";s:20:"Limited Availability";s:8:"sold_out";s:8:"Sold out";}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:13:"return_format";s:5:"value";s:11:"placeholder";s:0:"";}', 'Availability', 'availability', 'publish', 'closed', 'closed', '', 'field_57bf04c843a01', '', '', '2016-08-25 14:50:59', '2016-08-25 14:50:59', '', 85, 'http://host.dev/?post_type=acf-field&#038;p=148', 1, 'acf-field', '', 0),
(149, 1, '2016-08-25 14:55:31', '2016-08-25 14:55:31', '', 'room_placeholder', '', 'inherit', 'open', 'closed', '', 'room_placeholder', '', '', '2016-09-01 11:33:37', '2016-09-01 11:33:37', '', 18, 'http://host.dev/app/uploads/2016/08/room_placeholder.jpg', 0, 'attachment', 'image/jpeg', 0),
(152, 1, '2016-08-26 10:12:20', '2016-08-26 10:12:20', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Rooms', '', 'publish', 'closed', 'closed', '', 'field_57c015a4bd610', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=152', 15, 'acf-field', '', 0),
(153, 1, '2016-08-26 10:12:20', '2016-08-26 10:12:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Rooms title 1', 'rooms_title_1', 'publish', 'closed', 'closed', '', 'field_57c015bcbd611', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=153', 16, 'acf-field', '', 0),
(154, 1, '2016-08-26 10:12:21', '2016-08-26 10:12:21', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Rooms title 2', 'rooms_title_2', 'publish', 'closed', 'closed', '', 'field_57c015dcbd612', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=154', 17, 'acf-field', '', 0),
(155, 1, '2016-08-26 10:12:21', '2016-08-26 10:12:21', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Rooms description', 'rooms_description', 'publish', 'closed', 'closed', '', 'field_57c015f0bd613', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&#038;p=155', 18, 'acf-field', '', 0),
(158, 1, '2016-08-26 11:03:32', '2016-08-26 11:03:32', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-08-26 11:03:32', '2016-08-26 11:03:32', '', 0, 'http://host.dev/?page_id=158', 0, 'page', '', 0),
(159, 1, '2016-08-26 11:03:32', '2016-08-26 11:03:32', '', 'Home', '', 'inherit', 'closed', 'closed', '', '158-revision-v1', '', '', '2016-08-26 11:03:32', '2016-08-26 11:03:32', '', 158, 'http://host.dev/158-revision-v1/', 0, 'revision', '', 0),
(160, 1, '2016-08-26 11:03:47', '2016-08-26 11:03:47', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2016-08-26 11:03:47', '2016-08-26 11:03:47', '', 0, 'http://host.dev/?page_id=160', 0, 'page', '', 0),
(161, 1, '2016-08-26 11:03:47', '2016-08-26 11:03:47', '', 'About', '', 'inherit', 'closed', 'closed', '', '160-revision-v1', '', '', '2016-08-26 11:03:47', '2016-08-26 11:03:47', '', 160, 'http://host.dev/160-revision-v1/', 0, 'revision', '', 0),
(162, 1, '2016-08-26 11:04:00', '2016-08-26 11:04:00', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2016-08-26 11:04:00', '2016-08-26 11:04:00', '', 0, 'http://host.dev/?page_id=162', 0, 'page', '', 0),
(163, 1, '2016-08-26 11:04:00', '2016-08-26 11:04:00', '', 'News', '', 'inherit', 'closed', 'closed', '', '162-revision-v1', '', '', '2016-08-26 11:04:00', '2016-08-26 11:04:00', '', 162, 'http://host.dev/162-revision-v1/', 0, 'revision', '', 0),
(164, 1, '2016-08-26 11:04:14', '2016-08-26 11:04:14', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2016-08-26 11:04:14', '2016-08-26 11:04:14', '', 0, 'http://host.dev/?page_id=164', 0, 'page', '', 0),
(165, 1, '2016-08-26 11:04:14', '2016-08-26 11:04:14', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '164-revision-v1', '', '', '2016-08-26 11:04:14', '2016-08-26 11:04:14', '', 164, 'http://host.dev/164-revision-v1/', 0, 'revision', '', 0),
(167, 1, '2016-08-26 11:04:58', '2016-08-26 11:04:58', '', 'Universities', '', 'publish', 'closed', 'closed', '', 'universities', '', '', '2016-08-26 11:04:58', '2016-08-26 11:04:58', '', 0, 'http://host.dev/?page_id=167', 0, 'page', '', 0),
(168, 1, '2016-08-26 11:04:58', '2016-08-26 11:04:58', '', 'Universities', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2016-08-26 11:04:58', '2016-08-26 11:04:58', '', 167, 'http://host.dev/167-revision-v1/', 0, 'revision', '', 0),
(169, 1, '2016-08-26 11:31:51', '2016-08-26 11:31:51', '', 'Locations', '', 'publish', 'closed', 'closed', '', 'locations', '', '', '2016-08-26 11:31:51', '2016-08-26 11:31:51', '', 0, 'http://host.dev/?page_id=169', 0, 'page', '', 0),
(170, 1, '2016-08-26 11:31:51', '2016-08-26 11:31:51', '', 'Locations', '', 'inherit', 'closed', 'closed', '', '169-revision-v1', '', '', '2016-08-26 11:31:51', '2016-08-26 11:31:51', '', 169, 'http://host.dev/169-revision-v1/', 0, 'revision', '', 0),
(171, 1, '2016-08-26 11:32:57', '2016-08-26 11:32:57', ' ', '', '', 'publish', 'closed', 'closed', '', '171', '', '', '2016-08-26 11:32:57', '2016-08-26 11:32:57', '', 0, 'http://host.dev/?p=171', 1, 'nav_menu_item', '', 0),
(172, 1, '2016-08-26 11:32:57', '2016-08-26 11:32:57', ' ', '', '', 'publish', 'closed', 'closed', '', '172', '', '', '2016-08-26 11:32:57', '2016-08-26 11:32:57', '', 0, 'http://host.dev/?p=172', 4, 'nav_menu_item', '', 0),
(173, 1, '2016-08-26 11:32:57', '2016-08-26 11:32:57', ' ', '', '', 'publish', 'closed', 'closed', '', '173', '', '', '2016-08-26 11:32:57', '2016-08-26 11:32:57', '', 0, 'http://host.dev/?p=173', 3, 'nav_menu_item', '', 0),
(174, 1, '2016-08-26 11:32:57', '2016-08-26 11:32:57', ' ', '', '', 'publish', 'closed', 'closed', '', '174', '', '', '2016-08-26 11:32:57', '2016-08-26 11:32:57', '', 0, 'http://host.dev/?p=174', 2, 'nav_menu_item', '', 0),
(175, 1, '2016-08-26 11:37:55', '2016-08-26 11:37:55', 'These Website Terms and Conditions of Use apply to this website which is operated by Victoria Hall under the domain name www.victoriahalls.com (hereinafter referred to as “the Website”) and is part of the O’Flynn Group (hereinafter referred to as “we”, “us”, “our”), which also includes such other group companies as may from time to time be listed on the Website.\r\n\r\nBy proceeding beyond the homepage you agree to accept these Terms and Conditions of Use and we agree to grant you a non-exclusive, non-transferable licence to use the Website in accordance with the terms and conditions of use set out below.\r\n\r\nWe may from time to time and without notice revise these Terms and Conditions of Use and such revision will take effect as and from the date when such revision is posted on the Website. Your continued use of the Website will be regarded as your acceptance of these Terms and Conditions of Use as amended.\r\n\r\n<strong>Links</strong>\r\n\r\nWe may provide links on this Website to the websites of third parties. You acknowledge and agree that we have no control over and do not monitor these third party websites. We make no representations about and cannot accept any liability in respect of the content or otherwise of any such websites. A link to a third party website does not mean that we endorse the content of that website. Access to third party websites will be governed by terms of use of such websites.\r\nYou may not create a link to this Website from another website or document without our prior written consent.\r\n\r\n<strong>User conduct</strong>\r\n\r\nAny fraudulent, abusive, or otherwise illegal activity is strictly forbidden. You may not post or transmit, or cause to be posted or transmitted, any communication or solicitation designed or intended to obtain personal data from any Website user. You must comply with all applicable local, national and international laws and regulations that relate to your use of or activities on the Website.\r\n\r\n<strong>In accessing this Website, you must not:</strong>\r\n\r\nDisrupt or interfere with the Website, or any services, system resources, accounts, servers or networks connected to or accessible through the Website or any linked websites\r\n\r\nDisrupt or interfere in any way with any other user’s enjoyment of the Website or any linked websites\r\n\r\nExtract any web pages or any content from the Website by any means whatsoever.\r\n\r\nTake any action that imposes an unreasonable or disproportionately large load on the infrastructure of the Website\r\n\r\nReverse engineer, reverse assemble or otherwise attempt to discover source code or other arithmetical formula in respect of the software underlying the infrastructure and processes associated with the Website\r\n\r\nUse the Website to violate the security of any computer network, transfer or store illegal material including material that is deemed threatening or obscene, or engage in any kind of illegal activity\r\n\r\nEngage in any kind of illegal, criminal or tortious activity through the use of the Website.\r\n\r\nAttempt to gain unauthorised access to any parts of the Website that are not open to public access; or\r\n\r\nPost or transmit to or via the Website any material that may infringe the intellectual property rights of any third party, or any defamatory, derogatory or offensive material or publication.\r\n\r\n<strong>Indemnity</strong>\r\n\r\nYou agree to indemnify and hold us (and our related bodies corporate, directors, officers, employees, agents and contractors) harmless from any claim, action, demand, loss or damages made or incurred by any third party arising out of or relating to your conduct, your use of the Website, your breach of these Terms of Use, or your breach of any rights of third parties.\r\n\r\n<strong>Limitation of liability</strong>\r\n\r\nSubject to any responsibilities implied by law and which cannot be excluded, we (including our related bodies corporate, directors, officers, employees, agents and contractors) expressly disclaim all liability to you or any other persons for any losses, damages, liabilities, claims and expenses whatsoever, whether direct, indirect or consequential, arising out of or referable to the content of the Website (or material accessed via the Website), or to access of the Website by you, howsoever caused. To the extent permitted by law, any liabilities imposed on us, or implied into these Terms of Use, under any law are hereby excluded.', 'Terms & Conditions', '', 'publish', 'closed', 'closed', '', 'terms-conditions', '', '', '2016-08-26 11:37:55', '2016-08-26 11:37:55', '', 0, 'http://host.dev/?page_id=175', 0, 'page', '', 0),
(176, 1, '2016-08-26 11:37:55', '2016-08-26 11:37:55', 'These Website Terms and Conditions of Use apply to this website which is operated by Victoria Hall under the domain name www.victoriahalls.com (hereinafter referred to as “the Website”) and is part of the O’Flynn Group (hereinafter referred to as “we”, “us”, “our”), which also includes such other group companies as may from time to time be listed on the Website.\r\n\r\nBy proceeding beyond the homepage you agree to accept these Terms and Conditions of Use and we agree to grant you a non-exclusive, non-transferable licence to use the Website in accordance with the terms and conditions of use set out below.\r\n\r\nWe may from time to time and without notice revise these Terms and Conditions of Use and such revision will take effect as and from the date when such revision is posted on the Website. Your continued use of the Website will be regarded as your acceptance of these Terms and Conditions of Use as amended.\r\n\r\n<strong>Links</strong>\r\n\r\nWe may provide links on this Website to the websites of third parties. You acknowledge and agree that we have no control over and do not monitor these third party websites. We make no representations about and cannot accept any liability in respect of the content or otherwise of any such websites. A link to a third party website does not mean that we endorse the content of that website. Access to third party websites will be governed by terms of use of such websites.\r\nYou may not create a link to this Website from another website or document without our prior written consent.\r\n\r\n<strong>User conduct</strong>\r\n\r\nAny fraudulent, abusive, or otherwise illegal activity is strictly forbidden. You may not post or transmit, or cause to be posted or transmitted, any communication or solicitation designed or intended to obtain personal data from any Website user. You must comply with all applicable local, national and international laws and regulations that relate to your use of or activities on the Website.\r\n\r\n<strong>In accessing this Website, you must not:</strong>\r\n\r\nDisrupt or interfere with the Website, or any services, system resources, accounts, servers or networks connected to or accessible through the Website or any linked websites\r\n\r\nDisrupt or interfere in any way with any other user’s enjoyment of the Website or any linked websites\r\n\r\nExtract any web pages or any content from the Website by any means whatsoever.\r\n\r\nTake any action that imposes an unreasonable or disproportionately large load on the infrastructure of the Website\r\n\r\nReverse engineer, reverse assemble or otherwise attempt to discover source code or other arithmetical formula in respect of the software underlying the infrastructure and processes associated with the Website\r\n\r\nUse the Website to violate the security of any computer network, transfer or store illegal material including material that is deemed threatening or obscene, or engage in any kind of illegal activity\r\n\r\nEngage in any kind of illegal, criminal or tortious activity through the use of the Website.\r\n\r\nAttempt to gain unauthorised access to any parts of the Website that are not open to public access; or\r\n\r\nPost or transmit to or via the Website any material that may infringe the intellectual property rights of any third party, or any defamatory, derogatory or offensive material or publication.\r\n\r\n<strong>Indemnity</strong>\r\n\r\nYou agree to indemnify and hold us (and our related bodies corporate, directors, officers, employees, agents and contractors) harmless from any claim, action, demand, loss or damages made or incurred by any third party arising out of or relating to your conduct, your use of the Website, your breach of these Terms of Use, or your breach of any rights of third parties.\r\n\r\n<strong>Limitation of liability</strong>\r\n\r\nSubject to any responsibilities implied by law and which cannot be excluded, we (including our related bodies corporate, directors, officers, employees, agents and contractors) expressly disclaim all liability to you or any other persons for any losses, damages, liabilities, claims and expenses whatsoever, whether direct, indirect or consequential, arising out of or referable to the content of the Website (or material accessed via the Website), or to access of the Website by you, howsoever caused. To the extent permitted by law, any liabilities imposed on us, or implied into these Terms of Use, under any law are hereby excluded.', 'Terms & Conditions', '', 'inherit', 'closed', 'closed', '', '175-revision-v1', '', '', '2016-08-26 11:37:55', '2016-08-26 11:37:55', '', 175, 'http://host.dev/175-revision-v1/', 0, 'revision', '', 0),
(177, 1, '2016-08-26 11:40:09', '2016-08-26 11:40:09', '<strong>Below are links to some of the organisations Victoria Hall works with. Please note that the links below will take you to the external pages of the listed companies and Victoria Hall takes no responsibility for the content given within them.\r\n</strong>\r\n\r\n<a href="http://ask4.com/" target="_blank"><img src="http://victoriahalls.com/wp-content/uploads//2015/06/ASK-small-Bann.png" alt="UniKitOut logo" width="291" height="92" /></a>\r\n\r\n<strong>Ask4</strong>\r\nWe believe that a fast, reliable Internet service is an essential requirement for any student accommodation building. With ASK4 Broadband students may choose from a vast range of packages with speeds up to 100Mb/s and no restrictions.\r\n<a href="http://ask4.com/" target="_blank">http://ask4.com</a>\r\n\r\n&nbsp;\r\n\r\n<a href="http://www.endsleigh.co.uk/" target="_blank"><img src="http://victoriahalls.com/wp-content/uploads//2016/08/endsleigh_rgb_colour.jpg" alt="UniKitOut logo" width="156" height="92" /></a>\r\n\r\n<strong>Endsleigh</strong>\r\nEndsleigh Insurance Services Limited – Complete cover for a range of properties, including single flats, flats in blocks, commercial property, shared houses and family homes.\r\n<a href="http://www.endsleigh.co.uk/" target="_blank">http://www.endsleigh.co.uk</a>\r\n\r\n&nbsp;\r\n\r\n<strong><a href="http://www.unikitout.com/collections/victoria" target="_blank"><img class="alignnone" src="http://victoriahalls.com/wp-content/uploads//2016/08/unikitout-logo.png" alt="UniKitOut logo" width="101" height="92" /></a></strong>\r\n\r\n<strong>UniKitOut</strong>\r\nUniKitOut are specialist suppliers of student essentials; they provide what you need. UniKitOut are the one stop shop for student essentials. They offer huge discounts on Student Bed Packs, Student Kitchen Packs, Student Bathroom and Towel Packs, Student Combo Packs, Electricals, Accessories and much more – they even deliver direct to your halls so everything is waiting for you upon your arrival! <strong>Quote VHALL16 to receive a 10% discount.\r\n</strong><a title="UniKitOut" href="http://www.unikitout.com/collections/victoria" target="_blank">http://www.unikitout.com</a>', 'Partners', '', 'publish', 'closed', 'closed', '', 'partners', '', '', '2016-08-26 11:40:09', '2016-08-26 11:40:09', '', 0, 'http://host.dev/?page_id=177', 0, 'page', '', 0),
(178, 1, '2016-08-26 11:40:09', '2016-08-26 11:40:09', '<strong>Below are links to some of the organisations Victoria Hall works with. Please note that the links below will take you to the external pages of the listed companies and Victoria Hall takes no responsibility for the content given within them.\r\n</strong>\r\n\r\n<a href="http://ask4.com/" target="_blank"><img src="http://victoriahalls.com/wp-content/uploads//2015/06/ASK-small-Bann.png" alt="UniKitOut logo" width="291" height="92" /></a>\r\n\r\n<strong>Ask4</strong>\r\nWe believe that a fast, reliable Internet service is an essential requirement for any student accommodation building. With ASK4 Broadband students may choose from a vast range of packages with speeds up to 100Mb/s and no restrictions.\r\n<a href="http://ask4.com/" target="_blank">http://ask4.com</a>\r\n\r\n&nbsp;\r\n\r\n<a href="http://www.endsleigh.co.uk/" target="_blank"><img src="http://victoriahalls.com/wp-content/uploads//2016/08/endsleigh_rgb_colour.jpg" alt="UniKitOut logo" width="156" height="92" /></a>\r\n\r\n<strong>Endsleigh</strong>\r\nEndsleigh Insurance Services Limited – Complete cover for a range of properties, including single flats, flats in blocks, commercial property, shared houses and family homes.\r\n<a href="http://www.endsleigh.co.uk/" target="_blank">http://www.endsleigh.co.uk</a>\r\n\r\n&nbsp;\r\n\r\n<strong><a href="http://www.unikitout.com/collections/victoria" target="_blank"><img class="alignnone" src="http://victoriahalls.com/wp-content/uploads//2016/08/unikitout-logo.png" alt="UniKitOut logo" width="101" height="92" /></a></strong>\r\n\r\n<strong>UniKitOut</strong>\r\nUniKitOut are specialist suppliers of student essentials; they provide what you need. UniKitOut are the one stop shop for student essentials. They offer huge discounts on Student Bed Packs, Student Kitchen Packs, Student Bathroom and Towel Packs, Student Combo Packs, Electricals, Accessories and much more – they even deliver direct to your halls so everything is waiting for you upon your arrival! <strong>Quote VHALL16 to receive a 10% discount.\r\n</strong><a title="UniKitOut" href="http://www.unikitout.com/collections/victoria" target="_blank">http://www.unikitout.com</a>', 'Partners', '', 'inherit', 'closed', 'closed', '', '177-revision-v1', '', '', '2016-08-26 11:40:09', '2016-08-26 11:40:09', '', 177, 'http://host.dev/177-revision-v1/', 0, 'revision', '', 0),
(179, 1, '2016-08-26 11:41:08', '2016-08-26 11:41:08', 'Victoria Hall treats your privacy seriously. In general, we use the personal information that we collect from you to identify personal preferences and match your needs with relevant services and features on our website. NOTE This policy only applies to the website and not to the companies, individuals, organisations or other websites to which there are links.\r\n\r\n<strong>1. Consent</strong>\r\nYour use of this website signifies your consent to us collecting and using personal information about you as specified below in accordance with this Policy. Should we choose to change our Policy for any reason, the changes will be posted on this website, so that you are always kept informed of how we collect and use your personal information, and when we may disclose it.\r\n\r\n<strong>2.</strong> How Do We Collect Information About You and How Is It Used?\r\n\r\n<strong>2.1</strong> You may provide personal information by telephone, online registration, e-mail, automatically by your Internet browser, or by post when communicating with us.\r\n\r\n<strong>2.2</strong> When you order a service with Victoria Hall you may be asked for your name, address, e-mail address, telephone number, and credit or debit card number details so that your order can be processed.\r\n\r\n<strong>2.3</strong> Our primary reason for collecting data is to personalise your visits to our web site and recommend products or services to you. We may also use the information to help us develop the design and layout of our web site to ensure that our sites are as useful and enjoyable as possible.\r\n\r\n<strong>2.4</strong> We will collect information about your tastes and preferences both when you tell us what these are and by analysis of customer traffic by using cookies. This enables us to monitor accessibility of our service, and helps us to develop and improve our service in response to customer requirements.\r\n\r\n<strong>2.5</strong> We may use personal information collected about you to let you know about new products or services, functionality changes to our web site or changes to our terms and conditions of use.\r\n\r\n<strong>2.6 How do we protect your Information?</strong>\r\nVictoria Hall is serious about guarding the security of your personal details. When you register data such as credit card details with us, they are protected by a secure server, which encrypts the information that you input before it is transmitted to us. In addition, we have strict security procedures covering the storage and disclosure of your information in order to prevent unauthorised access and to comply with the Data Protection Act 1998. This means that sometimes we may ask you for proof of identity before disclosing any personal information to you.\r\n\r\n<strong>2.7 Cookies</strong>\r\nA cookie is a piece of information, like a tag, that is stored on your computer’s hard drive by your web browser when you visit a site. As with many other on line services, Victoria Hall uses cookies to gather certain usage information such as how and when pages in our site are visited, and by how many people. You can set your browser to refuse cookies or show when a cookie is being set up without affecting your use of most of the features of the Victoria Hall website.\r\n\r\n<strong>2.8 Disclosures</strong>\r\nVictoria Hall has a responsibility to keep your information confidential and we take all reasonable care to prevent any unauthorised access to your personal data. We do not disclose information that you may give, such as name, address, telephone number or e-mail address to any outside companies. However, Victoria Hall reserves the right to access and disclose individually identifiable information to comply with applicable laws and lawful government requests, to operate its systems properly or to protect itself or its users.\r\n\r\n<strong>2.9 Contacting Us</strong>\r\nIf you have any questions or concerns about our use of your personal information you should email us at<a href="mailto:info@www.victoriahalls.com">info@www.victoriahalls.com</a>', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2016-08-26 11:41:08', '2016-08-26 11:41:08', '', 0, 'http://host.dev/?page_id=179', 0, 'page', '', 0),
(180, 1, '2016-08-26 11:41:08', '2016-08-26 11:41:08', 'Victoria Hall treats your privacy seriously. In general, we use the personal information that we collect from you to identify personal preferences and match your needs with relevant services and features on our website. NOTE This policy only applies to the website and not to the companies, individuals, organisations or other websites to which there are links.\r\n\r\n<strong>1. Consent</strong>\r\nYour use of this website signifies your consent to us collecting and using personal information about you as specified below in accordance with this Policy. Should we choose to change our Policy for any reason, the changes will be posted on this website, so that you are always kept informed of how we collect and use your personal information, and when we may disclose it.\r\n\r\n<strong>2.</strong> How Do We Collect Information About You and How Is It Used?\r\n\r\n<strong>2.1</strong> You may provide personal information by telephone, online registration, e-mail, automatically by your Internet browser, or by post when communicating with us.\r\n\r\n<strong>2.2</strong> When you order a service with Victoria Hall you may be asked for your name, address, e-mail address, telephone number, and credit or debit card number details so that your order can be processed.\r\n\r\n<strong>2.3</strong> Our primary reason for collecting data is to personalise your visits to our web site and recommend products or services to you. We may also use the information to help us develop the design and layout of our web site to ensure that our sites are as useful and enjoyable as possible.\r\n\r\n<strong>2.4</strong> We will collect information about your tastes and preferences both when you tell us what these are and by analysis of customer traffic by using cookies. This enables us to monitor accessibility of our service, and helps us to develop and improve our service in response to customer requirements.\r\n\r\n<strong>2.5</strong> We may use personal information collected about you to let you know about new products or services, functionality changes to our web site or changes to our terms and conditions of use.\r\n\r\n<strong>2.6 How do we protect your Information?</strong>\r\nVictoria Hall is serious about guarding the security of your personal details. When you register data such as credit card details with us, they are protected by a secure server, which encrypts the information that you input before it is transmitted to us. In addition, we have strict security procedures covering the storage and disclosure of your information in order to prevent unauthorised access and to comply with the Data Protection Act 1998. This means that sometimes we may ask you for proof of identity before disclosing any personal information to you.\r\n\r\n<strong>2.7 Cookies</strong>\r\nA cookie is a piece of information, like a tag, that is stored on your computer’s hard drive by your web browser when you visit a site. As with many other on line services, Victoria Hall uses cookies to gather certain usage information such as how and when pages in our site are visited, and by how many people. You can set your browser to refuse cookies or show when a cookie is being set up without affecting your use of most of the features of the Victoria Hall website.\r\n\r\n<strong>2.8 Disclosures</strong>\r\nVictoria Hall has a responsibility to keep your information confidential and we take all reasonable care to prevent any unauthorised access to your personal data. We do not disclose information that you may give, such as name, address, telephone number or e-mail address to any outside companies. However, Victoria Hall reserves the right to access and disclose individually identifiable information to comply with applicable laws and lawful government requests, to operate its systems properly or to protect itself or its users.\r\n\r\n<strong>2.9 Contacting Us</strong>\r\nIf you have any questions or concerns about our use of your personal information you should email us at<a href="mailto:info@www.victoriahalls.com">info@www.victoriahalls.com</a>', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '179-revision-v1', '', '', '2016-08-26 11:41:08', '2016-08-26 11:41:08', '', 179, 'http://host.dev/179-revision-v1/', 0, 'revision', '', 0),
(181, 1, '2016-08-26 11:42:20', '2016-08-26 11:42:20', 'For further details on any positions available, including salary and job descriptions please contact the relevant Hall.\r\n\r\nCompleted applications should be returned to the relevant hall. Please view our <a href="http://host.dev/contact/">contact details</a> for email and postal addresses.\r\n\r\n<strong>Managerial Positions:</strong>\r\n\r\nN/A\r\n\r\n<strong>Non-Management Positions:</strong>\r\n\r\nN/A', 'Careers', '', 'publish', 'closed', 'closed', '', 'careers', '', '', '2016-08-26 11:42:20', '2016-08-26 11:42:20', '', 0, 'http://host.dev/?page_id=181', 0, 'page', '', 0),
(182, 1, '2016-08-26 11:42:20', '2016-08-26 11:42:20', 'For further details on any positions available, including salary and job descriptions please contact the relevant Hall.\r\n\r\nCompleted applications should be returned to the relevant hall. Please view our <a href="http://host.dev/contact/">contact details</a> for email and postal addresses.\r\n\r\n<strong>Managerial Positions:</strong>\r\n\r\nN/A\r\n\r\n<strong>Non-Management Positions:</strong>\r\n\r\nN/A', 'Careers', '', 'inherit', 'closed', 'closed', '', '181-revision-v1', '', '', '2016-08-26 11:42:20', '2016-08-26 11:42:20', '', 181, 'http://host.dev/181-revision-v1/', 0, 'revision', '', 0),
(183, 1, '2016-08-26 11:43:20', '2016-08-26 11:43:20', 'Host Students has been working with international agents for many years and we are experienced in ensuring that our international students get the best possible experience from their accommodation whilst studying in the UK.\r\n\r\nHost Students has been awarded the prestigious International Quality Award Mark from The National Student Housing Survey each year since 2011. This award credits organisations achieving a minimum of 90% satisfaction among international students and it has only bestowed on between 5 and 8 organisations, including universities, each year.\r\n\r\nWe are actively interested in working with new international agents and would welcome the possibility of agreements with any agents looking to refer their students into our accommodation. If you are interested in working with Host Students, please complete the form below, giving as much information as possible to allow us to respond to your enquiry.', 'Agents', '', 'publish', 'closed', 'closed', '', 'agents', '', '', '2016-08-26 11:43:20', '2016-08-26 11:43:20', '', 0, 'http://host.dev/?page_id=183', 0, 'page', '', 0),
(184, 1, '2016-08-26 11:43:20', '2016-08-26 11:43:20', 'Host Students has been working with international agents for many years and we are experienced in ensuring that our international students get the best possible experience from their accommodation whilst studying in the UK.\r\n\r\nHost Students has been awarded the prestigious International Quality Award Mark from The National Student Housing Survey each year since 2011. This award credits organisations achieving a minimum of 90% satisfaction among international students and it has only bestowed on between 5 and 8 organisations, including universities, each year.\r\n\r\nWe are actively interested in working with new international agents and would welcome the possibility of agreements with any agents looking to refer their students into our accommodation. If you are interested in working with Host Students, please complete the form below, giving as much information as possible to allow us to respond to your enquiry.', 'Agents', '', 'inherit', 'closed', 'closed', '', '183-revision-v1', '', '', '2016-08-26 11:43:20', '2016-08-26 11:43:20', '', 183, 'http://host.dev/183-revision-v1/', 0, 'revision', '', 0),
(185, 1, '2016-08-26 11:44:41', '2016-08-26 11:44:41', ' ', '', '', 'publish', 'closed', 'closed', '', '185', '', '', '2016-08-26 11:44:41', '2016-08-26 11:44:41', '', 0, 'http://host.dev/?p=185', 6, 'nav_menu_item', '', 0),
(186, 1, '2016-08-26 11:44:41', '2016-08-26 11:44:41', ' ', '', '', 'publish', 'closed', 'closed', '', '186', '', '', '2016-08-26 11:44:41', '2016-08-26 11:44:41', '', 0, 'http://host.dev/?p=186', 5, 'nav_menu_item', '', 0),
(187, 1, '2016-08-26 11:44:41', '2016-08-26 11:44:41', ' ', '', '', 'publish', 'closed', 'closed', '', '187', '', '', '2016-08-26 11:44:41', '2016-08-26 11:44:41', '', 0, 'http://host.dev/?p=187', 4, 'nav_menu_item', '', 0),
(188, 1, '2016-08-26 11:44:41', '2016-08-26 11:44:41', ' ', '', '', 'publish', 'closed', 'closed', '', '188', '', '', '2016-08-26 11:44:41', '2016-08-26 11:44:41', '', 0, 'http://host.dev/?p=188', 3, 'nav_menu_item', '', 0),
(189, 1, '2016-08-26 11:44:41', '2016-08-26 11:44:41', ' ', '', '', 'publish', 'closed', 'closed', '', '189', '', '', '2016-08-26 11:44:41', '2016-08-26 11:44:41', '', 0, 'http://host.dev/?p=189', 2, 'nav_menu_item', '', 0),
(190, 1, '2016-08-26 11:44:41', '2016-08-26 11:44:41', ' ', '', '', 'publish', 'closed', 'closed', '', '190', '', '', '2016-08-26 11:44:41', '2016-08-26 11:44:41', '', 0, 'http://host.dev/?p=190', 1, 'nav_menu_item', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(191, 1, '2016-08-30 08:07:08', '2016-08-30 08:07:08', '<a href="#who">Who are Host Students?</a>\r\n<a href="#where">Where does Host Students have accommodation?</a>\r\n<a href="#why">Why should I stay at Host Students?</a>\r\n<a href="#student">Do I have to be a student to live at Host Students?</a>\r\n<a href="#booking">How can I make a booking?</a>\r\n<a href="#deposit">Do I pay a deposit?</a>\r\n<a href="#terms">What are the Terms and Conditions of staying at Host Students?</a>\r\n<a href="#guarantor">What does being a Guarantor mean?</a>\r\n<a href="#rent">When do I pay my rent?</a>\r\n<a href="#insurance">Do I need to take out Contents Insurance?</a>\r\n<a href="#internet">Can I connect to the internet?</a>\r\n<a href="#holidays">Do I need to move out during the holidays?</a>\r\n<a href="#halls">Do you have staff at your halls?</a>\r\n<a href="#office">When is the Management Office open?</a>\r\n<a href="#safety">What about safety?</a>\r\n<a href="#maintenance">What happens if I have a maintenance problem and something stops working?</a>\r\n<a href="#furnished">What does it mean when you say the kitchens are fully furnished?</a>\r\n<a href="#furnished">How do I know that Host Students is a good landlord?</a>\r\n\r\n<a name="who"></a>\r\n<strong><span class="bold-header">Who are Host Students?</span></strong>\r\nHost Students is a private company that has been building and managing premium quality student accommodation since 1996. We believe that modern student accommodation should be well located, comfortable, stylish and affordable to rent.\r\n\r\n<strong><a name="where"></a></strong>\r\n<strong><span class="bold-header">Where does Host Students have accommodation?\r\n</span></strong>\r\n\r\nWe currently have student accommodation located in Birmingham (Grange Road and Dale Road), Cardiff (Blackweir Terrace and Shand House), Cambridge (CB1), Chester (Fontessa House), Coventry, Exeter (The Printworks), Glasgow, Liverpool (Hatton Garden and Hope Street), Leicester (Castle Street and The Glassworks), London (Dashwood Studios, Wembley, Paul St. East, King’s Cross, The Hive, The Hub and One Penrhyn Road), Manchester (Higher Cambridge Street and Upper Brook Street), Newcastle Upon Tyne, Nottingham (Curzon Street and Lace Market Studios), Oxford (The Mews), Plymouth (The Old Dairy and Frobisher House), Sheffield (Eldon Street and Denby Street), Wolverhampton, Cork (Ireland), Bremen (Germany) and Valencia (Spain).\r\n\r\n<a name="why"></a>\r\n<strong><span class="bold-header">Why should I stay at Host Students?\r\n</span></strong>Host Students is an ideal place to live if you wish to pursue your academic life boasting unrivalled locations close to university campuses. Host Students provides a perfect and safe environment in order to ensure our students can obtain maximum benefit from all aspects of university life. Voted Best Private Halls Provider and awarded with an International Accommodation Quality Mark in the National Student Housing Survey in 2011 and 2012, the question should really be, why should I not stay at Host Students?\r\n\r\n<a name="student"></a>\r\n<strong><span class="bold-header">Do I have to be a student to live at Host Students?</span></strong>\r\nTo take out a tenancy with us you need to be eligible for council tax exemption. This applies to all full-time students and some part-time students if you are unsure your university or college should be able to advise you whether you are exempt.\r\n\r\n<a name="booking"></a>\r\n<strong><span class="bold-header">How can I make a booking?</span></strong>\r\nThe application process varies in our halls. In many of our halls, it is possible to book direct with Host Students. This can be done using our online booking service on this website. Alternatively, a hard copy of our application booklet can be downloaded from the relevant section of the website in your chosen Hall’s website. We can also send a copy either by email or post, or they can be collected from the management office.\r\n\r\nIn order for a direct booking to be confirmed all required documents must be returned including a guarantor agreement, tenancy agreement, initial rent payment and provision for your rent payments. Any incomplete or incorrect applications will not be accepted. A booking will only be confirmed by Host Students once all necessary documentation has been supplied.\r\n\r\nIn some of our halls, it is not possible to book directly with Host Students and you must apply through the relevant university accommodation office. For further information visit the FAQ section on the website for your chosen hall.\r\n\r\n<a name="deposit"></a>\r\n<strong><span class="bold-header">Do I pay a deposit?</span></strong>\r\nHost Students does not take any deposits. Any payment you make upon booking is part of your rental payment.\r\n\r\n<a name="terms"></a>\r\n<strong><span class="bold-header">What are the Terms and Conditions of staying at Host Students?</span></strong>\r\nAll rooms that are let directly to students are done so using an assured short-hold tenancy agreement (or Short Assured Tenancy Agreement in Scotland) These agreements outline what is expected of the resident and in turn the obligations of Host Students as a landlord. The agreements are a legally binding document and should be read carefully. Once signed they are for a fixed term and should the resident wish to move out of the accommodation before the end date, they will remain liable for the full rent until the end of the contracted period and are responsible for the condition of the property regardless of whether they are staying in the hall or not.\r\n\r\nFor halls where you book through a university accommodation office rather than directly with Host Students you may be provided with a different type of Agreement, please visit FAQ section on the website for your chosen hall for further information.\r\n\r\n<a name="guarantor"></a>\r\n<strong><span class="bold-header">What does being a Guarantor mean?</span></strong>\r\nAll students who wish to take up our rent installment plan are required to provide a UK guarantor (excludes the Isle of Man and Channel Islands). By agreeing to be a guarantor you are signing a legal document stating that you agree to pay the rent and guarantee the behaviour of the resident if they default. <strong>Please do not sign this agreement if you do not wish to take on this responsibility.</strong> Any student who does not have a UK guarantor will be required to pay the full year’s rent upon application.\r\n\r\n<a name="rent"></a>\r\n<strong><span class="bold-header">When do I pay my rent?</span></strong>\r\nOur rent dates and amounts are set out clearly within our application literature. Please note that rent may be due before the contract begins and that the dates may not coincide with student loan dates. This should be taken into consideration when planning your accommodation as late payments may be subject to interest charges and, in some cases, legal action against the resident and their guarantor.\r\n\r\n<a name="insurance"></a>\r\n<strong><span class="bold-header">Do I need to take out Contents Insurance?</span></strong>\r\nAt Host Students, we provide you with contents insurance for your belongings free of charge. When you arrive we will provide you with details of the policy and if you need anything extra adding to the cover you can contact them to arrange an upgrade.\r\n\r\n<a name="internet"></a>\r\n<strong><span class="bold-header">Can I connect to the internet?</span></strong>\r\nThere is a superfast internet connection available in every bedroom at Host Students. Broadband arrangements vary in some halls so please visit the site-specific FAQs or contact your chosen hall for further information.\r\n\r\n<a name="holidays"></a>\r\n<strong><span class="bold-header">Do I need to move out during the holidays?</span></strong>\r\nYour contract at Host Students is for a fixed length of time and you can stay at the Hall throughout this period. That means that you don’t have to move your belongings out during the Christmas or Easter vacations and you can choose the stay in the hall over these holidays if you want. It is usually possible to book additional accommodation over the summer period should you want to stay then also, although we advise that you book early to ensure rooms are available.\r\n\r\n<a name="halls"></a>\r\n<strong><span class="bold-header">Do you have staff at your halls</span></strong>\r\nAll of our Halls have a team of Host Students staff based on site to respond to the needs of our residents. Staff undertake suitable training for their role and are criminal record background checked.\r\n\r\nOur on-site management office is open Monday to Friday and management are there to answer questions, respond to any issues, offer advice and be a friendly face on a day to day basis.\r\n\r\nMany of our halls have a highly skilled team of caretakers who are available around the clock. They are there to resolve maintenance issues quickly and efficiently and to ensure that the site remains a safe and secure environment for our residents. Security guards also supplement the caretaker team to ensure that most sites have a presence 24 hours a day, 7 days a week. Please check at your chosen Host Students for further details as this service may not be available in your hall.\r\n\r\nOur staff are not just there to upkeep the property, they want to make the experience of living at Host Students to be enjoyable for all residents. Whilst the majority of students settle into university life and living away from home quickly, we understand that for some students, this can take a little longer than for others. Whilst we are ultimately restricted in the involvement we can have due to the tenancy agreement, our staff have experience in dealing with a range of issues and can usually assist with offering advice to help residents overcome those initial problems.\r\n\r\n<a name="office"></a>\r\n<strong><span class="bold-header">When is the Management Office open?</span></strong>\r\nThe management office is open Monday to Friday each week. The opening hours are 9am – 6pm Monday –Thursday and 9am – 5pm on a Friday.\r\n\r\n<a name="safety"></a>\r\n<strong><span class="bold-header">What about safety?</span></strong>\r\nHost Students takes our residents safety very seriously. Many of our halls have a member of staff or security guard on site 24 hours a day, 7 days a week, throughout the year to ensure there is always someone on site to offer assistance should the need arise (please check with your chosen hall that this service is available)\r\n\r\nElectronic door entry systems, intercoms and CCTV offer further security to ensure that Host Students offers a high standard of security and the safest possible environment for our residents\r\n\r\n<a name="maintenance "></a>\r\n\r\n<strong><span class="bold-header">What happens if I have a maintenance problem and something stops working?</span></strong>\r\nEvery Host Students has a dedicated caretaker team to respond to and resolve your maintenance issues. We aim to respond to your problem in a timely manner and wherever possible will complete a repair during the first visit. Of course, this isn’t always possible and there are times when parts need to be ordered or external contractors arranged – in these instances we aim to keep you updated with the progress of the issue as much as possible.\r\n\r\n<a name="furnished"></a>\r\n<strong><span class="bold-header">What does it mean when you say the kitchens are fully furnished?</span></strong>\r\nHost Students designs flats that provide you with everything you need to enjoy student living with us. Our flats come fully kitted out with all your cooking appliances provided: cooker, hob, kettle, toaster and microwave. For sites where cutlery, crockery and cooking utensils are not provided, you will need to bring your own or purchase a kitchen pack from <a href="http://www.unikitout.com/collections/victoria" target="_blank">UniKitOut</a> prior to coming to the University. <strong>Quote VHALL16 to receive a 10% discount.</strong>\r\n\r\n<a name="landlord"></a>\r\n<strong><span class="bold-header">How do I know that Host Students is a good landlord?</span></strong>\r\nHost Students has agreed to the principals required by the ANUK Code of Standards. The National Code is voluntary and aimed at both educational establishments and private sector suppliers. Those who join, do so as part of their commitment to providing students with a first-class housing service.\r\nThose who join the Code provide you with information, reassurance and a procedure that you can follow if a dispute occurs.\r\nThe Code is fully supported by NUS who are a key stakeholder and have representation on the management and complaints procedures of the Code.\r\nThe Code will act as a student accommodation quality guide and, if you have a choice, always rent from a housing supplier who has joined the Code.\r\nHere are the advantages of living in a building covered by the Code:\r\n<ul>\r\n 	<li>best practice in day to day management is supported and recognised.</li>\r\n 	<li>your contract is clearly written, stating what you are paying for and how much your rent is, with reasonable terms and no hidden costs.</li>\r\n 	<li>your accommodation should be fully prepared for you when you arrive to take up residence.</li>\r\n 	<li>your accommodation meets with a set of nationally recognised standards in respect of services, furniture and fittings.</li>\r\n 	<li>repairs and maintenance are carried out within agreed timescales.</li>\r\n 	<li>your building will meet with, and exceed the required health and safety standards.</li>\r\n 	<li>you will be given information to explain what management routines are followed in the buildings.</li>\r\n 	<li>there is a set and accountable procedure for dealing with any disputes or complaints.</li>\r\n</ul>', 'FAQs', '', 'publish', 'closed', 'closed', '', 'faqs', '', '', '2016-08-30 08:10:05', '2016-08-30 08:10:05', '', 0, 'http://host.dev/?page_id=191', 0, 'page', '', 0),
(192, 1, '2016-08-30 08:07:08', '2016-08-30 08:07:08', '<a href="#who">Who are Victoria Hall?</a>\r\n<a href="#where">Where does Victoria Hall have accommodation?</a>\r\n<a href="#why">Why should I stay at Victoria Hall?</a>\r\n<a href="#student">Do I have to be a student to live at Victoria Hall?</a>\r\n<a href="#booking">How can I make a booking?</a>\r\n<a href="#deposit">Do I pay a deposit?</a>\r\n<a href="#terms">What are the Terms and Conditions of staying at Victoria Hall?</a>\r\n<a href="#guarantor">What does being a Guarantor mean?</a>\r\n<a href="#rent">When do I pay my rent?</a>\r\n<a href="#insurance">Do I need to take out Contents Insurance?</a>\r\n<a href="#internet">Can I connect to the internet?</a>\r\n<a href="#holidays">Do I need to move out during the holidays?</a>\r\n<a href="#halls">Do you have staff at your halls?</a>\r\n<a href="#office">When is the Management Office open?</a>\r\n<a href="#safety">What about safety?</a>\r\n<a href="#maintenance">What happens if I have a maintenance problem and something stops working?</a>\r\n<a href="#furnished">What does it mean when you say the kitchens are fully furnished?</a>\r\n<a href="#furnished">How do I know that Victoria Hall is a good landlord?</a>\r\n\r\n<a name="who"></a>\r\n<strong><span class="bold-header">Who are Victoria Hall?</span></strong>\r\nVictoria Hall is a private company that has been building and managing premium quality student accommodation since 1996. We believe that modern student accommodation should be well located, comfortable, stylish and affordable to rent.\r\n\r\n<strong><a name="where"></a></strong>\r\n<strong><span class="bold-header">Where does Victoria Hall have accommodation?\r\n</span></strong>\r\n\r\nWe currently have student accommodation located in Birmingham (Grange Road and Dale Road), Cardiff (Blackweir Terrace and Shand House), Cambridge (CB1), Chester (Fontessa House), Coventry, Exeter (The Printworks), Glasgow, Liverpool (Hatton Garden and Hope Street), Leicester (Castle Street and The Glassworks), London (Dashwood Studios, Wembley, Paul St. East, King’s Cross, The Hive, The Hub and One Penrhyn Road), Manchester (Higher Cambridge Street and Upper Brook Street), Newcastle Upon Tyne, Nottingham (Curzon Street and Lace Market Studios), Oxford (The Mews), Plymouth (The Old Dairy and Frobisher House), Sheffield (Eldon Street and Denby Street), Wolverhampton, Cork (Ireland), Bremen (Germany) and Valencia (Spain).\r\n\r\n<a name="why"></a>\r\n<strong><span class="bold-header">Why should I stay at Victoria Hall?\r\n</span></strong>Victoria Hall is an ideal place to live if you wish to pursue your academic life boasting unrivalled locations close to university campuses. Victoria Hall provides a perfect and safe environment in order to ensure our students can obtain maximum benefit from all aspects of university life. Voted Best Private Halls Provider and awarded with an International Accommodation Quality Mark in the National Student Housing Survey in 2011 and 2012, the question should really be, why should I not stay at Victoria Hall?\r\n\r\n<a name="student"></a>\r\n<strong><span class="bold-header">Do I have to be a student to live at Victoria Hall?</span></strong>\r\nTo take out a tenancy with us you need to be eligible for council tax exemption. This applies to all full-time students and some part-time students if you are unsure your university or college should be able to advise you whether you are exempt.\r\n\r\n<a name="booking"></a>\r\n<strong><span class="bold-header">How can I make a booking?</span></strong>\r\nThe application process varies in our halls. In many of our halls, it is possible to book direct with Victoria Hall. This can be done using our online booking service on this website. Alternatively, a hard copy of our application booklet can be downloaded from the relevant section of the website in your chosen Hall’s website. We can also send a copy either by email or post, or they can be collected from the management office.\r\n\r\nIn order for a direct booking to be confirmed all required documents must be returned including a guarantor agreement, tenancy agreement, initial rent payment and provision for your rent payments. Any incomplete or incorrect applications will not be accepted. A booking will only be confirmed by Victoria Hall once all necessary documentation has been supplied.\r\n\r\nIn some of our halls, it is not possible to book directly with Victoria Hall and you must apply through the relevant university accommodation office. For further information visit the FAQ section on the website for your chosen hall.\r\n\r\n<a name="deposit"></a>\r\n<strong><span class="bold-header">Do I pay a deposit?</span></strong>\r\nVictoria Hall does not take any deposits. Any payment you make upon booking is part of your rental payment.\r\n\r\n<a name="terms"></a>\r\n<strong><span class="bold-header">What are the Terms and Conditions of staying at Victoria Hall?</span></strong>\r\nAll rooms that are let directly to students are done so using an assured short-hold tenancy agreement (or Short Assured Tenancy Agreement in Scotland) These agreements outline what is expected of the resident and in turn the obligations of Victoria Hall as a landlord. The agreements are a legally binding document and should be read carefully. Once signed they are for a fixed term and should the resident wish to move out of the accommodation before the end date, they will remain liable for the full rent until the end of the contracted period and are responsible for the condition of the property regardless of whether they are staying in the hall or not.\r\n\r\nFor halls where you book through a university accommodation office rather than directly with Victoria Hall you may be provided with a different type of Agreement, please visit FAQ section on the website for your chosen hall for further information.\r\n\r\n<a name="guarantor"></a>\r\n<strong><span class="bold-header">What does being a Guarantor mean?</span></strong>\r\nAll students who wish to take up our rent installment plan are required to provide a UK guarantor (excludes the Isle of Man and Channel Islands). By agreeing to be a guarantor you are signing a legal document stating that you agree to pay the rent and guarantee the behaviour of the resident if they default. <strong>Please do not sign this agreement if you do not wish to take on this responsibility.</strong> Any student who does not have a UK guarantor will be required to pay the full year’s rent upon application.\r\n\r\n<a name="rent"></a>\r\n<strong><span class="bold-header">When do I pay my rent?</span></strong>\r\nOur rent dates and amounts are set out clearly within our application literature. Please note that rent may be due before the contract begins and that the dates may not coincide with student loan dates. This should be taken into consideration when planning your accommodation as late payments may be subject to interest charges and, in some cases, legal action against the resident and their guarantor.\r\n\r\n<a name="insurance"></a>\r\n<strong><span class="bold-header">Do I need to take out Contents Insurance?</span></strong>\r\nAt Victoria Hall, we provide you with contents insurance for your belongings free of charge. When you arrive we will provide you with details of the policy and if you need anything extra adding to the cover you can contact them to arrange an upgrade.\r\n\r\n<a name="internet"></a>\r\n<strong><span class="bold-header">Can I connect to the internet?</span></strong>\r\nThere is a superfast internet connection available in every bedroom at Victoria Hall. Broadband arrangements vary in some halls so please visit the site-specific FAQs or contact your chosen hall for further information.\r\n\r\n<a name="holidays"></a>\r\n<strong><span class="bold-header">Do I need to move out during the holidays?</span></strong>\r\nYour contract at Victoria Hall is for a fixed length of time and you can stay at the Hall throughout this period. That means that you don’t have to move your belongings out during the Christmas or Easter vacations and you can choose the stay in the hall over these holidays if you want. It is usually possible to book additional accommodation over the summer period should you want to stay then also, although we advise that you book early to ensure rooms are available.\r\n\r\n<a name="halls"></a>\r\n<strong><span class="bold-header">Do you have staff at your halls</span></strong>\r\nAll of our Halls have a team of Victoria Hall staff based on site to respond to the needs of our residents. Staff undertake suitable training for their role and are criminal record background checked.\r\n\r\nOur on-site management office is open Monday to Friday and management are there to answer questions, respond to any issues, offer advice and be a friendly face on a day to day basis.\r\n\r\nMany of our halls have a highly skilled team of caretakers who are available around the clock. They are there to resolve maintenance issues quickly and efficiently and to ensure that the site remains a safe and secure environment for our residents. Security guards also supplement the caretaker team to ensure that most sites have a presence 24 hours a day, 7 days a week. Please check at your chosen Victoria Hall for further details as this service may not be available in your hall.\r\n\r\nOur staff are not just there to upkeep the property, they want to make the experience of living at Victoria Hall to be enjoyable for all residents. Whilst the majority of students settle into university life and living away from home quickly, we understand that for some students, this can take a little longer than for others. Whilst we are ultimately restricted in the involvement we can have due to the tenancy agreement, our staff have experience in dealing with a range of issues and can usually assist with offering advice to help residents overcome those initial problems.\r\n\r\n<a name="office"></a>\r\n<strong><span class="bold-header">When is the Management Office open?</span></strong>\r\nThe management office is open Monday to Friday each week. The opening hours are 9am – 6pm Monday –Thursday and 9am – 5pm on a Friday.\r\n\r\n<a name="safety"></a>\r\n<strong><span class="bold-header">What about safety?</span></strong>\r\nVictoria Hall takes our residents safety very seriously. Many of our halls have a member of staff or security guard on site 24 hours a day, 7 days a week, throughout the year to ensure there is always someone on site to offer assistance should the need arise (please check with your chosen hall that this service is available)\r\n\r\nElectronic door entry systems, intercoms and CCTV offer further security to ensure that Victoria Hall offers a high standard of security and the safest possible environment for our residents\r\n\r\n<a name="maintenance "></a>\r\n\r\n<strong><span class="bold-header">What happens if I have a maintenance problem and something stops working?</span></strong>\r\nEvery Victoria Hall has a dedicated caretaker team to respond to and resolve your maintenance issues. We aim to respond to your problem in a timely manner and wherever possible will complete a repair during the first visit. Of course, this isn’t always possible and there are times when parts need to be ordered or external contractors arranged – in these instances we aim to keep you updated with the progress of the issue as much as possible.\r\n\r\n<a name="furnished"></a>\r\n<strong><span class="bold-header">What does it mean when you say the kitchens are fully furnished?</span></strong>\r\nVictoria Hall designs flats that provide you with everything you need to enjoy student living with us. Our flats come fully kitted out with all your cooking appliances provided: cooker, hob, kettle, toaster and microwave. For sites where cutlery, crockery and cooking utensils are not provided, you will need to bring your own or purchase a kitchen pack from <a href="http://www.unikitout.com/collections/victoria" target="_blank">UniKitOut</a> prior to coming to the University. <strong>Quote VHALL16 to receive a 10% discount.</strong>\r\n\r\n<a name="landlord"></a>\r\n<strong><span class="bold-header">How do I know that Victoria Hall is a good landlord?</span></strong>\r\nVictoria Hall has agreed to the principals required by the ANUK Code of Standards. The National Code is voluntary and aimed at both educational establishments and private sector suppliers. Those who join, do so as part of their commitment to providing students with a first-class housing service.\r\nThose who join the Code provide you with information, reassurance and a procedure that you can follow if a dispute occurs.\r\nThe Code is fully supported by NUS who are a key stakeholder and have representation on the management and complaints procedures of the Code.\r\nThe Code will act as a student accommodation quality guide and, if you have a choice, always rent from a housing supplier who has joined the Code.\r\nHere are the advantages of living in a building covered by the Code:\r\n<ul>\r\n 	<li>best practice in day to day management is supported and recognised.</li>\r\n 	<li>your contract is clearly written, stating what you are paying for and how much your rent is, with reasonable terms and no hidden costs.</li>\r\n 	<li>your accommodation should be fully prepared for you when you arrive to take up residence.</li>\r\n 	<li>your accommodation meets with a set of nationally recognised standards in respect of services, furniture and fittings.</li>\r\n 	<li>repairs and maintenance are carried out within agreed timescales.</li>\r\n 	<li>your building will meet with, and exceed the required health and safety standards.</li>\r\n 	<li>you will be given information to explain what management routines are followed in the buildings.</li>\r\n 	<li>there is a set and accountable procedure for dealing with any disputes or complaints.</li>\r\n</ul>', 'FAQs', '', 'inherit', 'closed', 'closed', '', '191-revision-v1', '', '', '2016-08-30 08:07:08', '2016-08-30 08:07:08', '', 191, 'http://host.dev/191-revision-v1/', 0, 'revision', '', 0),
(193, 1, '2016-08-30 08:10:05', '2016-08-30 08:10:05', '<a href="#who">Who are Host Students?</a>\r\n<a href="#where">Where does Host Students have accommodation?</a>\r\n<a href="#why">Why should I stay at Host Students?</a>\r\n<a href="#student">Do I have to be a student to live at Host Students?</a>\r\n<a href="#booking">How can I make a booking?</a>\r\n<a href="#deposit">Do I pay a deposit?</a>\r\n<a href="#terms">What are the Terms and Conditions of staying at Host Students?</a>\r\n<a href="#guarantor">What does being a Guarantor mean?</a>\r\n<a href="#rent">When do I pay my rent?</a>\r\n<a href="#insurance">Do I need to take out Contents Insurance?</a>\r\n<a href="#internet">Can I connect to the internet?</a>\r\n<a href="#holidays">Do I need to move out during the holidays?</a>\r\n<a href="#halls">Do you have staff at your halls?</a>\r\n<a href="#office">When is the Management Office open?</a>\r\n<a href="#safety">What about safety?</a>\r\n<a href="#maintenance">What happens if I have a maintenance problem and something stops working?</a>\r\n<a href="#furnished">What does it mean when you say the kitchens are fully furnished?</a>\r\n<a href="#furnished">How do I know that Host Students is a good landlord?</a>\r\n\r\n<a name="who"></a>\r\n<strong><span class="bold-header">Who are Host Students?</span></strong>\r\nHost Students is a private company that has been building and managing premium quality student accommodation since 1996. We believe that modern student accommodation should be well located, comfortable, stylish and affordable to rent.\r\n\r\n<strong><a name="where"></a></strong>\r\n<strong><span class="bold-header">Where does Host Students have accommodation?\r\n</span></strong>\r\n\r\nWe currently have student accommodation located in Birmingham (Grange Road and Dale Road), Cardiff (Blackweir Terrace and Shand House), Cambridge (CB1), Chester (Fontessa House), Coventry, Exeter (The Printworks), Glasgow, Liverpool (Hatton Garden and Hope Street), Leicester (Castle Street and The Glassworks), London (Dashwood Studios, Wembley, Paul St. East, King’s Cross, The Hive, The Hub and One Penrhyn Road), Manchester (Higher Cambridge Street and Upper Brook Street), Newcastle Upon Tyne, Nottingham (Curzon Street and Lace Market Studios), Oxford (The Mews), Plymouth (The Old Dairy and Frobisher House), Sheffield (Eldon Street and Denby Street), Wolverhampton, Cork (Ireland), Bremen (Germany) and Valencia (Spain).\r\n\r\n<a name="why"></a>\r\n<strong><span class="bold-header">Why should I stay at Host Students?\r\n</span></strong>Host Students is an ideal place to live if you wish to pursue your academic life boasting unrivalled locations close to university campuses. Host Students provides a perfect and safe environment in order to ensure our students can obtain maximum benefit from all aspects of university life. Voted Best Private Halls Provider and awarded with an International Accommodation Quality Mark in the National Student Housing Survey in 2011 and 2012, the question should really be, why should I not stay at Host Students?\r\n\r\n<a name="student"></a>\r\n<strong><span class="bold-header">Do I have to be a student to live at Host Students?</span></strong>\r\nTo take out a tenancy with us you need to be eligible for council tax exemption. This applies to all full-time students and some part-time students if you are unsure your university or college should be able to advise you whether you are exempt.\r\n\r\n<a name="booking"></a>\r\n<strong><span class="bold-header">How can I make a booking?</span></strong>\r\nThe application process varies in our halls. In many of our halls, it is possible to book direct with Host Students. This can be done using our online booking service on this website. Alternatively, a hard copy of our application booklet can be downloaded from the relevant section of the website in your chosen Hall’s website. We can also send a copy either by email or post, or they can be collected from the management office.\r\n\r\nIn order for a direct booking to be confirmed all required documents must be returned including a guarantor agreement, tenancy agreement, initial rent payment and provision for your rent payments. Any incomplete or incorrect applications will not be accepted. A booking will only be confirmed by Host Students once all necessary documentation has been supplied.\r\n\r\nIn some of our halls, it is not possible to book directly with Host Students and you must apply through the relevant university accommodation office. For further information visit the FAQ section on the website for your chosen hall.\r\n\r\n<a name="deposit"></a>\r\n<strong><span class="bold-header">Do I pay a deposit?</span></strong>\r\nHost Students does not take any deposits. Any payment you make upon booking is part of your rental payment.\r\n\r\n<a name="terms"></a>\r\n<strong><span class="bold-header">What are the Terms and Conditions of staying at Host Students?</span></strong>\r\nAll rooms that are let directly to students are done so using an assured short-hold tenancy agreement (or Short Assured Tenancy Agreement in Scotland) These agreements outline what is expected of the resident and in turn the obligations of Host Students as a landlord. The agreements are a legally binding document and should be read carefully. Once signed they are for a fixed term and should the resident wish to move out of the accommodation before the end date, they will remain liable for the full rent until the end of the contracted period and are responsible for the condition of the property regardless of whether they are staying in the hall or not.\r\n\r\nFor halls where you book through a university accommodation office rather than directly with Host Students you may be provided with a different type of Agreement, please visit FAQ section on the website for your chosen hall for further information.\r\n\r\n<a name="guarantor"></a>\r\n<strong><span class="bold-header">What does being a Guarantor mean?</span></strong>\r\nAll students who wish to take up our rent installment plan are required to provide a UK guarantor (excludes the Isle of Man and Channel Islands). By agreeing to be a guarantor you are signing a legal document stating that you agree to pay the rent and guarantee the behaviour of the resident if they default. <strong>Please do not sign this agreement if you do not wish to take on this responsibility.</strong> Any student who does not have a UK guarantor will be required to pay the full year’s rent upon application.\r\n\r\n<a name="rent"></a>\r\n<strong><span class="bold-header">When do I pay my rent?</span></strong>\r\nOur rent dates and amounts are set out clearly within our application literature. Please note that rent may be due before the contract begins and that the dates may not coincide with student loan dates. This should be taken into consideration when planning your accommodation as late payments may be subject to interest charges and, in some cases, legal action against the resident and their guarantor.\r\n\r\n<a name="insurance"></a>\r\n<strong><span class="bold-header">Do I need to take out Contents Insurance?</span></strong>\r\nAt Host Students, we provide you with contents insurance for your belongings free of charge. When you arrive we will provide you with details of the policy and if you need anything extra adding to the cover you can contact them to arrange an upgrade.\r\n\r\n<a name="internet"></a>\r\n<strong><span class="bold-header">Can I connect to the internet?</span></strong>\r\nThere is a superfast internet connection available in every bedroom at Host Students. Broadband arrangements vary in some halls so please visit the site-specific FAQs or contact your chosen hall for further information.\r\n\r\n<a name="holidays"></a>\r\n<strong><span class="bold-header">Do I need to move out during the holidays?</span></strong>\r\nYour contract at Host Students is for a fixed length of time and you can stay at the Hall throughout this period. That means that you don’t have to move your belongings out during the Christmas or Easter vacations and you can choose the stay in the hall over these holidays if you want. It is usually possible to book additional accommodation over the summer period should you want to stay then also, although we advise that you book early to ensure rooms are available.\r\n\r\n<a name="halls"></a>\r\n<strong><span class="bold-header">Do you have staff at your halls</span></strong>\r\nAll of our Halls have a team of Host Students staff based on site to respond to the needs of our residents. Staff undertake suitable training for their role and are criminal record background checked.\r\n\r\nOur on-site management office is open Monday to Friday and management are there to answer questions, respond to any issues, offer advice and be a friendly face on a day to day basis.\r\n\r\nMany of our halls have a highly skilled team of caretakers who are available around the clock. They are there to resolve maintenance issues quickly and efficiently and to ensure that the site remains a safe and secure environment for our residents. Security guards also supplement the caretaker team to ensure that most sites have a presence 24 hours a day, 7 days a week. Please check at your chosen Host Students for further details as this service may not be available in your hall.\r\n\r\nOur staff are not just there to upkeep the property, they want to make the experience of living at Host Students to be enjoyable for all residents. Whilst the majority of students settle into university life and living away from home quickly, we understand that for some students, this can take a little longer than for others. Whilst we are ultimately restricted in the involvement we can have due to the tenancy agreement, our staff have experience in dealing with a range of issues and can usually assist with offering advice to help residents overcome those initial problems.\r\n\r\n<a name="office"></a>\r\n<strong><span class="bold-header">When is the Management Office open?</span></strong>\r\nThe management office is open Monday to Friday each week. The opening hours are 9am – 6pm Monday –Thursday and 9am – 5pm on a Friday.\r\n\r\n<a name="safety"></a>\r\n<strong><span class="bold-header">What about safety?</span></strong>\r\nHost Students takes our residents safety very seriously. Many of our halls have a member of staff or security guard on site 24 hours a day, 7 days a week, throughout the year to ensure there is always someone on site to offer assistance should the need arise (please check with your chosen hall that this service is available)\r\n\r\nElectronic door entry systems, intercoms and CCTV offer further security to ensure that Host Students offers a high standard of security and the safest possible environment for our residents\r\n\r\n<a name="maintenance "></a>\r\n\r\n<strong><span class="bold-header">What happens if I have a maintenance problem and something stops working?</span></strong>\r\nEvery Host Students has a dedicated caretaker team to respond to and resolve your maintenance issues. We aim to respond to your problem in a timely manner and wherever possible will complete a repair during the first visit. Of course, this isn’t always possible and there are times when parts need to be ordered or external contractors arranged – in these instances we aim to keep you updated with the progress of the issue as much as possible.\r\n\r\n<a name="furnished"></a>\r\n<strong><span class="bold-header">What does it mean when you say the kitchens are fully furnished?</span></strong>\r\nHost Students designs flats that provide you with everything you need to enjoy student living with us. Our flats come fully kitted out with all your cooking appliances provided: cooker, hob, kettle, toaster and microwave. For sites where cutlery, crockery and cooking utensils are not provided, you will need to bring your own or purchase a kitchen pack from <a href="http://www.unikitout.com/collections/victoria" target="_blank">UniKitOut</a> prior to coming to the University. <strong>Quote VHALL16 to receive a 10% discount.</strong>\r\n\r\n<a name="landlord"></a>\r\n<strong><span class="bold-header">How do I know that Host Students is a good landlord?</span></strong>\r\nHost Students has agreed to the principals required by the ANUK Code of Standards. The National Code is voluntary and aimed at both educational establishments and private sector suppliers. Those who join, do so as part of their commitment to providing students with a first-class housing service.\r\nThose who join the Code provide you with information, reassurance and a procedure that you can follow if a dispute occurs.\r\nThe Code is fully supported by NUS who are a key stakeholder and have representation on the management and complaints procedures of the Code.\r\nThe Code will act as a student accommodation quality guide and, if you have a choice, always rent from a housing supplier who has joined the Code.\r\nHere are the advantages of living in a building covered by the Code:\r\n<ul>\r\n 	<li>best practice in day to day management is supported and recognised.</li>\r\n 	<li>your contract is clearly written, stating what you are paying for and how much your rent is, with reasonable terms and no hidden costs.</li>\r\n 	<li>your accommodation should be fully prepared for you when you arrive to take up residence.</li>\r\n 	<li>your accommodation meets with a set of nationally recognised standards in respect of services, furniture and fittings.</li>\r\n 	<li>repairs and maintenance are carried out within agreed timescales.</li>\r\n 	<li>your building will meet with, and exceed the required health and safety standards.</li>\r\n 	<li>you will be given information to explain what management routines are followed in the buildings.</li>\r\n 	<li>there is a set and accountable procedure for dealing with any disputes or complaints.</li>\r\n</ul>', 'FAQs', '', 'inherit', 'closed', 'closed', '', '191-revision-v1', '', '', '2016-08-30 08:10:05', '2016-08-30 08:10:05', '', 191, 'http://host.dev/191-revision-v1/', 0, 'revision', '', 0),
(194, 1, '2016-08-30 08:17:46', '2016-08-30 08:17:46', 'Starting university can be a daunting prospect for any student, but even more so for those traveling from overseas, especially for the first time.\r\n\r\nHost Students offers welcoming, secure and affordable accommodation designed to provide all the necessary touches to help our residents feel instantly at home and settle in quickly.\r\n\r\nFully equipped kitchens containing a fridge, freezer, oven and hob, kettle, toaster, microwave, cutlery, crockery and cooking utensils are provided as standard and bedding can be arranged with your hall in advance of your arrival as an optional extra*.\r\n\r\n*<em>not available in all sites, please check with your chosen Hall’s on-site management team.</em>\r\n\r\nOur <a title="Awards" href="http://www.victoriahalls.com/blog/category/awards/">award winning accommodation</a> is located in areas close to universities and college campuses to allow you to fully experience all the benefits of studying and living in your chosen city and socialising with your new friends, whilst telephones in each flat* and internet provided to each bedroom allow you to keep in touch with your friends and family back home.\r\n\r\n<em>*Excludes Dashwood Studios</em>\r\n\r\nEach Host Students accommodation has a dedicated on-site management office where friendly staff can answer day to day queries and offer assistance in helping you settle into life in your new city. The first class service offered to our overseas students has been recognised by the award of a Quality Mark for International Accommodation in 2011, an award given to only 5 providers and universities nationwide who have achieved a rating of more than 90% satisfaction from their international residents.\r\n\r\n&nbsp;', 'Overseas Students', '', 'publish', 'closed', 'closed', '', 'overseas-students', '', '', '2016-08-30 08:17:46', '2016-08-30 08:17:46', '', 0, 'http://host.dev/?page_id=194', 0, 'page', '', 0),
(195, 1, '2016-08-30 08:17:46', '2016-08-30 08:17:46', 'Starting university can be a daunting prospect for any student, but even more so for those traveling from overseas, especially for the first time.\r\n\r\nHost Students offers welcoming, secure and affordable accommodation designed to provide all the necessary touches to help our residents feel instantly at home and settle in quickly.\r\n\r\nFully equipped kitchens containing a fridge, freezer, oven and hob, kettle, toaster, microwave, cutlery, crockery and cooking utensils are provided as standard and bedding can be arranged with your hall in advance of your arrival as an optional extra*.\r\n\r\n*<em>not available in all sites, please check with your chosen Hall’s on-site management team.</em>\r\n\r\nOur <a title="Awards" href="http://www.victoriahalls.com/blog/category/awards/">award winning accommodation</a> is located in areas close to universities and college campuses to allow you to fully experience all the benefits of studying and living in your chosen city and socialising with your new friends, whilst telephones in each flat* and internet provided to each bedroom allow you to keep in touch with your friends and family back home.\r\n\r\n<em>*Excludes Dashwood Studios</em>\r\n\r\nEach Host Students accommodation has a dedicated on-site management office where friendly staff can answer day to day queries and offer assistance in helping you settle into life in your new city. The first class service offered to our overseas students has been recognised by the award of a Quality Mark for International Accommodation in 2011, an award given to only 5 providers and universities nationwide who have achieved a rating of more than 90% satisfaction from their international residents.\r\n\r\n&nbsp;', 'Overseas Students', '', 'inherit', 'closed', 'closed', '', '194-revision-v1', '', '', '2016-08-30 08:17:46', '2016-08-30 08:17:46', '', 194, 'http://host.dev/194-revision-v1/', 0, 'revision', '', 0),
(196, 1, '2016-09-01 11:31:45', '2016-09-01 11:31:45', 'a:7:{s:8:"location";a:3:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"rooms";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"buildings";}}i:2;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"locations";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Header carousel', 'header-carousel', 'publish', 'closed', 'closed', '', 'group_57c8114bb90b6', '', '', '2016-09-01 13:13:21', '2016-09-01 13:13:21', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=196', 0, 'acf-field-group', '', 0),
(197, 1, '2016-09-01 11:31:46', '2016-09-01 11:31:46', 'a:16:{s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"insert";s:6:"append";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Carousel images', 'carousel_images', 'publish', 'closed', 'closed', '', 'field_57c8133c281d9', '', '', '2016-09-01 11:31:46', '2016-09-01 11:31:46', '', 196, 'http://host.dev/?post_type=acf-field&p=197', 0, 'acf-field', '', 0),
(198, 1, '2016-09-01 11:37:44', '2016-09-01 11:37:44', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"locations";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Location Information', 'location-information', 'publish', 'closed', 'closed', '', 'group_57c812edbf4d0', '', '', '2016-09-01 15:11:30', '2016-09-01 15:11:30', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=198', 0, 'acf-field-group', '', 0),
(199, 1, '2016-09-01 12:59:42', '2016-09-01 12:59:42', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header', '', 'publish', 'closed', 'closed', '', 'field_57c82803458c6', '', '', '2016-09-01 12:59:42', '2016-09-01 12:59:42', '', 198, 'http://host.dev/?post_type=acf-field&p=199', 0, 'acf-field', '', 0),
(200, 1, '2016-09-01 12:59:42', '2016-09-01 12:59:42', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title 1', 'title_1', 'publish', 'closed', 'closed', '', 'field_57c827ec458c4', '', '', '2016-09-01 12:59:42', '2016-09-01 12:59:42', '', 198, 'http://host.dev/?post_type=acf-field&p=200', 1, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(201, 1, '2016-09-01 12:59:42', '2016-09-01 12:59:42', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title 2', 'title_2', 'publish', 'closed', 'closed', '', 'field_57c827f7458c5', '', '', '2016-09-01 12:59:42', '2016-09-01 12:59:42', '', 198, 'http://host.dev/?post_type=acf-field&p=201', 2, 'acf-field', '', 0),
(202, 1, '2016-09-01 12:59:42', '2016-09-01 12:59:42', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_57c82815458c7', '', '', '2016-09-01 12:59:42', '2016-09-01 12:59:42', '', 198, 'http://host.dev/?post_type=acf-field&p=202', 3, 'acf-field', '', 0),
(203, 1, '2016-09-01 13:01:42', '2016-09-01 13:01:42', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Location', '', 'publish', 'closed', 'closed', '', 'field_57c828648b03f', '', '', '2016-09-01 13:01:42', '2016-09-01 13:01:42', '', 198, 'http://host.dev/?post_type=acf-field&p=203', 4, 'acf-field', '', 0),
(204, 1, '2016-09-01 13:01:42', '2016-09-01 13:01:42', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Location title', 'location_title', 'publish', 'closed', 'closed', '', 'field_57c828748b040', '', '', '2016-09-01 13:01:42', '2016-09-01 13:01:42', '', 198, 'http://host.dev/?post_type=acf-field&p=204', 5, 'acf-field', '', 0),
(205, 1, '2016-09-01 13:01:42', '2016-09-01 13:01:42', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Location description', 'location_description', 'publish', 'closed', 'closed', '', 'field_57c8288c8b041', '', '', '2016-09-01 13:01:42', '2016-09-01 13:01:42', '', 198, 'http://host.dev/?post_type=acf-field&p=205', 6, 'acf-field', '', 0),
(206, 1, '2016-09-01 13:03:13', '2016-09-01 13:03:13', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Things to do', 'things_to_do', 'publish', 'closed', 'closed', '', 'field_57c828aed6f1d', '', '', '2016-09-01 13:14:58', '2016-09-01 13:14:58', '', 198, 'http://host.dev/?post_type=acf-field&#038;p=206', 8, 'acf-field', '', 0),
(207, 1, '2016-09-01 13:03:13', '2016-09-01 13:03:13', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"20";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Item number', 'item_number', 'publish', 'closed', 'closed', '', 'field_57c828c1d6f1e', '', '', '2016-09-01 13:03:13', '2016-09-01 13:03:13', '', 206, 'http://host.dev/?post_type=acf-field&p=207', 0, 'acf-field', '', 0),
(208, 1, '2016-09-01 13:03:13', '2016-09-01 13:03:13', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"80";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Item Name', 'item_name', 'publish', 'closed', 'closed', '', 'field_57c828e3d6f1f', '', '', '2016-09-01 13:03:13', '2016-09-01 13:03:13', '', 206, 'http://host.dev/?post_type=acf-field&p=208', 1, 'acf-field', '', 0),
(209, 1, '2016-09-01 13:07:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-09-01 13:07:34', '0000-00-00 00:00:00', '', 0, 'http://host.dev/?post_type=locations&p=209', 0, 'locations', '', 0),
(210, 1, '2016-09-01 13:12:04', '2016-09-01 13:12:04', '', 'london_feature', '', 'inherit', 'open', 'closed', '', 'london_feature', '', '', '2016-09-01 13:12:04', '2016-09-01 13:12:04', '', 9, 'http://host.dev/app/uploads/2016/08/london_feature.jpg', 0, 'attachment', 'image/jpeg', 0),
(211, 1, '2016-09-01 13:12:05', '2016-09-01 13:12:05', '', 'london', '', 'inherit', 'open', 'closed', '', 'london-2', '', '', '2016-09-01 13:12:14', '2016-09-01 13:12:14', '', 9, 'http://host.dev/app/uploads/2016/08/london.jpg', 0, 'attachment', 'image/jpeg', 0),
(212, 1, '2016-09-01 13:14:58', '2016-09-01 13:14:58', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Things to do title', 'things_to_do_title', 'publish', 'closed', 'closed', '', 'field_57c82b9fef965', '', '', '2016-09-01 13:14:58', '2016-09-01 13:14:58', '', 198, 'http://host.dev/?post_type=acf-field&p=212', 7, 'acf-field', '', 0),
(213, 1, '2016-09-01 13:50:17', '2016-09-01 13:50:17', '', 'kings_cross_feature', '', 'inherit', 'open', 'closed', '', 'kings_cross_feature', '', '', '2016-09-01 13:50:17', '2016-09-01 13:50:17', '', 48, 'http://host.dev/app/uploads/2016/08/kings_cross_feature.jpg', 0, 'attachment', 'image/jpeg', 0),
(214, 1, '2016-09-01 13:52:36', '2016-09-01 13:52:36', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"buildings";}}}s:8:"position";s:4:"side";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Building - External website', 'building-external-website', 'publish', 'closed', 'closed', '', 'group_57c8323d1b0ff', '', '', '2016-09-01 14:04:00', '2016-09-01 14:04:00', '', 0, 'http://host.dev/?post_type=acf-field-group&#038;p=214', 0, 'acf-field-group', '', 0),
(215, 1, '2016-09-01 13:52:36', '2016-09-01 13:52:36', 'a:10:{s:4:"type";s:8:"checkbox";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:1:{s:8:"external";s:16:"External website";}s:13:"default_value";a:0:{}s:6:"layout";s:8:"vertical";s:6:"toggle";i:0;s:13:"return_format";s:5:"value";}', 'External website', 'external_website', 'publish', 'closed', 'closed', '', 'field_57c8342cd2812', '', '', '2016-09-01 14:04:00', '2016-09-01 14:04:00', '', 214, 'http://host.dev/?post_type=acf-field&#038;p=215', 0, 'acf-field', '', 0),
(216, 1, '2016-09-01 13:52:36', '2016-09-01 13:52:36', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_57c8342cd2812";s:8:"operator";s:2:"==";s:5:"value";s:8:"external";}}}}', 'Website URL', 'website_url', 'publish', 'closed', 'closed', '', 'field_57c83463d2813', '', '', '2016-09-01 13:52:36', '2016-09-01 13:52:36', '', 214, 'http://host.dev/?post_type=acf-field&p=216', 1, 'acf-field', '', 0),
(217, 1, '2016-09-01 14:23:13', '2016-09-01 14:23:13', 'a:13:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:3:{s:9:"available";s:15:"Rooms available";s:7:"limited";s:20:"Limited availability";s:8:"sold_out";s:8:"Sold out";}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:13:"return_format";s:5:"value";s:11:"placeholder";s:0:"";}', 'Availability', 'availability', 'publish', 'closed', 'closed', '', 'field_57c83af56a8ab', '', '', '2016-09-01 14:23:13', '2016-09-01 14:23:13', '', 39, 'http://host.dev/?post_type=acf-field&p=217', 3, 'acf-field', '', 0),
(218, 1, '2016-09-01 14:24:17', '2016-09-01 14:24:17', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Prices from', 'prices_from', 'publish', 'closed', 'closed', '', 'field_57c83bca4bd33', '', '', '2016-09-01 14:24:17', '2016-09-01 14:24:17', '', 39, 'http://host.dev/?post_type=acf-field&p=218', 4, 'acf-field', '', 0),
(219, 1, '2016-09-01 15:11:29', '2016-09-01 15:11:29', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Things to do Image', 'things_to_do_image', 'publish', 'closed', 'closed', '', 'field_57c846edbc365', '', '', '2016-09-01 15:11:29', '2016-09-01 15:11:29', '', 198, 'http://host.dev/?post_type=acf-field&p=219', 9, 'acf-field', '', 0),
(220, 1, '2016-09-01 15:11:52', '2016-09-01 15:11:52', '', 'london_attraction', '', 'inherit', 'open', 'closed', '', 'london_attraction', '', '', '2016-09-01 15:30:23', '2016-09-01 15:30:23', '', 9, 'http://host.dev/app/uploads/2016/08/london_attraction.jpg', 0, 'attachment', 'image/jpeg', 0),
(221, 1, '2016-09-01 15:30:03', '2016-09-01 15:30:03', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Location image', 'location_image', 'publish', 'closed', 'closed', '', 'field_57c84b4680837', '', '', '2016-09-01 15:30:03', '2016-09-01 15:30:03', '', 85, 'http://host.dev/?post_type=acf-field&p=221', 19, 'acf-field', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(18, 2, 0),
(19, 3, 0),
(20, 5, 0),
(171, 6, 0),
(172, 6, 0),
(173, 6, 0),
(174, 6, 0),
(185, 7, 0),
(186, 7, 0),
(187, 7, 0),
(188, 7, 0),
(189, 7, 0),
(190, 7, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'category', '', 0, 1),
(3, 3, 'category', '', 0, 1),
(4, 4, 'category', '', 0, 0),
(5, 5, 'category', '', 0, 1),
(6, 6, 'nav_menu', '', 0, 4),
(7, 7, 'nav_menu', '', 0, 6),
(8, 8, 'nav_menu', '', 0, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Premium Studio', 'premium-studio', 0),
(3, 'Large Studio', 'large-studio', 0),
(4, 'Studio', 'studio', 0),
(5, 'En-suite Room', 'en-suite-room', 0),
(6, 'Primary Menu', 'primary-menu', 0),
(7, 'Footer Utilities', 'footer-utilities', 0),
(8, 'Footer About', 'footer-about', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'developers'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:1:{s:64:"f06c5561ce72557946b3d67203e991d731c2545c748fc671bec4176b4d3543f1";a:4:{s:10:"expiration";i:1472901181;s:2:"ip";s:12:"192.168.50.1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1472728381;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '84'),
(16, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse'),
(17, 1, 'wp_user-settings-time', '1470929318'),
(18, 1, 'meta-box-order_buildings', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:139:"submitdiv,pageparentdiv,acf-group_57c8323d1b0ff,postimagediv,p2p-from-building_to_location,p2p-from-building_to_uni,p2p-to-room_to_building";s:6:"normal";s:175:"acf-group_57b2f6e941ba7,acf-group_57b19251e35fe,acf-group_57bf0201a455c,acf-group_57c8114bb90b6,acf-group_57c812edbf4d0,acf-group_57bedc06b5a5e,acf-group_57b18f4d73a67,slugdiv";s:8:"advanced";s:0:"";}'),
(19, 1, 'screen_layout_buildings', '2'),
(20, 1, 'closedpostboxes_university', 'a:0:{}'),
(21, 1, 'metaboxhidden_university', 'a:2:{i:0;s:13:"pageparentdiv";i:1;s:7:"slugdiv";}'),
(22, 1, 'meta-box-order_university', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:84:"submitdiv,postimagediv,pageparentdiv,p2p-from-uni_to_location,p2p-to-building_to_uni";s:6:"normal";s:7:"slugdiv";s:8:"advanced";s:0:"";}'),
(23, 1, 'screen_layout_university', '2'),
(24, 1, 'acf_user_settings', 'a:0:{}'),
(25, 1, 'closedpostboxes_buildings', 'a:0:{}'),
(26, 1, 'metaboxhidden_buildings', 'a:5:{i:0;s:13:"pageparentdiv";i:1;s:23:"acf-group_57b2f6e941ba7";i:2;s:23:"acf-group_57b19251e35fe";i:3;s:23:"acf-group_57b18f4d73a67";i:4;s:7:"slugdiv";}'),
(27, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:38:"dashboard_right_now,dashboard_activity";s:4:"side";s:21:"dashboard_quick_press";s:7:"column3";s:17:"dashboard_primary";s:7:"column4";s:0:"";}'),
(28, 1, 'closedpostboxes_rooms', 'a:0:{}'),
(29, 1, 'metaboxhidden_rooms', 'a:6:{i:0;s:13:"pageparentdiv";i:1;s:23:"acf-group_57b2f6e941ba7";i:2;s:23:"acf-group_57b19251e35fe";i:3;s:23:"acf-group_57bf0201a455c";i:4;s:23:"acf-group_57b18f4d73a67";i:5;s:7:"slugdiv";}'),
(30, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(31, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:24:"add-post-type-university";i:1;s:23:"add-post-type-locations";i:2;s:23:"add-post-type-buildings";i:3;s:19:"add-post-type-rooms";i:4;s:12:"add-post_tag";}'),
(32, 1, 'nav_menu_recently_edited', '8'),
(33, 1, 'meta-box-order_rooms', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:74:"submitdiv,categorydiv,pageparentdiv,p2p-from-room_to_building,postimagediv";s:6:"normal";s:151:"acf-group_57b2f6e941ba7,acf-group_57b19251e35fe,acf-group_57bf0201a455c,acf-group_57bedc06b5a5e,acf-group_57c8114bb90b6,acf-group_57b18f4d73a67,slugdiv";s:8:"advanced";s:0:"";}'),
(34, 1, 'screen_layout_rooms', '2'),
(35, 1, 'meta-box-order_locations', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:87:"submitdiv,pageparentdiv,p2p-to-uni_to_location,p2p-to-building_to_location,postimagediv";s:6:"normal";s:175:"acf-group_57b2f6e941ba7,acf-group_57b19251e35fe,acf-group_57bf0201a455c,acf-group_57c812edbf4d0,acf-group_57c8114bb90b6,acf-group_57bedc06b5a5e,acf-group_57b18f4d73a67,slugdiv";s:8:"advanced";s:0:"";}'),
(36, 1, 'screen_layout_locations', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'developers', '$2y$10$Q56Pw3pjiGesxPvH4VEyrurLqhfkTw/cOBSTuYCx3osfyJOh7Xqse', 'developers', 'digital@example.dev', '', '2016-08-09 16:23:30', '', 0, 'developers') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

